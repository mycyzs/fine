controllers.controller("home", function ($scope, loading, confirmModal, msgModal) {

});
