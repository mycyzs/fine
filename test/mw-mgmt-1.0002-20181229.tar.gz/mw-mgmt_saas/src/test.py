import requests
import base64
url = 'http://paas.cwbke.com/api/c/compapi/v2/cc/search_host/'
awgs = {
        "bk_app_code": 'oraclecheck',
        "bk_app_secret": "f2d8d4c0-9222-11e8-8d62-e470b80d6741",
        "bk_token": "AaSAhV8rp9mVYvRIJ-zwcvj_gIoBm6y_Xv38D3wm90E",
        "ip": {
            "data": [],
            "exact": 1,
            "flag": "bk_host_innerip|bk_host_outerip"
        },
        "condition": [
            {
                "bk_obj_id": "biz",
                "fields": [],
                "condition": []
            },
        ],
        "page": {
            "start": 0,
            "limit": 200,
            "sort": ""
        },
    }
res = requests.post(url=url,json=awgs,verify=False)
print res
print res.content