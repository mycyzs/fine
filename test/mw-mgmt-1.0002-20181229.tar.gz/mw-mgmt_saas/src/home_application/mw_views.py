# -*- coding: utf-8 -*-
from common.mymako import render_json
from common.log import logger
from home_application.models import *
import time
import json
from home_application.helper import insert_log
from home_application.celery_tasks import start_config
from home_application.helper import *
from home_application.config_default_data import PLAN_CONFIG
def get_middle_ware(request):
    try:
        get_data = json.loads(request.body)
        filter_ip = get_data['ip']
        ret = []
        try:
            for i in MiddlewareType.objects.get(name=get_data['type']).middleware_set.order_by('-id').filter(is_delete=False,ip__icontains=filter_ip).values():
                try:
                    i['new_time'] = Middleware.objects.get(id=i['id']).historymiddleware_set.order_by('-create_time').filter()[0].create_time
                except:
                    pass
                ret.append(i)
        except:
            pass
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def has_model(request):
    try:
        get_data = json.loads(request.body)
        try:
            mid_obj = MiddlewareType.objects.get(name=get_data['type'])
            plan_list = []
            plan_data = {}
            for i in mid_obj.settingplan_set.values():
                plan_list.append({'id':i['id'],'name':i['name'],'display':i['display']})
                plan_data[i['id']] = eval(i['config_detail'])
            ret = {'has':True,'plan_data':plan_data,'plan_list':plan_list}
            if plan_list.__len__()==0:

                ret = {'has': False, 'data': PLAN_CONFIG[get_data['type']]}
        except Exception,e:

            ret = {'has': False, 'data': PLAN_CONFIG[get_data['type']]}
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def del_middleware(request):
    try:
        get_data = json.loads(request.body)
        mid_obj = Middleware.objects.get(id=get_data['id'])
        old_ip = mid_obj.ip
        old_type = mid_obj.type.name
        mid_obj.delete()
        # mid_obj.is_delete=True
        # mid_obj.save()
        insert_log(u'配置管理', request.user.username, u'删除中间件:' +old_type+'/'+ old_ip)
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def add_middleware(request):
    try:
        get_data = json.loads(request.body)
        if get_data['base'].get('id',False):
            # 修改
            # if MiddlewareType.objects.get(name=get_data['tpye']).middleware_set.exclude(id=get_data['base']['id']).filter(is_delete=False,ip=get_data['base']['ip'],port=get_data['base']['port']):
            #     return render_json({'result': False,'message':u'已存在此中间件！'})
            if get_data['base']['is_cluster']=='1':
                get_data['base']['is_cluster'] = True
            else:
                get_data['base']['is_cluster'] = False
            if get_data['base']['is_time']=='1':
                get_data['base']['is_time'] = True
            else:
                get_data['base']['is_time'] = False
            old_ip = Middleware.objects.get(id=get_data['base']['id']).ip
            Middleware.objects.filter(id=get_data['base']['id']).update(**get_data['base'])
            new_obj = Middleware.objects.get(id=get_data['base']['id'])
            mid_pass = ''
            if new_obj.configpath_set.filter(key='pass'):
                mid_pass=new_obj.configpath_set.filter(key='pass')[0].value
            new_obj.configpath_set.all().delete()
            for i in get_data['config']:
                if i['key'] == 'pass':
                    if i['value'] != '':
                        i['value'] = encrypt(i['value'])
                    else:
                        i['value'] = mid_pass
                new_obj.configpath_set.create(**i)
            # start_config.delay([new_obj.id])
            # start_config([new_obj.id])
            insert_log(u'配置管理', request.user.username, u'修改中间件:' +get_data['tpye']+'/'+ get_data['base']['ip']+u'—>'+old_ip)
            if get_data['path'] and get_data['path']!='':
                try:
                    mid_config = str(get_data['config'])
                    if mid_config == SettingPlan.objects.get(id=get_data['path']).config_detail:
                        return render_json({'result': True,'save':False})
                except:
                    pass
        else:
            # 添加
            # if MiddlewareType.objects.get(name=get_data['tpye']).middleware_set.filter(is_delete=False,ip=get_data['base']['ip'],port=get_data['base']['port']):
            #
            #     return render_json({'result': False,'message':u'已存在此中间件！'})
            if get_data['base']['is_cluster']=='1':
                get_data['base']['is_cluster'] = True
            else:
                get_data['base']['is_cluster'] = False
            if get_data['base']['is_time']=='1':
                get_data['base']['is_time'] = True
            else:
                get_data['base']['is_time'] = False
            get_data['base']['creator'] = request.user.username
            get_data['base']['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
            new_obj = MiddlewareType.objects.get(name=get_data['tpye']).middleware_set.create(**get_data['base'])
            for i in get_data['config']:
                if i['key'] == 'pass':
                    i['value'] = encrypt(i['value'])
                new_obj.configpath_set.create(**i)
                # 配置任务开启
            start_config.delay([new_obj.id])
            # start_config([new_obj.id])
            insert_log(u'配置管理', request.user.username, u'添加中间件:' +get_data['tpye']+'/'+ get_data['base']['ip'])
            if get_data['path']:
                mid_config = str(get_data['config'])
                if mid_config == SettingPlan.objects.get(id=get_data['path']).config_detail:
                    return render_json({'result': True,'save':False})
        return render_json({'result': True,'save':True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def sync_middle_ware(request):
    try:
        get_id = json.loads(request.body)['id']
        mid_obj = Middleware.objects.get(id=get_id)
        his_mid_obj = mid_obj.historymiddleware_set.create(**{'create_time':time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))})

        for i in mid_obj.configtype_set.all().values():
            next_id = i['id']
            i.pop('id')
            i.pop('midware_id')
            new_obj = his_mid_obj.historyconfigtype_set.create(**i)
            for g in ConfigType.objects.get(id=next_id).configitem_set.all().values():
                g.pop('id')
                g.pop('config_type_id')
                new_obj.historyconfigitem_set.create(**g)

        return render_json({'result': True, 'save': True})
    except Exception,e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_middle_ware_detail(request):
    try:
        get_data = json.loads(request.body)
        mid_obj = Middleware.objects.get(id=get_data['id'])
        base_data = list(Middleware.objects.filter(id=get_data['id']).values())[0]
        if base_data['is_cluster']:
            base_data['is_cluster'] = '1'
        else:
            base_data['is_cluster'] = '0'
        if base_data['is_time']:
            base_data['is_time'] = '1'
        else:
            base_data['is_time'] = '0'
        plan_item = []
        now_config = [x['key'] for x in PLAN_CONFIG[mid_obj.type.name]]
        for i in mid_obj.configpath_set.all():
            if i.key in now_config:
                mid_item_data = {'key':i.key,'value':i.value,'display':i.display}
                if i.key == 'pass':
                    mid_item_data['value'] = ''
                plan_item.append(mid_item_data)
        return render_json({'result': True,'base_data':base_data,'plan_data':plan_item})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_middle_ware_config_item(request):
    try:
        get_data = json.loads(request.body)
        mid_obj = Middleware.objects.get(id=get_data['id'])
        base_data = list(Middleware.objects.filter(id=get_data['id']).values())[0]
        item_data = []
        for i in mid_obj.configtype_set.all().values():
            mid_ret = {'type':i,'item':[]}
            for y in ConfigType.objects.get(id=i['id']).configitem_set.all().values():
                try:
                    y['value'] = eval(y['value'])
                except Exception,e:
                    pass
                if type(y['value'])==type([]):
                    y['rgtypeof'] = True

                mid_ret['item'].append(y)
            item_data.append(mid_ret)
        his_data = []
        his_time_list = []
        for y in mid_obj.historymiddleware_set.all():
            his_time_list.append(y.create_time)
            his_item_data = []
            for i in y.historyconfigtype_set.all().values():
                mid_ret = {'type': i, 'item': []}
                for y in HistoryConfigType.objects.get(id=i['id']).historyconfigitem_set.all().values():
                    try:
                        y['value'] = eval(y['value'])
                    except:
                        pass
                    if type(y['value']) == type([]):
                        y['rgtypeof'] = True
                        try:
                            y['value_list'] = y['value'][0].keys()
                        except:
                            pass
                    mid_ret['item'].append(y)
                his_item_data.append(mid_ret)
            his_data.append(his_item_data)
        return render_json({'result': True,'data':{'base_data':base_data,'item_data':item_data,'his_data':{'time':his_time_list,'data':his_data}}})
    except Exception, e:
        logger.error(e)
        logger.exception('1111')
        return render_json({'result': False, 'error': str(e)})

def get_instance_list(request):
    try:
        get_data = json.loads(request.body)
        filter_ip = get_data.get('ip','')
        tpye_obj = MiddlewareType.objects.get(name=get_data['type'])
        ret = []
        for mid_obj in tpye_obj.middleware_set.order_by('-id').filter(is_delete=False,ip__icontains=filter_ip):
            index = 0
            row_len = mid_obj.instance_set.all().__len__()
            for g in mid_obj.instance_set.all():
                if index==0:
                    mid_name = mid_obj.ip+':'+mid_obj.port
                else:
                    mid_name = ''
                ret.append({'id':mid_obj.id,'state':mid_obj.state,'mid_name':mid_name,'row':row_len,'name':g.name,'app':list(g.application_set.all().values())})
                index=index+1
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

OPERATE_TOMCAT = {'Linux':{'open':'startup.sh','close':'shutdown.sh'},'Windows':{'open':'startup.bat','close':'shutdown.bat'}}
OPERATE_WEBLOGIC = {'Linux':{'open':'startWebLogic.sh','close':'stopWebLogic.sh','openvip':'startManagedWebLogic.sh','closevip':'stopManagedWebLogic.sh'},'Windows':{'open':'startWebLogic.bat','close':'stopWebLogic.bat','openvip':'startManagedWebLogic.bat','closevip':'stopManagedWebLogic.bat'}}
def operate_mw(request):
    # return render_json({'result': False})
    from home_application.mw_helper import RGMiddleWare
    from home_application.celery_tasks import sync_connect
    try:
        get_data = json.loads(request.body)
        get_id = get_data['id']
        mw_obj = Middleware.objects.get(id=get_id)
        ip_obj = Servers.objects.get(ip=mw_obj.ip)
        server_os = ip_obj.sys_type
        if server_os=='Windows':
            pass
        elif server_os=='Linux':
            pass
        else:
            server_os = 'Linux'
        op_type = get_data['type']

        if mw_obj.type.name=='tomcat':
            mid_script = mw_obj.configpath_set.get(key='jvm').value
            mid_list = mid_script.split('/')
            mid_list[-1]=OPERATE_TOMCAT[server_os][op_type]
            script_val = '/'.join(mid_list)
        elif mw_obj.type.name=='weblogic':
            mid_script = mw_obj.configpath_set.get(key='operate').value
            if mid_script.endswith('/'):
                pass
            else:
                mid_script = mid_script+'/'
            instname = get_data['name']
            instlist = instname.split('(')
            if instlist.__len__()==2:
                instname = instlist[0]
            else:
                instlist.pop()
                instname = '('.join(instlist)
            admin_server =  mw_obj.configtype_set.get(name='root').configitem_set.get(key='AdminServerName').value
            if admin_server==instname:
                script_val = mid_script+OPERATE_WEBLOGIC[server_os][op_type+'vip']
            else:
                script_val = mid_script + OPERATE_WEBLOGIC[server_os][op_type]+' '+instname
        if server_os=='Windows':
            acct = 'Administrator'
        else:
            acct = 'root'
        mid_data = [{'ip': mw_obj.ip, 'app_id': ip_obj.module.business_id, 'source': ip_obj.source, 'creator': mw_obj.creator, 'script':script_val}]
        retdata = RGMiddleWare(mid_data,acct,False).run_script_only()
        try:
            sync_connect(get_id)
        except:
            pass
        insert_log(u'监控管理', request.user.username, u'操作中间件:'+mw_obj.ip +':'+mw_obj.port+op_type )
        if retdata['result']:
            ret = retdata['data'][0]['comback']['logContent']
            ret.lstrip()
            ret.rstrip()
            if ret =='':
                ret = '关闭成功'
            return render_json({'result': True,'data':ret,'script':script_val})
        else:
            ret = retdata['data']
            return render_json({'result': False, 'data': ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


