# -*- coding: utf-8 -*-

from home_application.models import Logs
from common.log import logger
from esb.client import get_esb_client
from blueking.component.shortcuts import get_client_by_user
from conf.default import APP_TOKEN, APP_ID, BK_PAAS_HOST,SOURCE_IP,SOURCE_URL,JMXCMD_PATH,JMXCMD_PATH_WINDOWS
import base64
from home_application.models import Servers
from binascii import b2a_hex, a2b_hex
from Crypto.Cipher import AES
from Crypto import Random
import requests
import json

import time
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


def insert_log(operated_type, operator, detail):
    date_now_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    Logs.objects.create(operated_type=operated_type, when_created=date_now_str, operator=operator, content=detail)


def send_mail(to, subject, mail_content, content_type="HTML"):
    if not to:
        return
    client = get_esb_client()
    kwargs = {
        "to": to,
        "subject": subject,
        "content": mail_content,
        "content_type": content_type,
    }
    result = client.call("common", "send_email", kwargs)
    if result["result"]:
        logger.error(u"邮件发送成功")
    else:
        logger.error(result["message"])


def has_file(ip, file_url):
    get_ip_data = get_host_ip([ip])
    if get_ip_data['result']:
        # get_ip_data['data']['business_id']source
        mid_script = '''
        find %s &> /dev/null
        [ $? -eq 0 ] && echo "hasfile" || echo "nofile"
        ''' % (file_url)
        get_ret = fast_script('admin', {'app_id': get_ip_data['data']['business_id'],'account':'root',
                              'ip_list': [{'source': get_ip_data['data']['source'], 'ip': ip}]}, mid_script)
        if get_ret['result']:
            try:
                log_content = get_ret['data'][0]['logContent']
                if 'nofile' in log_content:
                    return False
            except:
                return False
        else:
            return False
        return True
    else:
        return False


def fast_push_file(ip,account='root'):
    self_ip_data = get_host_ip([SOURCE_IP])
    get_ip_data = get_host_ip([ip])
    if self_ip_data['result']:
        try:
            self_cred = {
                'ip': SOURCE_IP,
                'app_id':self_ip_data['data']['business_id'] ,
                'source': self_ip_data['data']['source'],
            }
        except:
            self_cred = {
                'ip': '192.168.2.154',
                'app_id': '3',
                'source': '0',
            }
        mid_path = JMXCMD_PATH
        if account=='system':
            mid_path = JMXCMD_PATH_WINDOWS
        get_ret = fast_file('admin', {'app_id': get_ip_data['data']['business_id'], 'ip_list': [{'ip': ip, 'source':get_ip_data['data']['source']}]},
                            self_cred, SOURCE_URL+'cmdline-jmxclient-0.10.3.jar', mid_path, account)
        if get_ret['result']:
            if get_ret['data'][0]['result']:
                return True
            else:
                return False
        else:
            return False
    else:
        return False

def fast_file(username, server, self_cred, self_path, target_path, account='root'):
    client = get_client_by_user(username)
    kwargs = {
        "app_code": APP_ID,
        "app_secret": APP_TOKEN,
        "app_id": server['app_id'],
        "username": username,
        "file_source": [{
            'account': account,
            'ip_list': [
                {
                    "ip": self_cred['ip'],
                    "source": self_cred['source']
                }
            ],
            'file': self_path
        }],
        "file_target_path": target_path,
        "ip_list": server["ip_list"],
        "target_app_id": server["app_id"],
        "account": 'root',
    }

    logger.error(kwargs)
    result = client.job.fast_push_file(kwargs)
    logger.error(result)
    if result["result"]:
        task_id = result["data"]["taskInstanceId"]
        time.sleep(2)
        return get_ip_log_content(client, username, task_id)
    else:
        return {"result": False, "data": result["message"]}


def get_host_ip(iplist):
    url = BK_PAAS_HOST + "/api/c/compapi/v2/cc/search_host/"
    headers = {"Accept": "application/json"}
    params = {
        "bk_app_code": APP_ID,
        "bk_app_secret": APP_TOKEN,
        "bk_username": "admin",
        "ip": {
            "data": iplist,
            "exact": 1,
            "flag": "bk_host_innerip|bk_host_outerip"
        },
        "condition": [
            {
                "bk_obj_id": "biz",
                "fields": [],
                "condition": []
            },
        ],
        "page": {
            "start": 0,
            "limit": 200,
            "sort": ""
        },
    }

    res = requests.post(url, json=params, headers=headers,verify=False)
    result = json.loads(res.content)
    ret = {'result': True}
    if result['result']:
        ret['data'] = {'business_id': result['data']['info'][0]['biz'][0]['bk_biz_id'],
                       'source': result['data']['info'][0]['host']['bk_cloud_id'][0]['bk_inst_id']}
        return ret
    else:
        ret['result'] = False
        ret['error'] = str(res)
        return ret




def fast_script(username, server, script_content, script_type=1, script_timeout=3600):
    client = get_client_by_user(username)
    kwargs = {
        "app_code": APP_ID,
        "app_secret": APP_TOKEN,
        "app_id": server["app_id"],
        "username": username,
        "content": base64.b64encode(script_content),
        "ip_list": server["ip_list"],
        "type": script_type,
        "account": server["account"],
        "script_timeout": script_timeout
    }
    result = client.job.fast_execute_script(kwargs)
    if result["result"]:
        task_id = result["data"]["taskInstanceId"]
        time.sleep(2)
        return get_ip_log_content(client, username, task_id)
    else:
        return {"result": False, "data": result["message"]}


# 获取脚本任务Log
def get_ip_log_content(client, username, task_id, i=1):
    kwargs = {
        "app_code": APP_ID,
        "app_secret": APP_TOKEN,
        "username": username,
        "task_instance_id": task_id
    }
    result = client.job.get_task_ip_log(kwargs)
    if result["result"]:
        if result["data"][0]["isFinished"]:
            ip_log_content = []
            for i in result["data"][0]["stepAnalyseResult"]:
                if i["resultType"] == 9:
                    ip_log_content.extend([{"result": True, "ip": str(j["ip"]), "logContent": j["logContent"]} for j in
                                           i["ipLogContent"]])
                else:
                    ip_log_content.extend([{"result": False, "ip": str(j["ip"]), "logContent": j["logContent"]} for j in
                                           i["ipLogContent"]])
            return {"result": True, "data": ip_log_content}
        else:
            time.sleep(1)
            return get_ip_log_content(client, username, task_id)
    else:
        i += 1
        if i < 5:
            time.sleep(1)
            return get_ip_log_content(client, username, task_id, i)
        else:
            err_msg = "get_logContent_timeout;task_id:%s;err_msg:%s" % (task_id, result["message"])
            return {"result": False, "data": err_msg}


def os_server_win(app_id, ip_list, creator, script, accout='administrator'):
    try:
        mid_data = {'app_id': app_id,
                    'ip_list': ip_list,
                    'account': accout}
        result = fast_script(creator, mid_data, script, 2)
        if result["result"]:
            data = result["data"]
            for i in data:
                try:
                    if i["result"] and i["logContent"]:
                        tmpdata = [j for j in i["logContent"].split("@@@@@") if j]
                        logcontent = format_log_content_win(tmpdata[0])[0]
                        modelstr = format_log_content_win(tmpdata[1])[0]["Model"]
                        logcontent["sys_type"] = "Virtual" if (
                            "Virtual" in modelstr or "HVM" in modelstr) else "Physical"
                        logcontent["ip"] = i["ip"]
                        if "2008" in logcontent["Caption"] and "2008 R2" not in logcontent["Caption"]:
                            operation_system = "Microsoft Windows Server 2008" + logcontent["Caption"].split("2008")[1]
                        elif "2008 R2" in logcontent["Caption"]:
                            operation_system = "Microsoft Windows Server 2008 R2" + + \
                            logcontent["Caption"].split("2008 R2")[1]
                        else:
                            operation_system = logcontent["Caption"]
                        Servers.objects.filter(ip=logcontent["ip"]).update(hostname=logcontent["CSName"],
                                                                           sys_type="Windows",
                                                                           operation_system=operation_system)
                except:
                    logger.error(i["ip"])
            return {"result": True}
        else:
            return {"result": False}
    except Exception, e:
        return {"result": False}


def format_log_content_lin_linux(log_content):
    log_list = [i.strip('\n') for i in log_content.split('\n') if i.strip('\n')]
    info = {}
    for s in log_list:
        info[str(s).split("=")[0]] = str(s).split("=")[1]
    return info


def format_log_content_win(log_content, split_str="\n\n\n\n"):
    log_list = [j.strip("\n") for j in log_content.split(split_str) if j]
    info = []
    for d in log_list:
        if d:
            dinfo = {}
            for s in d.split("\n\n"):
                if s:
                    dinfo[str(s).split("=")[0].strip(" ")] = str(s).split("=")[1].strip(" ") if len(
                        str(s).split("=")) == 2 else ""
            info.append(dinfo)
    return info


def os_server_linux(app_id, ip_list, creator, script, accout='root'):
    try:
        mid_data = {'app_id': app_id,
                    'ip_list': ip_list,
                    'account': accout}
        result = fast_script(creator, mid_data, script, 1)
        if result["result"]:
            data = result["data"]
            for i in data:
                try:
                    if i["result"] and i["logContent"]:
                        logcontent = format_log_content_lin_linux(i["logContent"])
                        logcontent["ip"] = i["ip"]
                        Servers.objects.filter(ip=logcontent["ip"]).update(hostname=logcontent["hostname"],
                                                                           sys_type="Linux",
                                                                           operation_system=logcontent[
                                                                               "operation_system"])
                except Exception, e:
                    logger.error(i["ip"])
            return {"result": True}
        else:
            return {"result": False}
    except Exception, e:
        return {"result": False}


def get_cmdb_mw(mw_name):
    try:
        url = BK_PAAS_HOST + '/api/c/compapi/v2/cc/search_inst_by_object/'
        awgs = {
            "bk_app_code": APP_ID,
            "bk_app_secret": APP_TOKEN,
            "bk_username": "admin",
            "bk_obj_id": mw_name,
            "fields": [
            ],
            "condition": {
            },
        }
        res = requests.post(url=url, json=awgs,verify=False)
        ret = json.loads(res.content)
        if ret['result']:
            return ret['data']['info']
        else:
            return []
    except Exception, e:
        logger.exception('get_cmdb_error')
        return []


def get_cc_auto_mw(obj_id, inst_name):
    try:
        url = BK_PAAS_HOST + '/api/c/compapi/ccauto/get_token/'
        awgs = {
            "bk_app_code": APP_ID,
            "bk_app_secret": APP_TOKEN,
            "bk_username": "admin",
            "obj_id": obj_id,
            "inst_name": inst_name
        }
        res = requests.post(url=url, json=awgs,verify=False)
        ret = json.loads(res.content)
        if ret['result']:
            ret_mid = ret['data']
            return ret_mid
        else:
            return []
    except Exception, e:
        logger.exception('get_cmdb_error')
        return []


key = "wusnxhdyshdksiwy"
mode = AES.MODE_ECB
encryptor = AES.new(key, mode)


def encrypt(plaintext):
    while len(plaintext) % 16 != 0:
        n = 0
        n += 1
        plaintext += "\0" * n
    cipher = encryptor.encrypt(plaintext)
    return b2a_hex(cipher)


def decrypt(ciphertext):
    plain1 = encryptor.decrypt(a2b_hex(ciphertext))
    plain = plain1.rstrip("\0")
    return plain


AES_KEY = '12740f2c57aba727a4be179049cecf29'


def aes_encrypt(data):
    bs = AES.block_size
    pad = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs)
    iv = Random.new().read(bs)
    cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
    data = cipher.encrypt(pad(data))
    data = iv + data
    return data.encode('base64')


def aes_decrypt(data):
    try:
        data = data.decode('base64')
        bs = AES.block_size
        if len(data) <= bs:
            return data
        unpad = lambda s: s[0:-ord(s[-1])]
        iv = data[:bs]
        cipher = AES.new(AES_KEY, AES.MODE_CBC, iv)
        data = unpad(cipher.decrypt(data[bs:]))
        return data
    except Exception as e:
        logger.exception()
        return ''
