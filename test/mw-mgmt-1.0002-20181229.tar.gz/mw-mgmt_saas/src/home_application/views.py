# -*- coding: utf-8 -*-

from common.mymako import render_mako_context,render_json
from celery_tasks import *
import json
import sys
import StringIO
import xlsxwriter
from django.http import HttpResponse
from django.db.models import Q
import xlrd

reload(sys)
sys.setdefaultencoding('utf-8')


def home(request):
    """
    首页
    """

    return render_mako_context(request, '/home_application/js_factory.html')

def sync_def(request):
    config_sync.delay(request.GET.get('type',''))
    return render_json({'result':True})

def sync_mw(request):
    try:
        get_data = json.loads(request.body)['id']
        start_config.delay([get_data])
        # start_config([get_data])
        return render_json({'result': True})
    except:
        return render_json({'result': False})

def sync_c(request):
    try:
        btn_sync.delay()
        return render_json({'result': True})
    except:
        return render_json({'result': False})

from home_application.config_default_data import PLAN_CONFIG
def down_demo(request):
    try:
        get_data = request.GET.dict()
        mid_type = get_data['type']
        excel_name = mid_type+'_demo.xlsx'
        data = {
                'ip':{'name':'','list':[i.ip for i in Servers.objects.all()]},
                'is_cluster':{'name':u'非集群','list':[u'集群',u'非集群']},
                'port':'',
                'state': {'name': u'获取数据中', 'list': [u'获取数据中', u'成功',u'错误']},
                'java_version':'',
                'is_time':{'name':u'否','list':[u'是',u'否']},
            }
        row_common = [
            {'key': 'ip', 'val': u'IP'},
            {'key': 'is_cluster', 'val': u'是否群集'},
            {'key': 'port', 'val': u'端口'},
            {'key': 'state', 'val': u'状态'},
            {'key': 'java_version', 'val': u'java版本'},
            {'key': 'is_time', 'val': u'定时备份'},
        ]
        for z in PLAN_CONFIG[mid_type]:
            data[z['key']] = ''
            row_common.append({
                'key':z['key'],'val':z['display']
            })
        ret = {'data':[{'table_data':[data]}],"row_common":row_common}
        return make_summay_excel(ret,excel_name)
    except Exception, e:
        logger.error(e)
        return render_json({"result": False, "data": u"系统异常，请联系管理员！"})

def down_mw(request):
    try:
        get_data = request.GET.dict()
        mid_type = get_data['type']
        excel_name = mid_type+'_data.xlsx'
        all_data = []
        row_common = [
            {'key': 'ip', 'val': u'IP'},
            {'key': 'is_cluster', 'val': u'是否群集'},
            {'key': 'port', 'val': u'端口'},
            {'key': 'state', 'val': u'状态'},
            {'key': 'java_version', 'val': u'java版本'},
            {'key': 'is_time', 'val': u'定时备份'},
        ]
        option_dict = {
            "is_cluster":{
                True:u'集群',
                False:u'非集群',
            },
            "state": {
                'waitting': u'获取数据中',
                'success': u'成功',
                'fail': u'错误',
            },
            'is_time':{
                True: u'是',
                False: u'否',
            }
        }
        first_op = False
        for mw_obj in Middleware.objects.filter(type__name=mid_type).values():
            data = {
                    'ip':{'name':mw_obj['ip'],'list':[i.ip for i in Servers.objects.all()]},
                    'is_cluster':{'name':option_dict['is_cluster'][mw_obj['is_cluster']],'list':[u'集群',u'非集群']},
                    'port':mw_obj['port'],
                    'state': {'name': option_dict['state'][mw_obj['state']], 'list': [u'获取数据中', u'成功',u'错误']},
                    'java_version':mw_obj['java_version'],
                    'is_time':{'name':option_dict['is_time'][mw_obj['is_time']],'list':[u'是',u'否']},
                }
            path_true = {}
            for x in ConfigPath.objects.filter(midware_id=mw_obj['id']).values():
                path_true[x['key']] = x['value']
            for z in PLAN_CONFIG[mid_type]:
                data[z['key']] = path_true.get(z['key'],'')
                if first_op==False:
                    row_common.append({
                        'key':z['key'],'val':z['display']
                    })
            all_data.append(data)
            first_op = True
        ret = {'data':[{'table_data':all_data}],"row_common":row_common}
        return make_summay_excel(ret,excel_name)
    except Exception, e:
        logger.error(e)
        return render_json({"result": False, "data": u"系统异常，请联系管理员！"})

def make_summay_excel(ret,filename):
    row_common = ret['row_common']
    sio = StringIO.StringIO()
    workbook = xlsxwriter.Workbook(sio)
    worksheet = workbook.add_worksheet()
    header_format = workbook.add_format({
        'num_format': '@',
        'align': 'center',
        'bg_color': '#0090ff',
        'valign': 'vcenter',
        'font_size': 12,
        'font_color': 'white',
        'border': 1
    })
    normol_format = workbook.add_format({
        'num_format': '@',
        'align': 'center',
        'valign': 'vcenter',
        'font_size': 12,
        'font_color': 'black',
        'border': 1
    })
    warn_format = workbook.add_format({
        'num_format': '@',
        'align': 'center',
        'valign': 'vcenter',
        'bg_color': 'red',
        'font_size': 12,
        'font_color': 'white',
        'border': 1
    })
    row_index = 0
    for title_row in row_common:
        worksheet.set_column(0, row_index, 20)
        worksheet.write(0, row_index, title_row['val'], header_format)
        row_index += 1
    row_index = 1
    for server_index in ret['data']:
        mid_len = server_index['table_data'].__len__()
        tr_index = 0
        is_first = True
        for tr in server_index['table_data']:
            td_index = 0
            for title in row_common:
                mid_key = title['key']
                if title.get('is_common', False):
                    if is_first:
                        if mid_len == 1:
                            worksheet.write(row_index, td_index, server_index.get(mid_key,''),
                                            normol_format)
                        else:
                            worksheet.merge_range(row_index, td_index, row_index + mid_len - 1, td_index,
                                                  server_index.get(mid_key, ''), normol_format)
                else:
                    mid_val = tr.get(mid_key,'')
                    mid_format = normol_format
                    if type(mid_val) == dict:
                        worksheet.write(row_index+tr_index, td_index, mid_val['name'], mid_format)
                        worksheet.data_validation(row_index+tr_index, td_index, row_index+tr_index, td_index, {'validate': 'list', 'source': mid_val['list']})
                    else:
                        worksheet.write(row_index+tr_index, td_index, mid_val, mid_format)
                td_index += 1
            tr_index += 1
            is_first = False
        row_index += row_index + mid_len - 1
    workbook.close()
    sio.seek(0)
    response = HttpResponse(sio.getvalue(), content_type='APPLICATION/OCTET-STREAM')
    response['Content-Disposition'] = 'attachment; filename='+filename
    return response

def up_excel(request):
    try:
        mid_type = request.GET.get('type','')
        error_data = []
        name = 'tests%s.xlsx' % (time.time())
        file = open(name, 'wb')
        type_obj = MiddlewareType.objects.get(name=mid_type)
        file.write(request.FILES['files'].read())
        file.close()
        data = xlrd.open_workbook(name)
        table = data.sheets()[0]
        nrows = table.nrows
        ncols = table.ncols
        base_list = ['ip', 'is_cluster', 'port','state', 'java_version', 'is_time']
        index_list = ['ip','is_cluster','port','state', 'java_version','is_time']
        other_list = []
        for z in PLAN_CONFIG[mid_type]:
            index_list.append(z['key'])
            other_list.append(z)
        data_list = []
        for i in range(1, nrows):
            data_dict = {}
            table_row_value = table.row_values(i)
            for g in range(table_row_value.__len__()):
                mid_val = table_row_value[g]
                if index_list[g]=='is_time':
                    if mid_val==u'是':
                        mid_val = True
                    else:
                        mid_val = False
                if index_list[g]=='is_cluster':
                    if mid_val==u'集群':
                        mid_val = True
                    else:
                        mid_val = False
                if index_list[g]=='pass':
                    try:
                        decrypt(mid_val)
                    except:
                        mid_val = encrypt(mid_val)
                data_dict[index_list[g]] = mid_val
            data_list.append(data_dict)
        os.remove(name)
        error_list = []
        log_list = []
        for dict_cell in data_list:
            try:
                base_dict = {}
                for base in base_list:
                    base_dict[base] = dict_cell.get(base,'')
                if base_dict.get('state',False):
                    base_dict.pop('state')
                ip_count = type_obj.middleware_set.filter(ip=base_dict['ip']).count()
                if ip_count==0:
                    # create
                    base_dict['creator'] = request.user.username
                    base_dict['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
                    new_obj = type_obj.middleware_set.create(**base_dict)
                    for other in other_list:
                        other['value'] = dict_cell.get(other['key'],'')
                        new_obj.configpath_set.create(**other)
                elif ip_count==1:
                    # modify
                    type_obj.middleware_set.filter(ip=base_dict['ip']).update(**base_dict)
                    new_obj = type_obj.middleware_set.get(ip=base_dict['ip'])
                    new_obj.configpath_set.all().delete()
                    for other in other_list:
                        other['value'] = dict_cell.get(other['key'],'')
                        new_obj.configpath_set.create(**other)
                else:
                    # no one
                    ip_port_count = type_obj.middleware_set.filter(ip=base_dict['ip'],port=base_dict['port']).count()
                    if ip_port_count==1:
                        # modify
                        type_obj.middleware_set.filter(ip=base_dict['ip'],port=base_dict['port']).update(**base_dict)
                        new_obj = type_obj.middleware_set.get(ip=base_dict['ip'],port=base_dict['port'])
                        new_obj.configpath_set.all().delete()
                        for other in other_list:
                            other['value'] = dict_cell.get(other['key'], '')
                            new_obj.configpath_set.create(**other)
                    else:
                        # no one
                        path_str = 'operate'
                        if mid_type=='weblogic':
                            path_str = 'operate'
                        elif mid_type=='tomcat':
                            path_str = 'jvm'
                        elif mid_type=='apache':
                            path_str = 'httpd'
                        elif mid_type=='websphere':
                            path_str = 'wsadmin'
                        mid_obj = type_obj.middleware_set.filter(ip=base_dict['ip'],
                                                                       port=base_dict['port']).filter(Q(configpath__value=dict_cell.get(path_str,''))&Q(configpath__key=path_str))
                        for new_obj in mid_obj:
                            Middleware.objects.filter(id=new_obj.id).update(**base_dict)
                            new_obj.configpath_set.all().delete()
                            for other in other_list:
                                other['value'] = dict_cell.get(other['key'], '')
                                new_obj.configpath_set.create(**other)
                start_config.delay([new_obj.id])
                log_list.append(str(new_obj.ip))
            except Exception,e:
                error_data.append(str(e))
                error_list.append(dict_cell['ip']+u'导入失败！')
        if log_list.__len__()!=0:
            insert_log(u'配置管理', request.user.username, u'批量添加中间件:' + mid_type + '/' + (','.join(log_list)))
        if error_list.__len__() == 0 and error_data.__len__() == 0:
            return render_json({'result': True})
        else:
            return render_json({'result': False, 'error': '、'.join(error_list), 'error_data': error_data})
    except Exception,e:
        return render_json({'result': False,'all_error':str(e)})