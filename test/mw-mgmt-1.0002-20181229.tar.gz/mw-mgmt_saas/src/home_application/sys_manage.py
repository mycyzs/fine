# -*- coding: utf-8 -*-
from common.mymako import render_json
from common.log import logger
from home_application.models import *
from blueking.component.shortcuts import get_client_by_request
import time
import json
from home_application.helper import insert_log
from home_application.celery_tasks import updata_business, add_business_server, sync_business
from esb import ESBTools


def get_ip_server(request):
    try:
        ret = []
        for i in Business.objects.all():
            server_data = []
            for u in i.module_set.all():
                for o in u.servers_set.all():
                    server_data.append({'id': o.id, 'name': o.ip,'os':o.sys_type})
            if not server_data.__len__() == 0:
                ret.append({'name': i.name, 'children': server_data})
        return render_json({'result': True, 'data': ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


def get_business_list(request):
    try:
        get_data = json.loads(request.body)
        ret = [i for i in Business.objects.filter(name__icontains=get_data['name']).values()]
        return render_json({'result': True, 'data': ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


# 根据选择的业务刷新数据
def get_business_all(request):
    try:
        # 获取client，使用这个方法意味着要用调用对象的方案使用esb了
        # client = get_client_by_request(request)
        # kwargs = {}
        # 获取业务列表
        # result = client.cc.get_app_by_user(kwargs)
        business_data = ESBTools.search_business_message(request)
        if business_data["result"]:
            result = business_data["data"]["info"]
            hasbusiness = [i.id for i in Business.objects.all()]
            app_list = [{"name": i["bk_biz_name"], "id": i["bk_biz_id"]} for i in result if
                        i["bk_biz_id"] != 1 and i["bk_biz_id"] not in hasbusiness and request.user.username in i["bk_biz_maintainer"]]
            return render_json({'result': True, 'data': app_list})
        else:
            return render_json({'result': False, 'data': []})
        # app_list = []
        # 获取数据库内已有的业务列表
        # hasbusiness = [i.id for i in Business.objects.all()]
        # if result["result"]:
        #     datas = result["data"]
        # 使用列表推导生成list，排除掉数据库中已存在的业务和ApplicationId==1的业务（啥玩意？）
        # app_list = [{"name": data["ApplicationName"], "id": data["ApplicationID"]} for data in datas if
        #             data["ApplicationID"] != "1" and int(data["ApplicationID"]) not in hasbusiness]

    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


# 业务新增方案
def add_business(request):
    try:
        # 获取前端传入的数据
        get_data = json.loads(request.body)
        # 列表推导，拿到一个封装好数据的列表，包含需要新增到business表中的数据
        create_data = [{'created_by': request.user.username, 'id': i['id'], 'name': i['name'],
                        'when_created': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))} for i in
                       get_data]
        # 循环处理业务表新增，以及对应的业务下主机信息的更新
        for g in create_data:
            # **为字典方案传值
            buobj = Business.objects.create(**g)
            # 到这里业务表新增完成
            # 重点，处理业务下面的主机信息的更新
            # add_business_server.delay(buobj.id)
            add_business_server.delay(request.user.username,buobj.id)
            insert_log(u'业务管理', request.user.username, u'添加业务:' + buobj.name)
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        print e
        return render_json({'result': False, 'error': str(e)})


def sync_bussiness(request):
    try:
        # sync_business(request.user.username)
        sync_business.delay(request.user.username)
        # sync_business()
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


def delet_business(request):
    try:
        get_id = json.loads(request.body)['id']
        business_name = Business.objects.get(id=get_id).name
        Business.objects.filter(id=get_id).delete()
        insert_log(u'业务管理', request.user.username, u'删除业务:' + business_name)
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


def get_log(request):
    try:
        fiter_data = json.loads(request.body)
        ret = [i for i in Logs.objects.filter(
            operated_type__icontains=fiter_data['operateType'],
            operator__icontains=fiter_data['operator'],
            when_created__range=(str(fiter_data["whenStart"]) + " 00:00:00", str(fiter_data["whenEnd"]) + " 23:59:59")
        ).order_by('-when_created').values()]
        return render_json({'result': True, 'data': ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


def get_user(request):
    try:
        get_data = json.loads(request.body)
        ret = [i for i in Userinfo.objects.filter(name__icontains=get_data['name']).order_by('-when_created').values()]
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_user_list(request):
    try:
        ret= [{'text': i['name'], 'id': i['id']} for i in Userinfo.objects.all().values()]
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def add_user(request):
    try:
        get_data = json.loads(request.body)
        get_data['when_created'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        if Userinfo.objects.filter(name=get_data['name']):
            return render_json({'result': False,'error':u'用户名已存在'})
        else:
            Userinfo.objects.create(**get_data)
        insert_log(u'运维人员管理', request.user.username, u'添加人员:' + get_data['name'])
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def modify_user(request):
    try:
        get_data = json.loads(request.body)
        if not Userinfo.objects.get(id=get_data['id']).name==get_data['name']:
            if Userinfo.objects.filter(name=get_data['name']):
                return render_json({'result': False,'error':u'用户名已存在'})
        old_name = Userinfo.objects.get(id=get_data['id']).name
        Userinfo.objects.filter(id=get_data['id']).update(**get_data)
        insert_log(u'运维人员管理', request.user.username, u'修改人员:' + old_name+'-->'+get_data['name'])
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def del_user(request):
    try:
        get_id = json.loads(request.body)['id']
        old_name = Userinfo.objects.get(id=get_id).name
        Userinfo.objects.filter(id=get_id).delete()
        insert_log(u'运维人员管理', request.user.username, u'删除人员:' + old_name)
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


def get_mw_type_list(request):
    try:
        get_data = json.loads(request.body)
        ret = list(MiddlewareType.objects.filter(name__icontains=get_data.get('name','')).values())
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

from home_application.config_default_data import DEFAULT_MIDWARE_CONFIG
def add_mw_type(request):
    try:
        get_data = json.loads(request.body)
        if MiddlewareType.objects.filter(name=get_data['name']):
            return render_json({'result': False, 'message': u'已添加此中间件类型！'})
        if get_data['name']=='':
            return render_json({'result': False, 'message': u'请选择中间件类型！'})
        get_data['creator'] = request.user.username
        get_data['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        # default_data = DEFAULT_MIDWARE_CONFIG[get_data['name']]
        new_type_obj = MiddlewareType.objects.create(**get_data)
        # for i in default_data:
        #     new_setting_type_obj = new_type_obj.settingconfigtype_set.create(**i['type'])
        #     for u in i['item']:
        #         new_setting_type_obj.settingconfigitem_set.create(**u)
        insert_log(u'中间件类型管理', request.user.username, u'添加类型:' + get_data['name'])
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def del_mw_type(request):
    try:
        get_data = json.loads(request.body)
        MiddlewareType.objects.get(id=get_data['id']).delete()
        insert_log(u'中间件类型管理', request.user.username, u'删除类型:' + get_data['name'])
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})


def get_mw_type_config(request):
    try:
        get_data = json.loads(request.body)
        get_obj = MiddlewareType.objects.get(id=get_data['id'])
        ret = []
        for i in get_obj.settingconfigtype_set.all().values():
            mid_ret = {'type':i,'item':[]}
            for y in SettingConfigType.objects.get(id=i['id']).settingconfigitem_set.all().values():
                mid_ret['item'].append(y)
            ret.append(mid_ret)
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})




def add_plan(request):
    try:
        get_data = json.loads(request.body)
        if get_data.get('id',False):
            if SettingPlan.objects.exclude(id=get_data['id']).filter(name=get_data['data']['name']):
                return render_json({'result': True, 'message': u'已存在此模板'})
            old_name = SettingPlan.objects.get(id=get_data['id']).name
            SettingPlan.objects.filter(id=get_data['id']).update(**get_data['data'])
            insert_log(u'模板管理', request.user.username, u'修改模板:' + old_name +'-->'+get_data['data']['name'])
            return render_json({'result': True})
        else:
            mid_obj = MiddlewareType.objects.get(name=get_data['type'])
            if mid_obj.settingplan_set.filter(name=get_data['data']['name']):
                return render_json({'result': True, 'message': u'已存在此模板'})
            get_data['data']['creator'] = request.user.username
            get_data['data']['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
            new_obj = mid_obj.settingplan_set.create(**get_data['data'])
            insert_log(u'模板管理', request.user.username, u'创建模板:' + get_data['data']['name'])
            return render_json({'result': True,'new_id':new_obj.id})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_plan_list(request):
    try:
        get_data = json.loads(request.body)
        ret = []
        for i in SettingPlan.objects.filter(name__icontains=get_data.get('name','')).values():
            i['type_name'] = MiddlewareType.objects.get(id=i['middle_type_id']).name
            i['config_detail'] = eval(i['config_detail'])
            ret.append(i)
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def del_plan(request):
    try:
        get_data = json.loads(request.body)
        old_name = SettingPlan.objects.get(id=get_data['id']).name
        SettingPlan.objects.filter(id=get_data['id']).delete()
        insert_log(u'模板管理', request.user.username, u'删除模板:' + old_name)
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_plan_config(request):
    try:
        from home_application.config_default_data import PLAN_CONFIG
        ret = PLAN_CONFIG
        data_head = PLAN_CONFIG.keys()
        return render_json({'result': True,'data':ret,'data_head':data_head})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_default_mw_config(request):
    try:
        get_data = json.loads(request.body)
        mid_type_obj = MiddlewareType.objects.get(id=get_data['id'])
        type_list = [i.id for i in mid_type_obj.settingconfigtype_set.all()]
        all_key = [u.key for u in SettingConfigItem.objects.filter(setting_mid_type__in=type_list)]
        name = mid_type_obj.name
        from home_application.config_default_data import DEFAULT_MIDWARE_CONFIG
        midret = DEFAULT_MIDWARE_CONFIG[name]
        for u in midret:
            mid_data = []
            for y in u['item']:
                if y['key'] not in all_key:
                    mid_data.append(y)
            u['item'] = mid_data
        return render_json({'result': True,'data':midret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def up_default_mw_config(request):
    try:
        get_data = json.loads(request.body)
        get_obj = MiddlewareType.objects.get(id=get_data['id'])
        for i in get_data['up']:
            for g in i.keys():
                mid_obj = get_obj.settingconfigtype_set.get(name=g)
                mid_obj.settingconfigitem_set.all().delete()
                for y in i[g]:
                    mid_obj.settingconfigitem_set.create(**y)
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def get_setting(request):
    try:
        ret = list(Setting.objects.all().values())
        return render_json({'result': True,'data':ret})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})

def up_setting(request):
    try:
        get_data = json.loads(request.body)
        Setting.objects.filter(key=get_data['key']).update(value=get_data['value'])
        return render_json({'result': True})
    except Exception, e:
        logger.error(e)
        return render_json({'result': False, 'error': str(e)})
