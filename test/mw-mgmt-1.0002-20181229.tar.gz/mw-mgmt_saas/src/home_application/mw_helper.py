# -*- coding: utf-8 -*-
import os
from conf.default import PROJECT_ROOT,SOURCE_URL,SOURCE_IP,JMXCMD_PATH
import re
from home_application.models import *
import time
from common.log import logger
import json
import xml.etree.ElementTree as ET
from home_application.helper import *
import datetime
import socket


WEBCONF_TOMCAT = {'attr': ['port', 'shutdown'], 'text': False, 'next': [{'name': 'Service',
                                                                         'value': {'attr': ['name'], 'text': False,
                                                                                   'next': [
                                                                                       {'name': 'Connector', 'value': {
                                                                                           'attr': ['port', 'protocol',
                                                                                                    'connectionTimeout',
                                                                                                    'redirectPort']}},
                                                                                       {'name': 'Engine',
                                                                                        'value': {
                                                                                            'attr': [
                                                                                                'name',
                                                                                                'defaultHost'],
                                                                                            'next': [{
                                                                                                'name': 'Host',
                                                                                                'value': {
                                                                                                    'attr': [
                                                                                                        'name',
                                                                                                        'appBase',
                                                                                                        'unpackWARs',
                                                                                                        'autoDeploy']}}]}}]}}]}
USERCONF_TOMCAT = {'next': [{'name': 'user', 'value': {'attr': ['username', 'roles']}}]}
WEBCONF_WEBLOGIC = {
    'next': [{'name': 'name', 'value': {'text': True}}, {'name': 'domain-version', 'value': {'text': True}},
             {'name': 'production-mode-enabled', 'value': {'text': True}},
             {'name': 'configuration-version', 'value': {'text': True}},
             {'name': 'admin-server-name', 'value': {'text': True}}, {'name': 'server', 'value': {
            'next': [{'name': 'name', 'value': {'text': True}}, {'name': 'listen-address', 'value': {'text': True}},
                     {'name': 'port', 'value': {'text': True}},
                     {'name': 'ssl', 'value': {'next': [{'name': 'enabled', 'value': {'text': True}}]}}]}}]}


# [{'ip':'192','app_id':'1','source':123,'creator':'','script'}]
class RGMiddleWare():
    def __init__(self, ip_list, accout, is_ip=False, script_type=1):
        self.Ip_list = ip_list
        self.accout = accout
        self.script_type = script_type
        if is_ip:
            self.script_result_jvm = self.get_file_tomcat('jvm')
            self.script_result_server = self.get_file_tomcat('server')
            self.script_result_user = self.get_file_tomcat('user')
            self.script_result_httpd = self.get_file_tomcat('httpd')
            self.script_result_vhost = self.get_file_tomcat('vhost')

    def get_server_base(self):
        return self.get_server_info(self.Ip_list)

    def get_server_base_win(self):
        return self.get_server_info_win(self.Ip_list)

    def get_file_tomcat(self, index):
        try:
            ret = []
            for i in self.Ip_list:
                if not i['script'].get(index, False):
                    return {'result': False, 'data': {}}
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                mid_script = i['script'][index]
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def creat_weblogic_wlst(self):
        try:
            ret = []
            for i in self.Ip_list:
                wlst_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wlst'), 'r').read()
                mw_obj = Middleware.objects.get(id=i['id'])
                wlst_path = mw_obj.configpath_set.get(key='wlst').value
                wlst_accout = mw_obj.configpath_set.get(key='accout').value
                wlst_pass = mw_obj.configpath_set.get(key='pass').value
                wlst_pass = decrypt(wlst_pass)
                wlst_url = mw_obj.ip
                wlst_prot = mw_obj.port
                mid_py = wlst_py % (wlst_accout, wlst_pass, wlst_url, wlst_prot)
                wlst_path = wlst_path.replace('wlst.sh', 'wlst_py.py')
                mid_script = '''echo '%s' > %s
                ''' % (mid_py, wlst_path)
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def run_weblogic_wlst(self):
        try:
            self.creat_weblogic_wlst()
            time.sleep(5)
            ret = []
            for i in self.Ip_list:
                # wlst_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wlst'), 'r').read()
                mw_obj = Middleware.objects.get(id=i['id'])
                wlst_path = mw_obj.configpath_set.get(key='wlst').value
                run_path = wlst_path.replace('wlst.sh', '')
                mid_script = '''cd  %s
                ./wlst.sh wlst_py.py
                rm -rf wlst_py.py
                ''' % (run_path)
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def get_weblogic_wlst(self):
        try:
            # self.run_weblogic_wlst()
            ret = []
            for i in self.Ip_list:
                wlst_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wlst'), 'r').read()
                mw_obj = Middleware.objects.get(id=i['id'])
                mid_path_obj = mw_obj.configpath_set.get(key='wlst')
                wlst_path = mid_path_obj.value
                if 'wlst.sh' in wlst_path:
                    pass
                else:
                    if wlst_path.endswith('/'):
                        wlst_path = wlst_path+'wlst.sh'
                    else:
                        wlst_path = wlst_path + '/wlst.sh'
                    mid_path_obj.value = wlst_path
                mid_path_obj.save()
                wlst_accout = mw_obj.configpath_set.get(key='accout').value
                wlst_pass = mw_obj.configpath_set.get(key='pass').value
                wlst_pass = decrypt(wlst_pass)
                wlst_url = mw_obj.ip
                wlst_prot = mw_obj.port
                run_path = wlst_path.replace('wlst.sh', '')
                mid_i = {'id': i['id'], 'path': i['path']}
                if wlst_path=='' or wlst_accout=='' or wlst_url=='' or wlst_prot=='':
                    mid_i['result'] = False
                    mid_i['error'] = u'凭据不全'
                    ret.append(mid_i)
                    continue

                mid_script = wlst_py % (wlst_path,run_path,wlst_accout, wlst_pass, wlst_url, wlst_prot,str(i['id']),str(i['id']),str(i['id']))
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    if '_____' in mid_ret['logContent']:
                        mid_ret['logContent'] = mid_ret['logContent'].split('_____')[1].split('_____')[0]
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def get_websphere_data(self):
        try:
            ret = []
            for i in self.Ip_list:
                mw_obj = Middleware.objects.get(id=i['id'])
                wsadmin_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wsadmin'), 'r').read()
                wsadmin_path = mw_obj.configpath_set.get(key='wsadmin').value
                wsadmin_accout = mw_obj.configpath_set.get(key='accout').value
                wsadmin_pass = mw_obj.configpath_set.get(key='pass').value
                wsadmin_pass = decrypt(wsadmin_pass)
                wsadmin_ip = mw_obj.ip
                wsadmin_prot = mw_obj.port
                mid_list = wsadmin_path.split('/')
                mid_script = wsadmin_py % (
                    '/'.join(mid_list[:-1]), str(i['id']), wsadmin_ip, wsadmin_prot, wsadmin_accout, wsadmin_pass,
                    str(i['id']), str(i['id']))
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def get_jboss(self):
        try:
            ret = []
            for i in self.Ip_list:


                mw_obj = Middleware.objects.get(id=i['id'])
                if mw_obj.is_cluster:
                    cli_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'jboss_cli'), 'r').read()
                else:
                    cli_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'jboss_standalone'), 'r').read()
                mid_path_obj = mw_obj.configpath_set.get(key='cli')
                cli_path = mid_path_obj.value
                if 'jboss-cli.sh' in cli_path:
                    pass
                else:
                    if cli_path.endswith('/'):
                        cli_path = cli_path+'jboss-cli.sh'
                    else:
                        cli_path = cli_path + '/jboss-cli.sh'
                    mid_path_obj.value = cli_path
                mid_path_obj.save()
                wlst_accout = mw_obj.configpath_set.get(key='accout').value
                wlst_pass = mw_obj.configpath_set.get(key='pass').value
                wlst_pass = decrypt(wlst_pass)
                wlst_url = mw_obj.ip
                wlst_prot = mw_obj.port
                mid_i = {'id': i['id'], 'path': i['path']}
                if cli_path=='' or wlst_accout=='' or wlst_url=='' or wlst_prot=='':
                    mid_i['result'] = False
                    mid_i['error'] = u'凭据不全'
                    ret.append(mid_i)
                    continue

                mid_script = cli_py % (wlst_accout,wlst_pass,wlst_url,wlst_prot,cli_path)
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    if '______' in mid_ret['logContent']:
                        mid_ret['logContent'] = mid_ret['logContent'].split('______')[1].split('______')[0]
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def run_apache(self):
        try:
            ret = []
            for i in self.Ip_list:
                # wlst_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wlst'), 'r').read()
                mw_obj = Middleware.objects.get(id=i['id'])
                version_path = mw_obj.configpath_set.get(key='version').value
                apachectl_url = ''
                if version_path.endswith('/'):
                    apachectl_url = version_path + 'apachectl'
                else:
                    apachectl_url = version_path + '/apachectl'
                mid_script = '''
                %s -v
                ''' % (apachectl_url)
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def run_script_only(self):
        try:
            ret = []
            for i in self.Ip_list:
                mid_i = {}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                get_config_result = fast_script(i['creator'], mid_data, i['script'], self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def get_file_dir(self, pathindex):
        try:
            ret = []
            for i in self.Ip_list:
                if not i['path'].get(pathindex, False):
                    return {'result': False, 'data': {}}
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_data = {'app_id': i['app_id'],
                            'ip_list': [{'ip': i['ip'], 'source': i['source']}],
                            'account': self.accout}
                mid_path = i['path'].get(pathindex, '').split('/')
                mid_path.pop()
                mid_path[-1] = 'webapps'
                mid_path = '/'.join(mid_path)
                mid_script = '''ls -l  %s   |awk '/^d/ {print $NF}'
                ''' % (mid_path)
                get_config_result = fast_script(i['creator'], mid_data, mid_script, self.script_type)
                if not get_config_result["result"]:
                    mid_i['result'] = False
                    mid_i['error'] = get_config_result['data']
                else:
                    mid_ret = get_config_result["data"][0]
                    mid_i['result'] = True
                    # mid_ret['logContent'] = mid_ret['logContent'].replace('&lt;', '<').replace('&gt;', '>')
                    mid_ret['logContent'] = mid_ret['logContent'].lstrip()
                    mid_i['comback'] = mid_ret
                ret.append(mid_i)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def server_config_data(self, config_dict):
        if not self.script_result_server['result']:
            return self.script_result_server
        else:
            for i in self.script_result_server['data']:
                if i.get('comback', False):
                    get_data = i['comback']['logContent']
                    xml_data = get_data
                    if ' xmlns=' in xml_data:
                        xml_list = xml_data.split('xmlns=')
                        mid_xml = xml_list[1].lstrip()
                        yin = mid_xml[0]
                        mid_list = mid_xml.split(yin)
                        mid_list[1] = ''
                        next_xml_list = yin.join([z for z in mid_list if z != ''])
                        xml_data = xml_list[0] + next_xml_list
                    try:
                        ret = {'display': 'Server', 'value': [], 'rgtypeof': True}
                        end_data = ET.fromstring(xml_data)
                        mid_get = self.web_recursion(config_dict, end_data)
                        ret['value'] = mid_get + ret['value']
                        i['server_data'] = ret
                    except Exception, e:
                        i['server_data'] = xml_data
                        # return {'result':True,'data':ret['value']}

    def web_recursion(self, a, end_data):
        try:
            ret = []
            if a.get('attr', False):
                base_data = end_data.attrib
                for b in a['attr']:
                    ret.append({'display': b, 'value': base_data.get(b, ''), 'key': b})
            if a.get('text', False):
                base_data = end_data.text
                ret.append({'display': end_data.tag, 'value': base_data, 'key': end_data.tag})

            if a.get('next', False):
                for c in a['next']:
                    for d in end_data.findall(c['name']):
                        if c['value'].get('text', False):
                            mid_data = {'display': c['name'], 'key': c['name'], 'value': ''}
                            mid_data['value'] = d.text
                        else:
                            mid_data = {'display': c['name'], 'key': c['name'], 'rgtypeof': True, 'value': []}
                            mid_data['value'] = mid_data['value'] + self.web_recursion(c['value'], d)
                        ret.append(mid_data)
            return ret
        except Exception, e:
            print e
            return []

    def jvm_config_data(self, item_list):
        if not self.script_result_jvm['result']:
            return self.script_result_jvm
        else:
            for a in self.script_result_jvm['data']:
                if a.get('comback', False):
                    get_data = a['comback']['logContent']
                    xml_data = get_data
                    ret = []
                    try:
                        for i in item_list:
                            all_data = xml_data
                            if i in all_data:
                                next_data = all_data.split(i)[1].lstrip()
                                mid_data = next_data.split(' ')[0]
                                if mid_data[0] == '=':
                                    mid_val = mid_data[1:]
                                else:
                                    mid_val = mid_data
                                ret.append({'display': i, 'value': mid_val, 'key': i})
                        a['jvm_data'] = ret
                    except Exception, e:
                        a['jvm_data'] = xml_data

    def jvm_config_data_weblogic(self, item_list):
        if not self.script_result_jvm['result']:
            return self.script_result_jvm
        else:
            for a in self.script_result_jvm['data']:
                if a.get('comback', False):
                    get_data = a['comback']['logContent']
                    xml_data = get_data
                    mid_data = []
                    for u in xml_data.split('MEM_ARGS_'):
                        if 'MEM_ARGS' in u:
                            mid_data.append(u)
                    xml_data = ' '.join(mid_data)
                    ret = []
                    try:
                        for i in item_list:
                            all_data = xml_data
                            if i in all_data:
                                next_data = all_data.split(i)[1].lstrip()
                                mid_data = next_data.split(' ')[0]
                                if mid_data[0] == '=':
                                    mid_val = mid_data[1:]
                                else:
                                    mid_val = mid_data
                                ret.append({'display': i, 'value': mid_val, 'key': i})
                        a['jvm_data'] = ret
                    except Exception, e:
                        a['jvm_data'] = xml_data

    def user_config_data(self, config_dict):
        if not self.script_result_user['result']:
            return self.script_result_user
        else:
            for a in self.script_result_user['data']:
                if a.get('comback', False):
                    get_data = a['comback']['logContent']
                    xml_data = get_data.replace('\n', '')
                    ret = {'display': 'user', 'value': [], 'rgtypeof': True}
                try:
                    end_data = ET.fromstring(xml_data)
                    mid_get = self.web_recursion(config_dict, end_data)
                    ret['value'] = mid_get + ret['value']
                    a['user_data'] = ret
                except Exception, e:
                    a['user_data'] = xml_data

    def get_tomcat_base_config(self):
        self.user_config_data(USERCONF_TOMCAT)
        self.jvm_config_data(['Xms', 'Xmx', 'PermSize', 'MaxPermSize'])
        self.server_config_data(WEBCONF_TOMCAT)
        return {'jvm': self.script_result_jvm, 'server': self.script_result_server, 'user': self.script_result_user}

    def get_tomcat_jmx(self):
        ret = {}
        for i in self.Ip_list:
            if has_file(i['ip'],JMXCMD_PATH+'cmdline-jmxclient-0.10.3.jar'):
                logger.error(u'has cmd_client')
            else:
                if fast_push_file(i['ip']):
                    logger.error(u'fenfa cmd_client success')
                else:
                    logger.error(u'fenfa cmd_client error')
                    mid_ret = {'error': u'分发文件失败'}
            first_ret = ''
            try:
                cmd_list = ['Catalina:type=Server stateName',
                            'Catalina:type=Server shutdown',
                            'Catalina:type=Service name',
                            'Catalina:type=Engine name',
                            'Catalina:type=Engine defaultHost',
                            'Catalina:type=Connector,port=*',
                            'Catalina:type=Host,host=* name',
                            'Users:type=User,username=\"*\",database=UserDatabase username',
                            'java.lang:type=Memory HeapMemoryUsage',
                            r'java.lang:type=MemoryPool,name="PS Perm Gen" Usage',
                            r'java.lang:type=MemoryPool,name="Perm Gen" Usage',
                            r'java.lang:type=MemoryPool,name="Metaspace" Usage',
                            ]
                first_ret = commands_fast(cmd_list, i)
                ret_list = [z for z in first_ret.split('!____!')]
                mid_ret = {
                    'HeapMemoryUsage':{},
                    'Usage':{},
                    'user':{},
                    'stateName': back_last(ret_list[0]),
                    'shutdown': back_last(ret_list[1]),
                    'Service': {
                                    'name': back_last(ret_list[2]),
                                    'Connector':[],
                                    'Engine': {
                                        'name': back_last(ret_list[3]),
                                        'defaultHost': back_last(ret_list[4]),
                                        'host':[]
                                    }
                                }
                }
                four_key_list = ['committed', 'init', 'max', 'used']
                for heap_cell in ret_list[8].split('\n'):
                    if heap_cell:
                        for ke in four_key_list:
                            if ke in heap_cell:
                                mid_ret['HeapMemoryUsage'][ke]=heap_cell.split(':')[1].rstrip().lstrip()
                mid_ret_str = ret_list[9]+ret_list[10]+ret_list[11]
                for usage in mid_ret_str.split('\n'):
                    for ke in four_key_list:
                        if ke in usage:
                            mid_ret['Usage'][ke]=usage.split(':')[1].rstrip().lstrip()
                connect_list = [m for m in ret_list[5].split('\n') if m]
                connect_cmd = []
                key_list = ['port','protocol','connectionTimeout','redirectPort']
                for x in connect_list:
                    for keys in key_list:
                        connect_cmd.append(x+' '+keys)
                # connect_ret = commands_fast(connect_cmd, i)
                if 'Can be set only once' in ret_list[6]:
                    host_list = ['Catalina:host=%s,type=Host'%(mid_ret['Service']['Engine']['defaultHost'])]
                else:
                    host_list = ['Catalina:host=%s,type=Host'%(back_last(c)) for c in ret_list[6].split('\n') if c]
                host_key_list = ['name', 'appBase', 'unpackWARs', 'autoDeploy']
                host_cmd = []
                for x in host_list:
                    for keys in host_key_list:
                        host_cmd.append(x + ' ' + keys)
                # host_ret = commands_fast(host_cmd, i)

                user_list = []
                user_cmd_list = []
                for u in ret_list[7].split('\n'):
                    if u:
                        if 'username=' in u:
                            mid_user = u.split('username="')[1].split('"')[0]
                            user_cmd_list.append(r'Users:database=UserDatabase,type=User,username=\"%s\" roles' % (mid_user))
                            user_list.append(mid_user)
                        if 'username:' in u:
                            mid_user = u.split('username:')[1].lstrip().rstrip()
                            user_cmd_list.append(
                                r'Users:database=UserDatabase,type=User,username=\"%s\" roles' % (mid_user))
                            user_list.append(mid_user)
                ret_cmd = connect_cmd+['echo @@@@@@@@@@@@@']+host_cmd+['echo @@@@@@@@@@@@@']+user_cmd_list
                all_ret = commands_fast(ret_cmd, i)
                all_ret_list = [r for r in all_ret.split('@@@@@@@@@@@@@')]
                connect_ret = all_ret_list[0]
                host_ret = all_ret_list[1]
                user_ret = all_ret_list[2]
                for n in connect_ret.split('!____!'):
                    num = mid_ret['Service']['Connector'].__len__()
                    if num==0:
                        mid_ret['Service']['Connector'] = [{}]
                        num = 1
                    for zx in key_list:
                        if zx in n:
                            if mid_ret['Service']['Connector'][num-1].get(zx,False):
                                mid_ret['Service']['Connector'].append({zx:back_last(n)})
                            else:
                                mid_ret['Service']['Connector'][num-1][zx] = back_last(n)


                for n in host_ret.split('!____!'):
                    num = mid_ret['Service']['Engine']['host'].__len__()
                    if num == 0:
                        mid_ret['Service']['Engine']['host'] = [{}]
                        num = 1
                    for zx in host_key_list:
                        if zx in n:
                            if mid_ret['Service']['Engine']['host'][num - 1].get(zx, False):
                                mid_ret['Service']['Engine']['host'].append({zx: back_last(n)})
                            else:
                                mid_ret['Service']['Engine']['host'][num - 1][zx] = back_last(n)

                user_num = 0
                for q in user_ret.split('!____!'):
                    if 'rolename=' in q:
                        mid_ret['user'][user_list[user_num]] = []
                        for qc in q.split('\n'):
                            if 'rolename=' in qc:
                                mid_role_name = qc.split('rolename=')[1].split(',')[0]
                                mid_ret['user'][user_list[user_num]].append(mid_role_name)
                        user_num = user_num+1
            except Exception,e:
                logger.exception('tomcatdata_error')
                mid_ret = {'error':str(e)}
            ret[i['id']] = mid_ret
        return ret

    def get_weblogic_base_config(self):
        self.jvm_config_data_weblogic(['Xms', 'Xmx', 'PermSize', 'MaxPermSize'])
        self.server_config_data(WEBCONF_WEBLOGIC)
        return {'jvm': self.script_result_jvm, 'server': self.script_result_server}

    def get_apache_base_config(self):
        return {'httpd': self.script_result_httpd, 'vhost': self.script_result_vhost}

    def get_server_info(self, iplist):
        server_list_data = {}
        for i in [g['ip'] for g in iplist]:
            mid_obj = Servers.objects.get(ip=i)
            try:
                server_list_data[mid_obj.module.business_id].append({'ip': i,
                                                                     'source': mid_obj.source})
            except:
                server_list_data[mid_obj.module.business_id] = [{'ip': i,
                                                                 'source': mid_obj.source}]
        ret = []
        errorlist = []
        script_mid = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'server_config'), 'r').read()
        for y in server_list_data.keys():
            get_data = self.script_server_info(y, server_list_data[y], 'admin', script_mid, self.accout)
            if get_data['result']:
                ret = ret + get_data['data']
            else:
                errorlist = errorlist + [{'ip': i, 'error': get_data['data']} for i in server_list_data[y]]
        return {'success': ret, 'error': errorlist}

    def script_server_info(self, app_id, ip_list, creator, script, accout='root'):
        try:
            mid_data = {'app_id': app_id,
                        'ip_list': ip_list,
                        'account': accout}
            get_config_result = fast_script(creator, mid_data, script, self.script_type)
            if not get_config_result["result"]:
                return {'result': False, 'data': get_config_result['data']}
            ret = []
            for log_content in get_config_result["data"]:
                info = log_content["logContent"]
                info_list = info.split("\n")
                mid_ret = {'ip': log_content["ip"], 'val': []}
                for config_info in info_list:
                    try:
                        if config_info:
                            new_info = config_info.split("=")
                            mid_ret['val'].append(
                                {'display': SERVER_INFO_CONFIG.get(new_info[0], new_info[0]), 'key': new_info[0],
                                 'value': new_info[1].replace('&lt;', '<').replace('&gt;', '>')})
                    except Exception, e:
                        logger.error(e)
                if mid_ret['val'].__len__() == 0:
                    mid_ret['val'] = info
                ret.append(mid_ret)
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}

    def get_server_info_win(self, iplist):
        server_list_data = {}
        for i in [g['ip'] for g in iplist]:
            mid_obj = Servers.objects.get(ip=i)
            try:
                server_list_data[mid_obj.module.business_id].append({'ip': i,
                                                                     'source': mid_obj.source})
            except:
                server_list_data[mid_obj.module.business_id] = [{'ip': i,
                                                                 'source': mid_obj.source}]
        ret = []
        errorlist = []
        script_mid = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'server_config_win'), 'r').read()
        for y in server_list_data.keys():
            get_data = self.script_server_info_win(y, server_list_data[y], 'admin', script_mid, self.accout)
            if get_data['result']:
                ret = ret + get_data['data']
            else:
                errorlist = errorlist + [{'ip': i, 'error': get_data['data']} for i in server_list_data[y]]
        return {'success': ret, 'error': errorlist}

    def script_server_info_win(self, app_id, ip_list, creator, script, accout='Administrator'):
        try:
            mid_data = {'app_id': app_id,
                        'ip_list': ip_list,
                        'account': accout}
            get_config_result = fast_script(creator, mid_data, script, self.script_type)
            if not get_config_result["result"]:
                return {'result': False, 'data': get_config_result['data']}
            ret = []
            for log_content in get_config_result["data"]:
                mid_ret = {'ip': log_content["ip"], 'val': []}
                info = log_content["logContent"].split("@@@@@@@@@@")
                basicinfo = format_basic(info[0])
                cpuinfo = format_cpu(info[1])
                meminfo = format_mem(info[2])
                diskinfo = format_disk(info[3])
                macinfo = format_mac(info[4])
                hostmodel = "虚拟机" if "Virtual" in format_log_content(info[5])[0]["Model"] else "物理机"

                log_content["logContent"] = {"basicuptime": basicinfo.get('uptime', ''),
                                             "basicInstallDate": basicinfo.get('InstallDate', ''),
                                             "basichostname": basicinfo.get('hostname', ''),
                                             "basicVersion": basicinfo.get('Version', ''),
                                             "basictimezone": basicinfo.get('timezone', ''),
                                             "basicos": basicinfo.get('os', ''), "cpumodel": cpuinfo.get('Model', ''),
                                             "cpunum": cpuinfo.get('num', ''), "memnum": meminfo.get('num', ''),
                                             "memsize": meminfo.get('size', ''),
                                             "disknum": diskinfo.get('num', ''), "disksize": diskinfo.get('Size', ''),
                                             "macinfo": macinfo, "hostmodel": hostmodel}
                # mid_ret['val']
                for config_info in log_content["logContent"].keys():
                    try:
                        mid_val = log_content["logContent"][config_info]
                        if mid_val:
                            mid_ret['val'].append(
                                {'display': SERVER_INFO_CONFIG_WIN.get(config_info, config_info), 'key': config_info,
                                 'value': mid_val})
                    except Exception, e:
                        logger.error(e)
                if mid_ret['val'].__len__() == 0:
                    mid_ret['val'] = info
                ret.append(mid_ret)
            print ret
            return {'result': True, 'data': ret}
        except Exception, e:
            return {'result': False, 'data': str(e)}


SERVER_INFO_CONFIG = {'hostname': u'主机名称', 'operating_system': u'操作系统版本', 'product_name': u'硬件服务器品牌',
                      'cpu_info': u'CPU信息', 'disk_info': u'磁盘信息', 'mem_info': u'内存信息', 'fc_info': u'光纤卡信息',
                      'raid_info': u'RAID卡信息', 'nic_info': u'网卡信息', 'system_kernel': u'系统内核版本',
                      'system_install_time': u'系统安装时间', 'time_set': u'时区设置', 'system_run_time': u'系统运行时间',
                      'sys_type': u'服务器类型'}
SERVER_INFO_CONFIG_WIN = {'basichostname': u'主机名', 'basicos': u'操作系统版本', 'hostmodel': u'主机类型',
                          'cpunum': u'CPU个数', 'basicVersion': u'系统版本', 'basicuptime': u'系统运行时间',
                          'basicInstallDate': u'系统安装时间',
                          'basictimezone': u'时区设置', 'macinfo': u'MAC地址', 'cpumodel': u'CPU型号',
                          'memnum': u'内存数量', 'memsize': u'内存大小', 'disknum': u'磁盘数量',
                          'disksize': u'磁盘大小'}


def format_log_content(log_content):
    log_list = [j.strip("\n") for j in log_content.split("\n\n\n\n") if j]
    info = []
    for d in log_list:
        if d:
            dinfo = {}
            for s in d.split("\n\n"):
                if s:
                    dinfo[str(s).split("=")[0]] = str(s).split("=")[1]
            info.append(dinfo)
    return info


def format_basic(log_content):
    log_list = [j.strip("\n") for j in log_content.split("\n\n") if j]
    basicinfo = {}
    basicinfo["hostname"] = str(log_list[1]).split("=")[1]
    basicinfo["timezone"] = str(log_list[5]).split("=")[1]
    basicinfo["InstallDate"] = \
        str(datetime.datetime.strptime(str(str(log_list[2]).split("=")[1].split(".")[0]), "%Y%m%d%H%M%S")).split(".")[0]
    boottime = datetime.datetime.strptime(str(str(log_list[3]).split("=")[1].split(".")[0]), "%Y%m%d%H%M%S")
    basicinfo["uptime"] = str((datetime.datetime.now() - boottime).days) + "Days"
    basicinfo["Version"] = str(log_list[4]).split("=")[1]
    basicinfo["os"] = str(log_list[0]).split("=")[1]
    return basicinfo


def format_cpu(log_content):
    cpu = format_log_content(log_content)
    f_cpu = {}
    f_cpu["num"] = len(cpu)
    s = ""
    for i in cpu:
        if str(i["Name"]) not in s:
            s += str(i["Name"]) + ";"
    f_cpu["Model"] = s.strip(";")
    return f_cpu


def format_mem(log_content):
    mem = format_log_content(log_content)
    f_mem = {}
    f_mem["num"] = len(mem)
    s = 0
    for i in mem:
        s += int(i["Capacity"])
    f_mem["size"] = str(s / 1024 / 1024 / 1024) + "GB"
    return f_mem


def format_disk(log_content):
    disks = format_log_content(log_content)
    f_disk = {}
    f_disk["num"] = len(disks)
    s = 0
    for disk in disks:
        s += int(disk["Size"])
    f_disk["Size"] = str("%.2f" % (float(s) / 1024 / 1024 / 1024)) + "GB"
    return f_disk


def format_mac(log_content):
    mac = format_log_content(log_content)
    f_mac = ""
    for i in mac:
        f_mac += str(i["MACAddress"]) + ";"
    return f_mac.strip(";")


def is_connect(ip, port):
    sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sk.settimeout(5)
    try:
        port = int(port)
        ret_state = sk.connect_ex((ip, port))
        if ret_state == 0:
            sk.close()
            return True
        else:
            sk.close()
            return False
    except Exception, e:
        return False



def commands_fast(cmd, script_cred):
    cmd_ret = []
    for i in cmd:
        if 'echo @@@@@@@@@@@@@' in i:
            cmd_ret.append(i)
            continue
        cmd_ret.append('java -jar cmdline-jmxclient-0.10.3.jar - %s %s' % (
            script_cred['ip'] + ':' + script_cred['path']['jmx_port'], i))
    cmd_rets = '&&echo !____!&&'.join(cmd_ret)
    cmds = cmd_rets.replace('cmdline-jmxclient-0.10.3.jar', JMXCMD_PATH + 'cmdline-jmxclient-0.10.3.jar')
    get_ret = fast_script(script_cred['creator'], {'app_id': script_cred['app_id'],
                                                   'ip_list': [
                                                       {'ip': script_cred['ip'], 'source': script_cred['source']}],
                                                   'account': 'root'
                                                   }, cmds)
    if get_ret['result']:
        return get_ret['data'][0]['logContent']
    else:
        return get_ret['data']


def back_last(data):
    if 'not found' in data:
        return ''
    return data.split(':')[-1].lstrip().rstrip()
