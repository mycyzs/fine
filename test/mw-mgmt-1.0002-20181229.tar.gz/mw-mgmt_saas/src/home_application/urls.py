# -*- coding: utf-8 -*-

from django.conf.urls import patterns

urlpatterns = patterns(
    'home_application.views',
    # 首页--your index
    (r'^$', 'home'),
    (r'^config_sync$', 'sync_def'),
    (r'^sync_mw$', 'sync_mw'),
    (r'^sync_c$', 'sync_c'),
    (r'^down_demo$', 'down_demo'),
    (r'^down_mw$', 'down_mw'),
    (r'^up_excel$', 'up_excel'),
)
urlpatterns += patterns(
    'home_application.mw_views',
    (r'^get_middle_ware$', 'get_middle_ware'),
    (r'^has_model$', 'has_model'),
    (r'^add_middleware$', 'add_middleware'),
    (r'^sync_middle_ware$', 'sync_middle_ware'),
    (r'^del_middleware$', 'del_middleware'),
    (r'^get_middle_ware_detail$', 'get_middle_ware_detail'),
    (r'^get_middle_ware_config_item$', 'get_middle_ware_config_item'),
    (r'^get_instance_list$', 'get_instance_list'),
    (r'^operate_mw$', 'operate_mw'),


)
urlpatterns += patterns(
    'home_application.sys_manage',
    # 系统管理
    (r'^get_ip_server$', 'get_ip_server'),
    (r'^get_business_list$', 'get_business_list'),
    (r'^get_business_all$', 'get_business_all'),
    (r'^add_business$', 'add_business'),
    (r'^sync_bussiness$', 'sync_bussiness'),
    (r'^delet_business$', 'delet_business'),
    (r'^get_log$', 'get_log'),

    (r'^get_user$', 'get_user'),
    (r'^get_user_list$', 'get_user_list'),
    (r'^add_user$', 'add_user'),
    (r'^modify_user$', 'modify_user'),

    (r'^del_user$', 'del_user'),

    (r'^get_mw_type_list$', 'get_mw_type_list'),
    (r'^add_mw_type$', 'add_mw_type'),
    (r'^del_mw_type$', 'del_mw_type'),
    (r'^get_mw_type_config$', 'get_mw_type_config'),

    (r'^add_plan$', 'add_plan'),
    (r'^get_plan_list$', 'get_plan_list'),
    (r'^get_plan_config$', 'get_plan_config'),
    (r'^del_plan$', 'del_plan'),

    (r'^get_default_mw_config$', 'get_default_mw_config'),
    (r'^up_default_mw_config$', 'up_default_mw_config'),

    (r'^get_setting$', 'get_setting'),
    (r'^up_setting$', 'up_setting'),

)

urlpatterns += patterns(
    'api.get_tomcat_list',
    (r'^get_tomcat_list$', 'get_tomcat_list'),
    (r'^get_tomcat$', 'get_tomcat'),
)
urlpatterns += patterns(
    'api.get_weblogic_list',
    (r'^get_weblogic_list$', 'get_weblogic_list'),
    (r'^get_weblogic$', 'get_weblogic'),
    (r'^get_weblogic_instance$', 'get_weblogic_instance'),
    (r'^get_weblogic_instance_by_id$', 'get_weblogic_instance_by_id'),
    (r'^run_instance_idlist$', 'run_instance_idlist'),
)
urlpatterns += patterns(
    'api.get_apache_list',
    (r'^get_apache_list$', 'get_apache_list'),
    (r'^get_apache$', 'get_apache'),
)

urlpatterns += patterns(
    'api.get_websphere_list',
    (r'^get_websphere$', 'get_websphere'),
)

urlpatterns += patterns(
    'api.get_mw_info',
    (r'^get_mw_by_id$', 'get_mw_by_id'),
)