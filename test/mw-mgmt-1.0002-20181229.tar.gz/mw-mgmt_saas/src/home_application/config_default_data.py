# -*- coding: utf-8 -*-

DEFAULT_MIDWARE_CONFIG = {
    'tomcat': [
        {'type': {'display': u'服务器配置', 'name': 'os'}, 'item': [
            {'key': 'version', 'display': u'版本', 'is_default': False},
            {'key': 'test', 'display': u'测试字段', 'is_default': False},
        ]},
        {'type': {'display': u'JVM配置', 'name': 'jvm'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]},
        {'type': {'display': u'tomcat配置', 'name': 'server'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]},
        {'type': {'display': u'权限配置', 'name': 'user'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]}
    ], 'weblogic': [
        {'type': {'display': u'服务器配置', 'name': 'os'}, 'item': [
            {'key': 'version', 'display': u'版本', 'is_default': False},
            {'key': 'test', 'display': u'测试字段', 'is_default': False},
        ]},
        {'type': {'display': u'JVM配置', 'name': 'jvm'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]},
        {'type': {'display': u'tomcat配置', 'name': 'server'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]},
        {'type': {'display': u'权限配置', 'name': 'user'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]}
    ], 'apache': [
        {'type': {'display': u'服务器配置', 'name': 'os'}, 'item': [
            {'key': 'version', 'display': u'版本', 'is_default': False},
            {'key': 'test', 'display': u'测试字段', 'is_default': False},
        ]},
        {'type': {'display': u'JVM配置', 'name': 'jvm'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]},
        {'type': {'display': u'tomcat配置', 'name': 'server'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]},
        {'type': {'display': u'权限配置', 'name': 'user'}, 'item': [
            {'key': 'version1', 'display': u'版本1', 'is_default': False},
            {'key': 'test1', 'display': u'测试字段1', 'is_default': False},
        ]}
    ]
}

PLAN_CONFIG = {
    'tomcat': [
        {'key': 'jvm', 'value': '', 'display': u'Catalina路径'},
        {'key': 'jmx_port', 'value': '', 'display': u'JMX端口'},
    ],
    'weblogic': [
        {'key': 'wlst', 'value': '', 'display': u'wlst路径'},
        {'key': 'accout', 'value': '', 'display': u'账号'},
        {'key': 'pass', 'value': '', 'display': u'密码'},
        {'key': 'operate', 'value': '', 'display': u'启停路径'},
    ],
    'apache': [
        {'key': 'version', 'value': '', 'display': u'bin路径'},
        {'key': 'httpd', 'value': '', 'display': u'httpd路径'},
        {'key': 'vhost', 'value': '', 'display': u'vhost路径'},
    ],'websphere': [
        {'key': 'wsadmin', 'value': '', 'display': u'wsadmin路径'},
        {'key': 'accout', 'value': '', 'display': u'账号'},
        {'key': 'pass', 'value': '', 'display': u'密码'},
    ]
,'jboss': [
        {'key': 'cli', 'value': '', 'display': u'jboss-cli路径'},
        {'key': 'accout', 'value': '', 'display': u'账号'},
        {'key': 'pass', 'value': '', 'display': u'密码'},
    ]
}
