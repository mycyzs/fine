# -*- coding: utf-8 -*-
from celery import task
from celery.schedules import crontab
from celery.task import periodic_task
from home_application.models import *
from home_application.helper import send_mail
from common.log import logger
from esb.client import get_esb_client
from conf.default import BK_PAAS_HOST, APP_TOKEN, APP_ID, PROJECT_ROOT
from blueking.component.shortcuts import get_client_by_user
from home_application.helper import insert_log, fast_script, os_server_linux, os_server_win,has_file,decrypt
from mw_helper import RGMiddleWare, is_connect
import os
import time
import sys
from home_application.helper import get_cmdb_mw, get_cc_auto_mw
from esb import ESBTools
from home_application.windows.object import RGMiddleWareWindows
from  home_application.windows import data_maker
import json

reload(sys)
sys.setdefaultencoding("utf-8")


# """
# celery 任务示例
#
# 本地启动celery命令: python  manage.py  celery  worker  --settings=settings
# 周期性任务还需要启动celery调度命令：python  manage.py  celerybeat --settings=settings
# """


# @periodic_task(run_every=crontab(minute=0, hour=0))
# def delete_report():
#     pass

# 更新业务信息，然后根据业务id更新下面的模块，主机基础信息
@periodic_task(run_every=crontab(minute='30', hour='1', day_of_week="*"))
def updata_business():
    logger.error(u"更新业务开始")
    res_data = ESBTools.search_business_message_by_admin()
    if res_data['result']:
        biz_list = res_data["data"]["info"]
        for i in biz_list:
            mid_obj = Business.objects.filter(id=i["bk_biz_id"])
            if mid_obj:
                try:
                    mid_obj.update(name=i["bk_biz_name"])
                    # 业务更新完成后，同步该业务下面的模块和主机
                    add_business_server(mid_obj[0].created_by, i["bk_biz_id"], is_all=True)
                except Exception, e:
                    logger.exception('business')
    logger.error(u"更新业务结束")


@task()
def sync_business(username):
    updata_business()


# 异步对业务下的模块下的主机信息进行更新，包括系统类型,主机名称等
@task()
def add_business_server(username, business_id, is_all=False):
    print "----------------------------:"
    # 从数据库中抓取传入的业务id对应的业务
    biz_item = Business.objects.get(id=business_id)
    # 获取业务下的主机
    ip_list = ESBTools.get_host_ip_list(username, business_id)
    if ip_list["result"]:
        biz_item.module_set.exclude(id=business_id).delete()
        moduel_obj_list = biz_item.module_set.filter(id=business_id)
        # 判断当前业务信息的承载模块是否已同步到数据库中，有数据则更新，没有数据就新增一条
        # 当前模块的使用没有意义，只采用了一个概念上的模块来承载业务下所有的主机 2018.11.12
        if moduel_obj_list:
            moduel_obj = moduel_obj_list[0]
        else:
            moduel_obj = biz_item.module_set.create(id=business_id, name=biz_item.name)
        #     对模块下的主机信息进行更新
        create_add_server(ip_list, moduel_obj)


# 更新模块下的主机信息
def create_add_server(ip_list, moduel_obj):
    # 拿到主机数据列表
    data = ip_list["data"]["info"]
    # 默认清除所有当前模块下的主机数据
    moduel_obj.servers_set.all().update(is_delete=True)
    for j in data:
        item = j["host"]
        if item["bk_os_type"] == u'1':
            bk_os_type = "Linux"
        elif item["bk_os_type"] == u'2':
            bk_os_type = "Windows"
        else:
            bk_os_type = ""
        # 对照数据库，如果数据库中对应主机已存在，就更新信息，就更新信息，不存在，就创建，这里使用了标志位，使用逻辑删除方案保留了主机数据
        if moduel_obj.servers_set.filter(ip=item['bk_host_innerip']):
            moduel_obj.servers_set.filter(ip=item['bk_host_innerip']).update(is_delete=False,
                                                                   source=item['bk_cloud_id'][0]["bk_inst_id"],sys_type=bk_os_type,
                                 operation_system=item["bk_os_name"],hostname=item["bk_host_name"])
        else:
            moduel_obj.servers_set.create(ip=item['bk_host_innerip'], source=item['bk_cloud_id'][0]["bk_inst_id"],is_delete=False,sys_type=bk_os_type,
                                 operation_system=item["bk_os_name"],hostname=item["bk_host_name"])
    moduel_obj.servers_set.filter(is_delete=True).delete()



@periodic_task(run_every=crontab(minute='50', hour='1', day_of_week="*"))
def config_sync(type=''):
    logger.error('start sync mw')
    # idlist = [i.id for i in Middleware.objects.filter(is_delete=False)]
    if type=='':
        filer_obj = Middleware.objects.filter(is_delete=False)
    else:
        filer_obj = Middleware.objects.filter(is_delete=False,type__name=type)
    for i in filer_obj:
        start_config_linux([i.id])
        start_config_win([i.id])
    sync_connect()

@periodic_task(run_every=crontab(minute='50', hour='2', day_of_week="*"))
def beifen_mw():
    for z in Middleware.objects.filter(is_time=True):
        mid_obj = z
        his_mid_obj = mid_obj.historymiddleware_set.create(
            **{'create_time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))})
        for i in mid_obj.configtype_set.all().values():
            next_id = i['id']
            i.pop('id')
            i.pop('midware_id')
            new_obj = his_mid_obj.historyconfigtype_set.create(**i)
            for g in ConfigType.objects.get(id=next_id).configitem_set.all().values():
                g.pop('id')
                g.pop('config_type_id')
                new_obj.historyconfigitem_set.create(**g)


@periodic_task(run_every=crontab(minute='*/5', hour='*', day_of_week="*"))
def sync_connect(pid=''):
    if pid:
        mid_obj = Middleware.objects.filter(id=pid)
    else:
        mid_obj = Middleware.objects.filter(is_delete=False)
    for i in mid_obj:
        if i.state=='waitting':
            continue
        if ConfigItem.objects.filter(config_type__midware=i,key='error'):
            i.state = 'fail'
        else:
            i.state = 'success'
            if ConfigItem.objects.filter(config_type__midware=i).count()==0:
                i.state = 'fail'
            if i.configtype_set.all().count()==1:
                i.state = 'fail'
        i.save()


from home_application.helper import aes_decrypt, encrypt

@task()
def btn_sync():
    sync_cmdb()

@periodic_task(run_every=crontab(minute='*/30', hour='*', day_of_week="*"))
def sync_cmdb():
    if Setting.objects.get(key='cmdb_op').value == '0':
        return
    common_account = 'admin'
    id_list = []
    mw_name = 'weblogic'
    cmdb_name = 'weblogic'
    inst_name = 'weblogic_inst'
    if MiddlewareType.objects.filter(name=mw_name):
        mw_type_web = MiddlewareType.objects.get(name=mw_name)
        cmdb_data = get_cmdb_mw(cmdb_name)
        weblogic_inst_cmdb = get_cmdb_mw(inst_name)
        inst_data = {}
        for inst_mid in weblogic_inst_cmdb:
            mid_dict = {inst_mid['listen_port']: inst_mid}
            mid_key = str(inst_mid['belong_weblogic'][0]['bk_inst_id'])
            inst_data[mid_key] = dict(mid_dict, **inst_data.get(mid_key, {}))
        if cmdb_data.__len__() == 0:
            get_scret = []
        else:
            get_scret = get_cc_auto_mw(cmdb_name, '')
        all_scret = {}
        for z in get_scret:
            all_scret[str(z['bk_inst_id'])] = z
        for i in cmdb_data:
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id'], last_time=i['last_time']):
                continue
            mid_scret = all_scret.get(str(i['bk_inst_id']), {})
            ret_scret = [
                {'key': 'wlst', 'value': i['wlst_path'], 'display': u'wlst路径'},
                {'key': 'accout', 'value': mid_scret.get('username', ''), 'display': u'账号'},
                {'key': 'pass', 'value': encrypt(aes_decrypt(mid_scret.get('password', ''))), 'display': u'密码'},
                {'key': 'operate', 'value': i['wlst_path'], 'display': u'启停路径'},
            ]
            mid_filter = {
                'ip': i['ip_addr'],
                'port': i['port'],
                'bk_inst_id': i['bk_inst_id'],
            }
            if i['ip_addr']=='' or  i['port']=='':
                continue
            mid_inst = {'admin': i, 'inst': inst_data.get(str(i['bk_inst_id']), '')}

            # 存在bk_inst_id
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']):
                # 基本凭据不变
                if mw_type_web.middleware_set.filter(**mid_filter):
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.bk_data = mid_inst
                    mw_obj.save()
                    change_op = False
                    for z in ret_scret:
                        if mw_obj.configpath_set.filter(**z):
                            pass
                        else:
                            change_op = True
                            mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    if change_op:
                        id_list.append(mw_obj.id)
                        insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
                else:
                    mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']).update(**mid_filter)
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.bk_data = mid_inst
                    mw_obj.save()
                    for z in ret_scret:
                        mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    id_list.append(mw_obj.id)
                    insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
            else:
                mid_filter['bk_data'] = mid_inst
                mid_filter['last_time'] = i['last_time']
                mid_filter['creator'] = common_account
                mid_filter['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
                mw_obj = mw_type_web.middleware_set.create(**mid_filter)
                for z in ret_scret:
                    mw_obj.configpath_set.create(**z)
                id_list.append(mw_obj.id)
                insert_log(u'配置管理', common_account, u'添加中间件(cmdb):' + mw_name + '/' + i['ip_addr'])

    mw_name = 'tomcat'
    cmdb_name = 'tomcat'
    if MiddlewareType.objects.filter(name=mw_name):
        mw_type_web = MiddlewareType.objects.get(name=mw_name)
        for i in get_cmdb_mw(cmdb_name):
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id'], last_time=i['last_time']):
                continue
            ret_scret = [
                {'key': 'jvm', 'value': i['jvm_path'], 'display': u'JVM路径'},
                {'key': 'server', 'value': i['server_path'], 'display': u'tomcat路径'},
                {'key': 'user', 'value': i['user_conf_path'], 'display': u'用户配置路径'},
                {'key': 'jmx_port', 'value': i['jmx_port'], 'display': u'JMX端口'},
            ]
            mid_filter = {
                'ip': i['ip_addr'],
                'port': i['port'],
                'bk_inst_id': i['bk_inst_id'],
            }

            # 存在bk_inst_id
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']):
                # 基本凭据不变
                if mw_type_web.middleware_set.filter(**mid_filter):
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.save()
                    change_op = False
                    for z in ret_scret:
                        if mw_obj.configpath_set.filter(**z):
                            pass
                        else:
                            change_op = True
                            mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    if change_op:
                        id_list.append(mw_obj.id)
                        insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
                else:
                    mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']).update(**mid_filter)
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.save()
                    for z in ret_scret:
                        mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    id_list.append(mw_obj.id)
                    insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
            else:
                # 不存在bk_inst_id

                mid_filter['last_time'] = i['last_time']
                mid_filter['creator'] = common_account
                mid_filter['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
                mw_obj = mw_type_web.middleware_set.create(**mid_filter)
                for z in ret_scret:
                    mw_obj.configpath_set.create(**z)
                id_list.append(mw_obj.id)
                insert_log(u'配置管理', common_account, u'添加中间件(cmdb):' + mw_name + '/' + i['ip_addr'])

    mw_name = 'apache'
    cmdb_name = 'apache'
    if MiddlewareType.objects.filter(name=mw_name):
        mw_type_web = MiddlewareType.objects.get(name=mw_name)
        for i in get_cmdb_mw(cmdb_name):
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id'], last_time=i['last_time']):
                continue
            ret_scret = [
                {'key': 'version', 'value': i['bin_path'], 'display': u'bin路径'},
                {'key': 'httpd', 'value': i['httpd_path'], 'display': u'httpd路径'},
                {'key': 'vhost', 'value': i['vhost_path'], 'display': u'vhost路径'},
            ]
            mid_filter = {
                'ip': i['ip_addr'],
                'port': i['listen_port'],
                'bk_inst_id': i['bk_inst_id'],
            }

            # 存在bk_inst_id
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']):
                # 基本凭据不变
                if mw_type_web.middleware_set.filter(**mid_filter):
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.save()
                    change_op = False
                    for z in ret_scret:
                        if mw_obj.configpath_set.filter(**z):
                            pass
                        else:
                            change_op = True
                            mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    if change_op:
                        id_list.append(mw_obj.id)
                        insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
                else:
                    mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']).update(**mid_filter)
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.save()
                    for z in ret_scret:
                        mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    id_list.append(mw_obj.id)
                    insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
            else:
                # 不存在bk_inst_id
                mid_filter['last_time'] = i['last_time']
                mid_filter['creator'] = common_account
                mid_filter['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
                mw_obj = mw_type_web.middleware_set.create(**mid_filter)
                for z in ret_scret:
                    mw_obj.configpath_set.create(**z)
                id_list.append(mw_obj.id)
                insert_log(u'配置管理', common_account, u'添加中间件(cmdb):' + mw_name + '/' + i['ip_addr'])

    mw_name = 'websphere'
    cmdb_name = 'websphere'
    if MiddlewareType.objects.filter(name=mw_name):
        mw_type_web = MiddlewareType.objects.get(name=mw_name)
        cmdb_data = get_cmdb_mw(cmdb_name)
        if cmdb_data.__len__() == 0:
            get_scret = []
        else:
            get_scret = get_cc_auto_mw(cmdb_name, '')
        all_scret = {}
        for z in get_scret:
            all_scret[z['bk_inst_id']] = z
        for i in cmdb_data:
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id'], last_time=i['last_time']):
                continue
            mid_scret = all_scret.get(i['bk_inst_id'], {})
            if not mid_scret.get('password', False):
                continue
            if not mid_scret.get('username', False):
                continue
            ret_scret = [
                {'key': 'wsadmin', 'value': i['wlst_path'], 'display': u'wsadmin路径'},
                {'key': 'accout', 'value': mid_scret['username'], 'display': u'账号'},
                {'key': 'pass', 'value': encrypt(aes_decrypt(mid_scret['password'])), 'display': u'密码'},
            ]
            mid_filter = {
                'ip': i['ip_addr'],
                'port': i['port'],
                'bk_inst_id': i['bk_inst_id'],
            }

            # 存在bk_inst_id
            if mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']):
                # 基本凭据不变
                if mw_type_web.middleware_set.filter(**mid_filter):
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.save()
                    change_op = False
                    for z in ret_scret:
                        if mw_obj.configpath_set.filter(**z):
                            pass
                        else:
                            change_op = True
                            mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    if change_op:
                        id_list.append(mw_obj.id)
                        insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
                else:
                    mw_type_web.middleware_set.filter(bk_inst_id=i['bk_inst_id']).update(**mid_filter)
                    mw_obj = mw_type_web.middleware_set.get(bk_inst_id=i['bk_inst_id'])
                    mw_obj.last_time = i['last_time']
                    mw_obj.save()
                    for z in ret_scret:
                        mw_obj.configpath_set.filter(key=z['key']).update(**z)
                    id_list.append(mw_obj.id)
                    insert_log(u'配置管理', common_account, u'修改中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
            else:
                mid_filter['last_time'] = i['last_time']
                mid_filter['creator'] = common_account
                mid_filter['create_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
                mw_obj = mw_type_web.middleware_set.create(**mid_filter)
                for z in ret_scret:
                    mw_obj.configpath_set.create(**z)
                id_list.append(mw_obj.id)
                insert_log(u'配置管理', common_account, u'添加中间件(cmdb):' + mw_name + '/' + i['ip_addr'])
    logger.error('sync:' + str(id_list))
    if not id_list.__len__() == 0:
        for zz in id_list:
            start_config.delay([zz])


@task()
def start_config(idlist):
    mid_obj = Middleware.objects.get(id=idlist[0])
    try:
        os_type = Servers.objects.get(ip=mid_obj.ip).sys_type
    except:
        os_type = 'Linux'
    if os_type != 'Windows':
        start_config_linux(idlist)
    else:
        start_config_win(idlist)
    mid_obj.state='running'
    mid_obj.save()
    sync_connect(idlist[0])


# [{'ip':'192','app_id':'1','source':123,'creator':'','script'}]
def start_config_linux(idlist):
    logger.error(u'开始同步配置')
    all_list = []
    tomcat_list = []
    weblogic_list = []
    apache_list = []
    websphere_list = []
    jboss_list = []
    for i in idlist:
        try:
            mid_obj = Middleware.objects.get(id=i)
            ip_obj = Servers.objects.get(ip=mid_obj.ip)
            if ip_obj.sys_type == 'Windows':
                continue
            mid_scripts = 'cat %s'
            mid_script = {}
            mid_path = {}
            for l in mid_obj.configpath_set.all():
                midpath = l.value
                mid_script[l.key] = mid_scripts % (midpath)
                mid_path[l.key] = midpath

            mid_ret = {'id': i, 'ip': mid_obj.ip, 'app_id': ip_obj.module.business_id, 'source': ip_obj.source,
                       'creator': mid_obj.creator, 'script': mid_script, 'path': mid_path}
            all_list.append(mid_ret)
            if mid_obj.type.name == 'tomcat':
                tomcat_list.append(mid_ret)
            if mid_obj.type.name == 'weblogic':
                weblogic_list.append(mid_ret)
            if mid_obj.type.name == 'apache':
                apache_list.append(mid_ret)
            if mid_obj.type.name == 'websphere':
                websphere_list.append(mid_ret)
            if mid_obj.type.name == 'jboss':
                jboss_list.append(mid_ret)
        except Exception,e:
            logger.exception('make_list_error')
    # tomcat
    try:
        get_base_data = RGMiddleWare(tomcat_list, 'root', False).get_tomcat_jmx()
        make_tomcat_data(get_base_data)
        # make_base_jvm(get_base_data['jvm'])
        # make_base_server(get_base_data['server'])
        # make_base_user(get_base_data['user'])
    except Exception, e:
        logger.exception('linux_tomcat')
    # weblogic
    try:
        get_base_data_weblogic = RGMiddleWare(weblogic_list, 'root', False).get_weblogic_wlst()
        make_weblogic_data(get_base_data_weblogic)
        make_weblogic_monitor(get_base_data_weblogic)
    except Exception, e:
        logger.exception('linux_weblogic')

    try:
        get_base_data_websphere = RGMiddleWare(websphere_list, 'root', False).get_websphere_data()
        make_websphere_data(get_base_data_websphere)
        make_websphere_monitor(get_base_data_websphere)
    except Exception, e:
        logger.exception('linux_wesphere')
    # apache
    try:
        get_base_data_web = RGMiddleWare(apache_list, 'root', True).get_apache_base_config()
        get_version = RGMiddleWare(apache_list, 'root', False).run_apache()
        # make_base_jvm(get_base_data_web['jvm'])
        # make_base_server(get_base_data_web['server'],'weblogic')
        make_apache_data_version(get_version)
        make_apache_data_httpd(get_base_data_web['httpd'])
        make_apache_data_httpd_host(get_base_data_web['vhost'])

    except Exception, e:
        logger.exception('linux_apache')
    # server base info
    try:
        base_data = RGMiddleWare(all_list, 'root').get_server_base()
        make_server_info_data(base_data)
    except Exception, e:
        logger.exception('linux_server')

    # jboss
    try:
        get_base_jboss = RGMiddleWare(jboss_list, 'root', False).get_jboss()
        make_jboss_data(get_base_jboss)
        make_jboss_monitor(get_base_jboss)
    except Exception, e:
        logger.exception('linux_jbss')

    # monitor
    try:
        make_tomcat_monitor(tomcat_list)
    except Exception, e:
        logger.exception('lin_monitor')
    logger.error(u'结束同步配置')


def start_config_win(idlist):
    logger.info(u'Windows,开始同步配置')
    all_list = []
    tomcat_list = []
    weblogic_list = []
    apache_list = []
    websphere_list = []
    for i in idlist:
        try:
            mid_obj = Middleware.objects.get(id=i)
            ip_obj = Servers.objects.get(ip=mid_obj.ip)
        except Exception, e:
            logger.exception(u"获取基本业务、服务器信息异常,任务中断")
            return False
        if ip_obj.sys_type == 'Linux':
            continue
        mid_scripts = 'type %s'
        mid_script = {}
        mid_path = {}
        for l in mid_obj.configpath_set.all():
            midpath = l.value
            mid_script[l.key] = mid_scripts % (midpath)
            mid_path[l.key] = midpath

        mid_ret = {'id': i, 'ip': mid_obj.ip, 'app_id': ip_obj.module.business_id, 'source': ip_obj.source,
                   'creator': mid_obj.creator, 'script': mid_script, 'path': mid_path}
        all_list.append(mid_ret)
        if mid_obj.type.name == 'tomcat':
            tomcat_list.append(mid_ret)
        if mid_obj.type.name == 'weblogic':
            weblogic_list.append(mid_ret)
        if mid_obj.type.name == 'apache':
            apache_list.append(mid_ret)
        if mid_obj.type.name == 'websphere':
            websphere_list.append(mid_ret)

    if tomcat_list:
        # tomcat
        try:
            logger.info(u"windows,tomcat信息同步开始")
            get_base_data = RGMiddleWareWindows(tomcat_list, 'system', False).get_tomcat_jmx()
            if get_base_data:
                data_maker.make_tomcat_data(get_base_data)
            else:
                logger.error(u"tomcat信息同步失败")
            logger.info(u"windows,tomcat信息同步结束")
            # make_base_jvm(get_base_data['jvm'])
            # make_base_server(get_base_data['server'])
            # make_base_user(get_base_data['user'])
        except Exception, e:
            logger.exception(u'windows,tomcat信息同步异常')

    if weblogic_list:
        # weblogic
        try:
            logger.info(u"weblogic信息同步开始")
            get_base_data_weblogic = RGMiddleWareWindows(weblogic_list, 'system', False).get_weblogic_wlst()
            if get_base_data_weblogic:
                ip_list=[{"ip":weblogic_list[0]["ip"],"bk_cloud_id":weblogic_list[0]["source"]}]
                bk_biz_id=weblogic_list[0]["app_id"]
                data_maker.make_weblogic_data(get_base_data_weblogic,ip_list,bk_biz_id)
                data_maker.make_weblogic_monitor(get_base_data_weblogic)
            else:
                logger.error(u"获取weblogic信息失败")
            logger.info(u"weblogic信息同步结束")
        except Exception, e:
            logger.exception(u"weblogic信息同步异常")

    if apache_list:
        # apache
        try:
            logger.info(u"apache信息同步开始")
            get_base_data_web = RGMiddleWareWindows(apache_list, 'system', True).get_apache_base_config()
            flag1=False
            flag2=False
            if get_base_data_web:
                flag1 = True
            else:
                logger.error(u"获取apache服务器信息失败")
            get_version = RGMiddleWareWindows(apache_list, 'system', False).run_apache()
            if get_version:
                flag2 = True
            else:
                logger.error(u"获取apache代理信息失败")

            if flag1 and flag2:
                data_maker.make_apache_data_version(get_version)
                data_maker.make_apache_data_httpd(get_base_data_web['httpd'])
                data_maker.make_apache_data_httpd_host(get_base_data_web['vhost'])
            logger.info(u"apache信息同步结束")
            # make_base_jvm(get_base_data_web['jvm'])
            # make_base_server(get_base_data_web['server'],'weblogic')
        except Exception, e:
            logger.exception(u'apache信息同步异常')

    if websphere_list:
        pass

    # server base info
    logger.info(u"windows,服务器全局信息同步开始")
    try:
        base_data = RGMiddleWareWindows(all_list, 'system').get_server_base()
        if base_data:
            data_maker.make_server_info_data(base_data)
        else:
            logger.error(u"获取服务器全局信息失败")
        logger.info(u"windows,服务器全局信息同步结束")

    except Exception, e:
        logger.exception(u'windows,服务器全局信息同步异常')

    # monitor
    try:
        logger.info(u"windows,tomcat应用信息同步开始")
        data = RGMiddleWareWindows(tomcat_list, 'system', False).get_file_dir('jvm')
        if data["result"]:
            data_maker.make_monitor_data(data)
        else:
            logger.error(u"获取tomcat应用目录失败")
        logger.info(u"windows,tomcat应用信息同步结束")
    except Exception, e:
        logger.exception(u'windows,tomcat应用信息同步异常')
    logger.info(u'windows,结束同步配置')


def make_server_info_data(base_data):
    for a in base_data['success']:
        for b in Middleware.objects.filter(ip=a['ip']):
            if b.configtype_set.filter(name='os'):
                next_obj = b.configtype_set.get(name='os')
            else:
                next_obj = b.configtype_set.create(**{'name': 'os', 'display': '服务器配置'})
            next_obj.configitem_set.all().delete()
            if type(a['val']) == type([]):
                for c in a['val']:
                    next_obj.configitem_set.create(**c)
            else:
                next_obj.configitem_set.create(**{'value': str(a['val']), 'display': u'错误', 'key': u'error'})
    for c in base_data['error']:
        for d in Middleware.objects.filter(ip=c['ip']):
            if d.configtype_set.filter(name='os'):
                next_obj = d.configtype_set.get(name='os')
            else:
                next_obj = d.configtype_set.create(**{'name': 'os', 'display': '服务器配置'})
            next_obj.configitem_set.all().delete()
            next_obj.configitem_set.create(**{'value': str(c['error']), 'display': u'错误', 'key': u'error'})


def make_server_info_data_win(base_data):
    for a in base_data['success']:
        for b in Middleware.objects.filter(ip=a['ip']):
            if b.configtype_set.filter(name='os'):
                next_obj = b.configtype_set.get(name='os')
            else:
                next_obj = b.configtype_set.create(**{'name': 'os', 'display': '服务器配置'})
            next_obj.configitem_set.all().delete()
            if type(a['val']) == type([]):
                for c in a['val']:
                    next_obj.configitem_set.create(**c)
            else:
                next_obj.configitem_set.create(**{'value': str(a['val']), 'display': u'错误', 'key': u'error'})
    for c in base_data['error']:
        for d in Middleware.objects.filter(ip=c['ip']):
            if d.configtype_set.filter(name='os'):
                next_obj = d.configtype_set.get(name='os')
            else:
                next_obj = d.configtype_set.create(**{'name': 'os', 'display': '服务器配置'})
            next_obj.configitem_set.all().delete()
            next_obj.configitem_set.create(**{'value': str(c['error']), 'display': u'错误', 'key': u'error'})


def make_base_jvm(data):
    if data['result']:
        for a in data['data']:
            mw_obj = Middleware.objects.get(id=a['id'])
            xml_data = a['comback']['logContent']
            if mw_obj.configtype_set.filter(name='jvm'):
                mw_obj.configtype_set.filter(name='jvm').update(
                    **{'name': 'jvm', 'display': 'JVM配置', 'xml': xml_data, 'xml_path': a['path']['jvm']})
                next_obj = mw_obj.configtype_set.get(name='jvm')
            else:
                next_obj = mw_obj.configtype_set.create(
                    **{'name': 'jvm', 'display': 'JVM配置', 'xml': xml_data, 'xml_path': a['path']['jvm']})
            next_obj.configitem_set.all().delete()
            if a['result']:
                item_list = a['jvm_data']
                for c in item_list:
                    next_obj.configitem_set.create(**c)
            else:
                next_obj.configitem_set.filter(key='error').delete()
                next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})


def make_tomcat_data(data):
    for keys in data.keys():
        a = data[keys]
        mw_obj = Middleware.objects.get(id=keys)
        try:
            tomcat_jvm_cell(mw_obj, a)
        except Exception, e:
            logger.error(str(e))
        try:
            tomcat_config_cell(mw_obj, a)
        except Exception, e:
            logger.error(str(e))
        try:
            tomcat_user_cell(mw_obj, a)
        except Exception, e:
            logger.error(str(e))


def tomcat_jvm_cell(mw_obj, a):
    if mw_obj.configtype_set.filter(name='jvm'):
        mw_obj.configtype_set.filter(name='jvm').update(
            **{'name': 'jvm', 'display': 'JVM配置', 'xml': '', 'xml_path': ''})
        next_obj = mw_obj.configtype_set.get(name='jvm')
    else:
        next_obj = mw_obj.configtype_set.create(
            **{'name': 'jvm', 'display': 'JVM配置', 'xml': '', 'xml_path': ''})
    next_obj.configitem_set.all().delete()
    if a.get('error', False):
        next_obj.configitem_set.filter(key='error').delete()
        next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})
    else:
        item_val = a['HeapMemoryUsage']
        heap_key = {'max': u'堆最大分配空间', 'used': u'当前堆使用空间'}
        for z in heap_key.keys():
            if item_val[z] == '-1':
                mid_val = '-1'
            else:
                try:
                    mid_val = '%.2f' % (float(item_val[z]) / float(1048576)) + 'MB'
                except:
                    mid_val = ''
            next_obj.configitem_set.create(**{'value': mid_val, 'display': heap_key[z], 'key': z})
        item_val = a['Usage']
        heap_key = {'max': u'持久堆内存最大分配空间', 'used': u'持久堆内存使用大小'}
        for z in heap_key.keys():
            if item_val[z] == '-1':
                mid_val = '-1'
            else:
                try:
                    mid_val = '%.2f' % (float(item_val[z]) / float(1048576)) + 'MB'
                except:
                    mid_val = ''
            next_obj.configitem_set.create(**{'value': mid_val, 'display': heap_key[z], 'key': z})


def tomcat_config_cell(mw_obj, a):
    if mw_obj.configtype_set.filter(name='server'):
        mw_obj.configtype_set.filter(name='server').update(
            **{'name': 'server', 'display': 'tomcat配置', 'xml': '', 'xml_path': ''})
        next_obj = mw_obj.configtype_set.get(name='server')
    else:
        next_obj = mw_obj.configtype_set.create(
            **{'name': 'server', 'display': 'tomcat配置', 'xml': '', 'xml_path': ''})
    next_obj.configitem_set.all().delete()
    if a.get('error', False):
        next_obj.configitem_set.filter(key='error').delete()
        next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})
    else:
        next_obj.configitem_set.create(**{'value': a['stateName'], 'display': 'stateName', 'key': 'stateName'})
        next_obj.configitem_set.create(**{'value': a['shutdown'], 'display': 'shutdown', 'key': 'shutdown'})
        service_data = a['Service']
        try:
            service_val = [{'key': 'name', 'display': 'name', 'value': service_data['name']}]
            for connects in service_data['Connector']:
                mid_val = []
                for z in ['port', 'protocol', 'connectionTimeout', 'redirectPort']:
                    mid_val.append({'key': z, 'display': z, 'value': connects[z]})
                service_val.append({'key': 'Connector', 'display': 'Connector', 'value': mid_val, 'rgtypeof': True})
            mid_en_val = []
            engine_data = service_data['Engine']
            mid_en_val.append({'key': 'name', 'display': 'name', 'value': engine_data['name']})
            mid_en_val.append({'key': 'defaultHost', 'display': 'defaultHost', 'value': engine_data['defaultHost']})
            for host_cell in service_data['Engine']['host']:
                mid_val = []
                for z in ['name', 'appBase', 'unpackWARs', 'autoDeploy']:
                    mid_val.append({'key': z, 'display': z, 'value': host_cell[z]})
                mid_en_val.append({'key': 'Host', 'display': 'Host', 'value': mid_val, 'rgtypeof': True})
            service_val.append({'key': 'Engine', 'display': 'Engine', 'value': mid_en_val, 'rgtypeof': True})
            next_obj.configitem_set.create(**{'value': service_val, 'display': 'Service', 'key': 'Service'})
        except Exception, e:
            print e


def tomcat_user_cell(mw_obj, a):
    if mw_obj.configtype_set.filter(name='user'):
        mw_obj.configtype_set.filter(name='user').update(
            **{'name': 'user', 'display': '权限配置', 'xml': '', 'xml_path': ''})
        next_obj = mw_obj.configtype_set.get(name='user')
    else:
        next_obj = mw_obj.configtype_set.create(
            **{'name': 'user', 'display': '权限配置', 'xml': '', 'xml_path': ''})
    next_obj.configitem_set.all().delete()
    if a.get('error', False):
        logger.error(str(a['error']))
        next_obj.configitem_set.filter(key='error').delete()
        next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})
    else:
        for user_cell in a['user'].keys():
            try:
                mid_role = ','.join(a['user'][user_cell])
            except:
                mid_role = ''
            mid_val = [{'key': 'username', 'display': 'username', 'value': user_cell},
                       {'key': 'roles', 'display': 'roles', 'value': mid_role}]
            next_obj.configitem_set.create(**{'value': mid_val, 'display': 'User', 'key': 'user'})


def make_base_server(data, type='tomcat'):
    if data['result']:
        for a in data['data']:
            xml_data = a['comback']['logContent']
            mw_obj = Middleware.objects.get(id=a['id'])
            if mw_obj.configtype_set.filter(name='server'):
                mw_obj.configtype_set.filter(name='server').update(
                    **{'name': 'server', 'display': type + '配置', 'xml': xml_data, 'xml_path': a['path']['server']})
                next_obj = mw_obj.configtype_set.get(name='server')
            else:
                next_obj = mw_obj.configtype_set.create(
                    **{'name': 'server', 'display': type + '配置', 'xml': xml_data, 'xml_path': a['path']['server']})
            next_obj.configitem_set.all().delete()
            if a['result']:
                item_list = a['server_data']['value']
                for c in item_list:
                    next_obj.configitem_set.create(**{'value': c['value'], 'display': c['display'], 'key': c['key']})
            else:
                next_obj.configitem_set.filter(key='error').delete()
                next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})


def make_base_user(data):
    if data['result']:
        for a in data['data']:
            xml_data = a['comback']['logContent']
            mw_obj = Middleware.objects.get(id=a['id'])
            if mw_obj.configtype_set.filter(name='user'):
                mw_obj.configtype_set.filter(name='user').update(
                    **{'name': 'user', 'display': '权限配置', 'xml': xml_data, 'xml_path': a['path']['user']})
                next_obj = mw_obj.configtype_set.get(name='user')
            else:
                next_obj = mw_obj.configtype_set.create(
                    **{'name': 'user', 'display': '权限配置', 'xml': xml_data, 'xml_path': a['path']['user']})
            next_obj.configitem_set.all().delete()
            if a['result']:
                item_list = a['user_data']['value']
                for c in item_list:
                    next_obj.configitem_set.create(**{'value': c['value'], 'display': c['display'], 'key': c['key']})
            else:
                next_obj.configitem_set.filter(key='error').delete()
                next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})


def make_tomcat_monitor(tomcat_list):
    data = RGMiddleWare(tomcat_list, 'root', False).get_file_dir('jvm')
    make_monitor_data(data)


def make_monitor_data(data):
    if data['result']:
        for a in data['data']:
            xml_data = a['comback']['logContent']
            applist = xml_data.split('\n')

            mw_obj = Middleware.objects.get(id=a['id'])
            service_data = mw_obj.configtype_set.get(name='server').configitem_set.get(key='Service').value
            service_dict = eval(service_data)
            mid_connect = []
            servername = ''
            for i in service_dict:
                if i['key'] == 'name':
                    servername = i['value']
                if i['key'] == 'Connector':
                    for u in i['value']:
                        if u['key'] == 'protocol' and ('HTTP' in u['value']):
                            mid_connect = i['value']
            mid_port = ''
            for z in mid_connect:
                if z['key'] == 'port':
                    mid_port = servername + '(' + z['value'] + ')'
            if mw_obj.instance_set.filter(name=mid_port):
                nextobj = mw_obj.instance_set.get(name=mid_port)
            else:
                nextobj = mw_obj.instance_set.create(name=mid_port)
            nextobj.application_set.all().delete()
            for y in applist:
                if y:
                    nextobj.application_set.create(name=y)


def make_weblogic_monitor(data):
    if data['result']:
        for d in data['data']:
            mw_obj = Middleware.objects.get(id=d['id'])
            try:
                xml_data = eval(d['comback']['logContent'])
            except:
                xml_data = {}
            name_list = [m.name for m in mw_obj.instance_set.all()]
            for i in mw_obj.configtype_set.get(name='server').configitem_set.all():
                service_dict = eval(i.value)
                mid_key = ''
                mid_val = ''
                mid_all = {'admin_server': str(d['id']) + '%%' + mw_obj.ip + ':' + mw_obj.port}
                for z in service_dict:
                    if z['key'] == 'Name':
                        mid_key = z['value']
                    if z['key'] == 'ListenPort':
                        mid_val = z['value']
                    if z['key'] == 'WeblogicHome':
                        if z['value']:
                            if z['value'].endswith('/'):
                                mid_all['wlst'] = z['value'] + 'common/bin/wlst.sh'
                            else:
                                mid_all['wlst'] = z['value'] + '/common/bin/wlst.sh'
                        else:
                            mid_all['wlst'] = ''
                    if z['key'] == 'ListenAddress':
                        if z['value']:
                            mid_all['ip'] = z['value']
                        else:
                            mid_all['ip'] = mw_obj.ip
                    if z['key'] == 'ListenPort':
                        mid_all['port'] = z['value']
                    if z['key'] == 'WeblogicVersion':
                        mid_all['WeblogicVersion'] = z['value']
                    if z['key'] == 'patch_path':
                        mid_all['patch_path'] = z['value']
                val_name = mid_key + '(' + mid_val + ')'
                if mw_obj.instance_set.filter(name=val_name):
                    next_obj = mw_obj.instance_set.get(name=val_name)
                    next_obj.value = str(mid_all)
                    next_obj.save()
                    name_list.remove(val_name)
                else:
                    next_obj = mw_obj.instance_set.create(name=val_name, value=str(mid_all))
                next_obj.application_set.all().delete()
                try:
                    for c in xml_data['app'].get(mid_key, []):
                        next_obj.application_set.create(name=c)
                except Exception, e:
                    pass
            for z in name_list:
                mw_obj.instance_set.filter(name=z).delete()


def make_websphere_monitor(data):
    if data['result']:
        for d in data['data']:
            mw_obj = Middleware.objects.get(id=d['id'])
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_websphere'), 'r').read()
            data = d['comback']['logContent']
            mid_data_list = data.split('!-----!')
            detail_data = mid_data_list[0]
            if '_____' in detail_data:
                detail_data = detail_data.split('_____')[1].split('_____')[0]
            base_data = eval(detail_data)
            name_list = [m.name for m in mw_obj.instance_set.all()]
            for node in base_data.values()[0]['node'].keys():
                node_data = base_data.values()[0]['node'][node]
                for server in node_data['server'].keys():
                    if server == 'version':
                        continue
                    if mw_obj.instance_set.filter(name=server):
                        next_obj = mw_obj.instance_set.get(name=server)
                        name_list.remove(server)
                    else:
                        next_obj = mw_obj.instance_set.create(name=server)
                    next_obj.application_set.all().delete()
                    try:
                        for app in node_data['server'][server]['app']:
                            next_obj.application_set.create(name=app)
                    except:
                        pass
            for z in name_list:
                mw_obj.instance_set.filter(name=z).delete()


def make_jboss_monitor(data):
    if data['result']:
        for d in data['data']:
            mw_obj = Middleware.objects.get(id=d['id'])
            if mw_obj.is_cluster:
                jboss_monitor_cli(mw_obj, d)
            else:
                jboss_monitor_alone(mw_obj, d)

def jboss_monitor_cli(mw_obj,d):
    data = d['comback']['logContent']
    data = data.replace('=>', ':').replace('expression "', '"').replace('L,', ',').replace('L\n', '\n').replace(
        '("', '{"').replace('")', '"}').replace('\n', '').replace('\'', '"').replace(' ', '').replace(
        'undefined', '""')
    data = data[:-3] + "}}"
    all_i = []
    for i in data.split('bytes{'):
        if not i.startswith('{'):
            mid_list = i.split('}')
            end_str = "}".join(mid_list[1:])
            all_i.append(end_str)
        else:
            all_i.append(i)
    data = '""'.join(all_i)
    end_data = json.loads(data)

    name_list = [m.name for m in mw_obj.instance_set.all()]
    for host in end_data['host'].values():
        host = host['result']
        for server in host['server-config'].values():
            server_name = host['name'] + ':' + server['name']
            app_list = []
            if end_data['server']['result']['server-group'].get(server['group'], False):
                group_data = end_data['server']['result']['server-group'][server['group']]
                app_list = group_data['deployment']
                if end_data['server']['result']['socket-binding-group'].get(group_data['socket-binding-group'], False):
                    socket_data = end_data['server']['result']['socket-binding-group'][
                        group_data['socket-binding-group']]
                    server_name = server_name + '(' + str(socket_data['socket-binding']['http']['port']) + ')'
            if mw_obj.instance_set.filter(name=server_name):
                next_obj = mw_obj.instance_set.get(name=server_name)
                name_list.remove(server_name)
            else:
                next_obj = mw_obj.instance_set.create(name=server_name)
            next_obj.application_set.all().delete()
            for app in app_list:
                next_obj.application_set.create(name=app)

    for z in name_list:
        mw_obj.instance_set.filter(name=z).delete()

def jboss_monitor_alone(mw_obj,d):
    data = d['comback']['logContent']
    data = data.replace('=>', ':').replace('expression "', '"').replace('L,', ',').replace('L ','').replace('L\n', '\n').replace(
        '("', '{"').replace('")', '"}').replace('\n', '').replace('\'', '"').replace(' ', '').replace(
        'undefined', '""')
    all_i = []
    for i in data.split('bytes{'):
        if not i.startswith('{'):
            mid_list = i.split('}')
            end_str = "}".join(mid_list[1:])
            all_i.append(end_str)
        else:
            all_i.append(i)
    data = '""'.join(all_i)
    end_data = json.loads(data)

    name_list = [m.name for m in mw_obj.instance_set.all()]
    if end_data['outcome']=='success':
        res = end_data['result']
        app_list = res['deployment'].keys()
        server_name =res['name']+"("+str(res['socket-binding-group'].values()[0]['socket-binding']['http']['port'])+")"
        if mw_obj.instance_set.filter(name=server_name):
            next_obj = mw_obj.instance_set.get(name=server_name)
            name_list.remove(server_name)
        else:
            next_obj = mw_obj.instance_set.create(name=server_name)
        next_obj.application_set.all().delete()
        for app in app_list:
            next_obj.application_set.create(name=app)
    for z in name_list:
        mw_obj.instance_set.filter(name=z).delete()

def make_weblogic_data(data):
    key_cmdb = {'AdminServerName': 'admin_server_name', 'RootDirectory': 'root_dir', 'WeblogicVersion': 'version',
                'ConsoleEnabled': 'console_enabled', 'WeblogicHome': 'weblogic_home',
                'ProductionModeEnabled': 'production_mode_enabled', 'MiddlewareHome': 'md_home',
                'AdminConsole': 'admin_console', 'ConsoleContextPath': 'console_context_path',
                'DomainVersion': 'domain_version'}
    inst_key_cmdb = {'Name': 'name', 'ListenAddress': 'ip_addr', 'ListenPort': 'listen_port',
                     'HealthState': 'health_state', 'State': 'state', 'JavaVersion': 'java_version',
                     'AdminServerName': 'admin_server_name', 'RootDirectory': 'root_dir',
                     'ConsoleEnabled': 'console_enabled', 'WeblogicHome': 'weblogic_home',
                     'ProductionModeEnabled': 'production_mode_enabled', 'MiddlewareHome': 'md_home',
                     'ConsoleContextPath': 'console_context_path', 'WeblogicVersion': 'version',
                     'DomainVersion': 'domain_version', 'patch_path': 'patch_path'}
    if data['result']:
        for d in data['data']:
            oid = d['id']
            mid_obj = Middleware.objects.get(id=oid)
            try:
                bk_data = eval(mid_obj.bk_data)
            except:
                bk_data = {}
            if mid_obj.configtype_set.filter(name='root'):
                mid_obj.configtype_set.filter(name='root').update(
                    **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
                root_obj = mid_obj.configtype_set.get(name='root')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
            if mid_obj.configtype_set.filter(name='server'):
                mid_obj.configtype_set.filter(name='server').update(
                    **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
                server_obj = mid_obj.configtype_set.get(name='server')
            else:
                server_obj = mid_obj.configtype_set.create(
                    **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
            # root_obj.configitem_set.all().delete()
            # server_obj.configitem_set.all().delete()

            if d['result']:
                admin_data = bk_data.get('admin', {})
                data = d['comback']['logContent']
                try:
                    data = eval(data)
                except:
                    root_obj.configitem_set.filter(key='error').delete()
                    server_obj.configitem_set.filter(key='error').delete()
                    if bk_data.get('admin', False):
                        make_cmdb_to_weblogic_config(root_obj, server_obj, bk_data, key_cmdb, inst_key_cmdb)
                    else:
                        if root_obj.configitem_set.filter(key='error'):
                            root_obj.configitem_set.filter(key='error').update(
                                **{'value': str(data), 'display': u'错误', 'key': u'error'})
                        else:
                            root_obj.configitem_set.create(**{'value': str(data), 'display': u'错误', 'key': u'error'})
                        if server_obj.configitem_set.filter(key='error'):
                            server_obj.configitem_set.filter(key='error').update(
                                **{'value': str(data), 'display': u'错误', 'key': u'error'})
                        else:
                            server_obj.configitem_set.create(**{'value': str(data), 'display': u'错误', 'key': u'error'})
                server_ret = []
                server_list = [data['root']['AdminServerName']]
                for xi in data['root']['Servers'].keys():
                    if xi not in server_list:
                        server_list.append(xi)
                for i in server_list:
                    mid_dict = dict(data['root']['Servers'][i],
                                    **data['domain_run_time']['ServerRuntimes'].get(i,
                                                                                    {'HealthState': '', 'State': ''}))
                    try:
                        mid_jvm = data['domain_run_time']['ServerRuntimes'][i]['JVMRuntime'][i]
                    except:
                        mid_jvm = {}
                    mid_dict = dict(mid_dict, **mid_jvm)
                    if data['domain_run_time'].get('ServerServices', False):
                        services_data = data['domain_run_time']['ServerServices'].get(i, False)
                        if services_data:
                            mid_domain_data = services_data['RuntimeService']['DomainConfiguration']
                            domain_data = mid_domain_data[mid_domain_data.keys()[0]]
                            domain_data['DomainName'] = domain_data['Name']
                            server_runtime_data = services_data['RuntimeService']['ServerRuntime'][i]
                            mid_domain_dict = dict(domain_data, **server_runtime_data)
                            mid_dict = dict(mid_domain_dict, **mid_dict)
                    mid_key = []
                    m_home = ''
                    weblogic_version = ''
                    listen_ip = ''
                    for g in ['Name', 'ListenAddress', 'ListenPort', 'HealthState', 'State', 'JavaVersion',
                              'AdminServerName', 'RootDirectory', 'ConsoleEnabled', 'WeblogicHome',
                              'ProductionModeEnabled',
                              'MiddlewareHome', 'ConsoleContextPath', 'WeblogicVersion', 'DomainVersion']:
                        mid_vl = mid_dict.get(g, '')
                        if g == 'MiddlewareHome':
                            m_home = mid_vl
                        if g == 'ListenAddress':
                            listen_ip = mid_vl
                        if g == 'WeblogicVersion':
                            weblogic_version = mid_vl
                        if g == 'HealthState':
                            try:
                                mid_vl = mid_vl.split('State:')[1].split(',')[0]
                            except:
                                pass
                        if g == 'ListenAddress':
                            if mid_vl == '':
                                mid_vl = mid_obj.ip
                        mid_key.append({'key': g, 'display': g, 'value': mid_vl})
                    if weblogic_version:
                        if comeback_weblogic_version(weblogic_version).split('.')[0]>='12':
                            patch_path = m_home + '/OPatch/opatch'
                        else:
                            patch_path = m_home + '/utils/bsu/bsu.sh'
                        if listen_ip=='':
                            listen_ip = d['comback']['ip']
                        if has_file(listen_ip,patch_path):
                            mid_key.append({'key': 'patch_path', 'display': 'patch_path', 'value': patch_path})
                        else:
                            mid_key.append({'key': 'patch_path', 'display': 'patch_path', 'value': ''})
                    else:
                        mid_key.append({'key': 'patch_path', 'display': 'patch_path', 'value': ''})
                    displayi = ''
                    if data['root']['AdminServerName'] == i:
                        displayi = u'管理实例：' + i
                    else:
                        displayi = u'应用实例：' + i
                    server_ret.append({'key': i, 'display': displayi, 'value': mid_key})
                mid_ret = dict(data['root'], **data['server_run_time'])
                try:
                    mid_ret['AdminConsole'] = mid_ret['AdminConsole'][mid_ret['AdminConsole'].keys()[0]][
                        'SessionTimeout']
                except:
                    pass
                mid_ret.pop('Servers')
                root_obj.configitem_set.filter(key='error').delete()
                server_obj.configitem_set.filter(key='error').delete()

                for z in mid_ret.keys():
                    # has key
                    mid_val = mid_ret[z]
                    if root_obj.configitem_set.filter(key=z):
                        if mid_val:
                            # has new key  update
                            root_obj.configitem_set.filter(key=z).update(
                                **{'key': z, 'display': z, 'value': mid_val, 'can_modify': False})
                        else:
                            # no new key
                            mid_root = root_obj.configitem_set.get(key=z)
                            cmdb_mid_data = admin_data.get(key_cmdb[z], False)
                            if cmdb_mid_data:
                                root_obj.configitem_set.filter(key=z).update(
                                    **{'key': z, 'display': z, 'value': cmdb_mid_data, 'can_modify': True})
                            else:
                                # old_val = mid_root.value
                                mid_root.can_modify = True
                                mid_root.save()
                    else:
                        if mid_val == '':
                            mid_val = admin_data.get(key_cmdb[z], '')
                        root_obj.configitem_set.create(**{'key': z, 'display': z, 'value': mid_val})
                for x in server_ret:
                    listen_port = ''
                    mid_val = x['value']
                    for xz in mid_val:
                        if xz['key'] == 'ListenPort':
                            listen_port = xz['value']
                            break
                    try:
                        inst_data_cmdb = bk_data['inst'].get(listen_port, {})
                    except:
                        inst_data_cmdb = {}
                    if server_obj.configitem_set.filter(key=x['key']):
                        old_server_mid_val = eval(server_obj.configitem_set.get(key=x['key']).value)
                        old_server_val = {}
                        for old_mi in old_server_mid_val:
                            old_server_val[old_mi['key']] = old_mi
                        for xz in mid_val:
                            if xz['value']=='':
                                xz['value'] = inst_data_cmdb.get(inst_key_cmdb.get(xz['key'],''),'')
                                xz['can_modify'] = True
                            if xz['value'] == '':
                                xz['value'] = old_server_val[xz['key']]['value']
                                xz['can_modify'] = True
                        server_obj.configitem_set.filter(key=x['key']).update(**{'value':mid_val})
                    else:
                        for xz in mid_val:
                            if xz['value']=='':
                                xz['value'] = inst_data_cmdb.get(inst_key_cmdb.get(xz['key'],''),'')
                                xz['can_modify'] = True
                        x['value'] = mid_val
                        server_obj.configitem_set.create(**x)
            else:
                root_obj.configitem_set.filter(key='error').delete()
                server_obj.configitem_set.filter(key='error').delete()
                if bk_data.get('admin', False):
                    make_cmdb_to_weblogic_config(root_obj, server_obj, bk_data, key_cmdb, inst_key_cmdb)
                else:
                    root_obj.configitem_set.create(**{'value': str(d['error']), 'display': u'错误', 'key': u'error'})
                    server_obj.configitem_set.create(**{'value': str(d['error']), 'display': u'错误', 'key': u'error'})


def make_cmdb_to_weblogic_config(root_obj, server_obj, bk_data, key_cmdb, inst_key_cmdb):
    for z in key_cmdb.keys():
        if root_obj.configitem_set.filter(key=z):
            root_obj.configitem_set.filter(key=z).update(
                **{'key': z, 'display': z, 'value': bk_data['admin'].get(key_cmdb[z], ''),
                   'can_modify': True})
        else:
            root_obj.configitem_set.create(
                **{'key': z, 'display': z, 'value': bk_data['admin'].get(key_cmdb[z], ''),
                   'can_modify': True})
    if bk_data['inst']:
        for z in bk_data['inst'].values():
            mid_val = []
            for x in inst_key_cmdb.keys():
                mid_val.append({'key':x,'display':x,'value':z.get(inst_key_cmdb[x],''),'can_modify':True})
            if server_obj.configitem_set.filter(key=z['name']):
                server_obj.configitem_set.filter(key=z['name']).update(
                    **{'key': z['name'], 'display': z['name'], 'value': mid_val,
                       'can_modify': True})
            else:
                server_obj.configitem_set.create(
                    **{'key': z['name'], 'display': z['name'], 'value': mid_val,
                       'can_modify': True})

def make_websphere_data(data):
    if data['result']:
        for d in data['data']:
            oid = d['id']
            mid_obj = Middleware.objects.get(id=oid)
            if mid_obj.configtype_set.filter(name='root'):
                mid_obj.configtype_set.filter(name='root').update(
                    **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
                root_obj = mid_obj.configtype_set.get(name='root')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
            if mid_obj.configtype_set.filter(name='server'):
                mid_obj.configtype_set.filter(name='server').update(
                    **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
                server_obj = mid_obj.configtype_set.get(name='server')
            else:
                server_obj = mid_obj.configtype_set.create(
                    **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_websphere'), 'r').read()
            root_obj.configitem_set.filter(key='error').delete()
            server_obj.configitem_set.filter(key='error').delete()
            try:
                data = d['comback']['logContent']
                mid_data_list = data.split('!-----!')
                version_data = mid_data_list[1]
                detail_data = mid_data_list[0]
                if '_____' in detail_data:
                    detail_data = detail_data.split('_____')[1].split('_____')[0]
                base_data = eval(detail_data)
                root_obj.configitem_set.all().delete()
                server_obj.configitem_set.all().delete()
                ret_version = {}
                version_key = ''
                for i in version_data.split('\n'):
                    if i:
                        mid_i = i.split('  ')
                        if mid_i.__len__() > 2:
                            if mid_i[0].lstrip().rstrip()!= '':
                                version_key = mid_i[0]
                            if ret_version.get(version_key):
                                ret_version[version_key] = ret_version[version_key] + '   ' + ' '.join(
                                    mid_i[1:]).lstrip().rstrip()
                            else:
                                ret_version[version_key] = ' '.join(mid_i[1:]).lstrip().rstrip()
                for z in ret_version:
                    root_obj.configitem_set.create(**{'key': z, 'display': z, 'value': ret_version[z]})
                ports_ret = []
                for cell in base_data.keys():
                    cell_data = base_data[cell]
                    cell_ret = []
                    for y in cell_data['ports'].keys():
                        ports_ret.append({'key': y, 'display': y, 'value': cell_data['ports'][y]})
                    root_obj.configitem_set.create(**{'key': 'ports', 'display': u'端口', 'value': ports_ret})

                    for node in cell_data['node'].keys():
                        node_data = cell_data['node'][node]
                        node_ret = {'key': node, 'display': node, 'value': [], 'rgtypeof': True}
                        for server in node_data['server'].keys():
                            server_data = node_data['server'][server]
                            if server == 'version':
                                server_ret = {'key': server, 'display': u'版本', 'value': server_data}
                            else:
                                mid_server_data = []
                                if server_data.get('app', False):
                                    mid_server_data.append(
                                        {'key': 'app', 'display': '应用', 'value': u'，'.join(server_data['app'])})

                                if server_data.get('jvm', False):
                                    jvm_config = {'debugArgs': u'调试参数', 'genericJvmArguments': u'通用 JVM 参数',
                                                  'initialHeapSize': u'初始堆大小', 'maximumHeapSize': u'最大堆大小'}
                                    mid_server_data.append({'rgtypeof': True, 'key': 'jvm', 'display': 'JVM', 'value': [
                                        {'key': jvm, 'display': jvm_config.get(jvm, jvm),
                                         'value': server_data['jvm'][jvm]} for
                                        jvm in server_data['jvm']]})

                                if server_data.get('ObjectRequestBroker', False):
                                    orb_config = {'requestTimeout': u'请求超时', 'requestRetriesCount': u'请求重试次数',
                                                  'requestRetriesDelay': u'请求重试延迟',
                                                  'connectionCacheMaximum': u'连接高速缓存最大值',
                                                  'connectionCacheMinimum': u'连接高速缓存最小值',
                                                  'locateRequestTimeout': u'定位请求超时',
                                                  'minimumSize': u'线程池最小大小', 'maximumSize': u'线程池最大大小',
                                                  'inactivityTimeout': u'线程不活动超时', 'isGrowable': u'允许线程分配超过最大线程大小'}
                                    try:
                                        mid_orb_data = server_data['ObjectRequestBroker']['val'][0]
                                        mid_orb_data = dict(
                                            server_data['ObjectRequestBroker']['next'][0].values()[0]['ThreadPool']['val'][
                                                0],
                                            **mid_orb_data)
                                        orb_ret = [{'key': orbkey, 'display': orb_config.get(orbkey, orbkey),
                                                    'value': mid_orb_data[orbkey]} for orbkey in mid_orb_data.keys()]
                                        mid_server_data.append(
                                            {'key': 'ObjectRequestBroker', 'display': u'ORB服务', 'value': orb_ret,
                                             'rgtypeof': True})
                                    except Exception,e:
                                        logger.error(e)
                                if server_data.get('ThreadPool', False):
                                    mid_server_data.append(
                                        {'key': 'ThreadPool', 'display': u'线程池',
                                         'value': server_data['ThreadPool']['val'],
                                         'rgtypeof': True})

                                if server_data.get('JDBCProvider', False):
                                    jdbc_ret = []
                                    for ji in server_data['JDBCProvider']['next']:
                                        for procell in ji.keys():
                                            for data_cell in ji[procell]['DataSource']['next']:
                                                for data_end_cell in data_cell.keys():
                                                    end_ret = data_cell[data_end_cell]['ConnectionPool']['val'][0]
                                                    if procell[0] == '"':
                                                        end_ret['jdbc'] = procell[1:].rstrip()
                                                    else:
                                                        end_ret['jdbc'] = procell.rstrip()
                                                    if data_end_cell[0] == '"':
                                                        end_ret['datasource'] = data_end_cell[1:].rstrip()
                                                    else:
                                                        end_ret['datasource'] = data_end_cell.rstrip()
                                                    jdbc_ret.append(end_ret)
                                    mid_server_data.append(
                                        {'key': 'JDBCProvider', 'display': u'JDBC', 'value': jdbc_ret,
                                         'rgtypeof': True})

                                server_ret = {'key': server, 'display': server, 'value': mid_server_data,
                                              'rgtypeof': True}
                            node_ret['value'].append(server_ret)
                        cell_ret.append(node_ret)
                    server_obj.configitem_set.create(**{'key': 'cell', 'display': cell, 'value': cell_ret})
            except Exception, e:
                logger.error(str(d))
                logger.exception('websphere config')
                server_obj.configitem_set.create(**{'key': 'error', 'display': u'错误', 'value': u'获取信息错误，请联系管理员！'})
                root_obj.configitem_set.create(**{'key': 'error', 'display': u'错误', 'value': u'获取信息错误，请联系管理员！'})


def make_jboss_data(data):
    if data['result']:
        for d in data['data']:
            oid = d['id']
            mid_obj = Middleware.objects.get(id=oid)
            if mid_obj.is_cluster:
                cell_jboss_cli(mid_obj, d)
            else:
                cell_jboss_alone(mid_obj, d)


def cell_jboss_alone(mid_obj,d):
    if mid_obj.configtype_set.filter(name='root'):
        mid_obj.configtype_set.filter(name='root').update(
            **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
        root_obj = mid_obj.configtype_set.get(name='root')
    else:
        root_obj = mid_obj.configtype_set.create(
            **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
    if mid_obj.configtype_set.filter(name='server'):
        mid_obj.configtype_set.filter(name='server').delete()
    root_obj.configitem_set.filter(key='error').delete()
    try:
        data = d['comback']['logContent']
        data = data.replace('=>', ':').replace('expression "', '"').replace('L,', ',').replace('L ','').replace('L\n', '\n').replace(
            '("', '{"').replace('")', '"}').replace('\n', '').replace('\'', '"').replace(' ', '').replace('undefined',
                                                                                                          '""')
        all_i = []
        for i in data.split('bytes{'):
            if not i.startswith('{'):
                mid_list = i.split('}')
                end_str = "}".join(mid_list[1:])
                all_i.append(end_str)
            else:
                all_i.append(i)
        data = '""'.join(all_i)
        end_data = json.loads(data)
        root_obj.configitem_set.all().delete()

        if end_data['outcome']=='success':
            res = end_data['result']
            create_list = []
            create_list.append({'key': 'release-version', 'display': u'发行版本', 'value': res['release-version']})
            create_list.append({'key': 'release-codename', 'display': u'发行代号', 'value': res['release-codename']})

            socket_group = []
            for socket_name in res['socket-binding-group'].keys():
                socket_list = []
                for soket_line in res['socket-binding-group'][socket_name]['socket-binding'].values():
                    socket_list.append({'key': soket_line.get('name', ''), 'display': soket_line.get('name', ''),
                                        'value': str(soket_line.get('port', ''))})
                socket_group.append(
                    {'key': socket_name, 'display': socket_name, 'value': socket_list, 'rgtypeof': True})
            create_list.append(
                {'key': 'socket-binding-group', 'display': u'socket-binding-group', 'value': socket_group})

            inter_list = []
            for interface in res['interface'].values():
                inter_list.append({'rgtypeof': True, 'key': interface['name'], 'display': interface['name'],
                                   'value': [{'key': 'inet-address', 'display': 'inet-address',
                                              'value': interface['inet-address']}]})
            create_list.append(
                {'key': 'interface', 'display': u'interface', 'value': inter_list})
            create_list.append(
                {'key': 'deployment', 'display': u'应用', 'value': ",".join(res['deployment'].keys())})
            for i in create_list:
                root_obj.configitem_set.create(**i)
    except Exception, e:
        logger.error(str(d))
        logger.exception('jboss config alone')
        root_obj.configitem_set.create(**{'key': 'error', 'display': u'错误', 'value': u'获取信息错误，请联系管理员！'})

def cell_jboss_cli(mid_obj,d):
    if mid_obj.configtype_set.filter(name='root'):
        mid_obj.configtype_set.filter(name='root').update(
            **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
        root_obj = mid_obj.configtype_set.get(name='root')
    else:
        root_obj = mid_obj.configtype_set.create(
            **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
    if mid_obj.configtype_set.filter(name='server'):
        mid_obj.configtype_set.filter(name='server').update(
            **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
        server_obj = mid_obj.configtype_set.get(name='server')
    else:
        server_obj = mid_obj.configtype_set.create(
            **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
    root_obj.configitem_set.filter(key='error').delete()
    server_obj.configitem_set.filter(key='error').delete()
    try:
        data = d['comback']['logContent']
        data = data.replace('=>', ':').replace('expression "', '"').replace('L,', ',').replace('L\n', '\n').replace(
            '("', '{"').replace('")', '"}').replace('\n', '').replace('\'', '"').replace(' ', '').replace('undefined',
                                                                                                          '""')
        data = data[:-3] + "}}"
        all_i = []
        for i in data.split('bytes{'):
            if not i.startswith('{'):
                mid_list = i.split('}')
                end_str = "}".join(mid_list[1:])
                all_i.append(end_str)
            else:
                all_i.append(i)
        data = '""'.join(all_i)
        end_data = json.loads(data)
        root_obj.configitem_set.all().delete()
        server_obj.configitem_set.all().delete()
        if end_data['server']['outcome'] == "success":
            create_list = []
            res = end_data['server']['result']
            create_list.append({'key': 'release-version', 'display': u'发行版本', 'value': res['release-version']})
            create_list.append({'key': 'release-codename', 'display': u'发行代号', 'value': res['release-codename']})
            group_list = []
            for groupname in res['server-group'].keys():
                group_data = res['server-group'][groupname]
                mid_group_list = []
                mid_group_list.append({'key': 'profile', 'display': u'profile', 'value': group_data['profile']})
                mid_group_list.append({'key': 'socket-binding-group', 'display': u'socket-binding-group',
                                       'value': group_data['socket-binding-group']})
                mid_group_list.append(
                    {'key': 'deployment', 'display': u'应用', 'value': ",".join(group_data['deployment'].keys())})
                group_list.append({'key': groupname, 'display': groupname, 'value': mid_group_list, 'rgtypeof': True})
            create_list.append(
                {'key': 'server-group', 'display': u'server-group', 'value': group_list})

            socket_group = []
            for socket_name in res['socket-binding-group'].keys():
                socket_list = []
                for soket_line in res['socket-binding-group'][socket_name]['socket-binding'].values():
                    socket_list.append({'key': soket_line.get('name', ''), 'display': soket_line.get('name', ''),
                                        'value': str(soket_line.get('port', ''))})
                socket_group.append(
                    {'key': socket_name, 'display': socket_name, 'value': socket_list, 'rgtypeof': True})
            create_list.append(
                {'key': 'socket-binding-group', 'display': u'socket-binding-group', 'value': socket_group})
            for i in create_list:
                root_obj.configitem_set.create(**i)
        if end_data.get('host', False):
            create_list = []
            res = end_data['host']
            host_list = []
            for host in res.keys():
                if res[host]['outcome'] != 'success':
                    return
                host_res = res[host]['result']
                host_list.append(
                    {'key': 'release-version', 'display': u'发行版本', 'value': host_res['release-version']})
                host_list.append(
                    {'key': 'release-codename', 'display': u'发行代号', 'value': host_res['release-codename']})
                try:
                    mid_controller_res = host_res['domain-controller'].values()[0]
                    mid_controller = mid_controller_res['host'] + ":" + mid_controller_res['port']
                except:
                    mid_controller = host_res['domain-controller'].keys()[0] + ':' + mid_obj.port
                host_list.append(
                    {'key': 'domain-controller', 'display': u'管理实例', 'value': mid_controller})
                inter_list = []
                for interface in host_res['interface'].values():
                    inter_list.append({'rgtypeof': True, 'key': interface['name'], 'display': interface['name'],
                                       'value': [{'key': 'inet-address', 'display': 'inet-address',
                                                  'value': interface['inet-address']}]})
                host_list.append(
                    {'rgtypeof': True, 'key': 'interface', 'display': u'interface', 'value': inter_list})
                server_list = []
                for server in host_res['server-config'].values():
                    mid_item = []
                    mid_item.append({'key': 'jvm', 'display': u'jvm', 'value': server['jvm']})
                    mid_item.append({'key': 'group', 'display': u'group', 'value': server['group']})
                    mid_item.append({'key': 'socket-binding-group', 'display': u'socket-binding-group',
                                     'value': server['socket-binding-group']})
                    server_list.append(
                        {'rgtypeof': True, 'key': server['name'], 'display': server['name'], 'value': mid_item})
                host_list.append(
                    {'rgtypeof': True, 'key': 'server-config', 'display': u'实例', 'value': server_list})
                create_list.append(
                    {'key': host, 'display': host, 'value': host_list})
            for i in create_list:
                server_obj.configitem_set.create(**i)
    except Exception, e:
        logger.error(str(d))
        logger.exception('jboss config cli')
        server_obj.configitem_set.create(**{'key': 'error', 'display': u'错误', 'value': u'获取信息错误，请联系管理员！'})
        root_obj.configitem_set.create(**{'key': 'error', 'display': u'错误', 'value': u'获取信息错误，请联系管理员！'})



APACHE_ITEM = ['User', 'Group', 'ServerAdmin', 'DocumentRoot', 'ServerName']
APACHE_DEFULT = {'Timeout': '60', 'KeepAlive': 'on', 'KeepAliveTimeout': '5', 'MaxKeepAliveRequests': '100'}


def make_apache_data_httpd(data):
    if data['result']:
        for a in data['data']:
            data = a['comback']['logContent']
            oid = a['id']
            mid_obj = Middleware.objects.get(id=oid)
            httpd_url = mid_obj.configpath_set.get(key='httpd').value
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_httpd'), 'r').read()
            port_list = []
            module_list = []
            inclue_list = []
            base_item = {}
            default_tiem = APACHE_DEFULT
            for i in data.split('\n'):
                i = i.rstrip()
                i = i.lstrip()
                if not i.startswith('#'):
                    if 'Listen' in i:
                        port_list.append(i.split(' ')[1])
                    if 'LoadModule' in i:
                        split_mid = i.split(' ')
                        module_list.append({'key': split_mid[1], 'value': split_mid[2], 'display': split_mid[1]})
                    for z in APACHE_ITEM:
                        if i.startswith(z):
                            mid_li_vl = i.split(' ')
                            mid_li_vl[0] = ''
                            base_item[z] = ' '.join(mid_li_vl)
                    if 'Include' in i:
                        inclue_list.append(i.split(' ')[1])
                    for g in APACHE_DEFULT.keys():
                        if i.startswith(g):
                            default_tiem[g] = i.split(' ')[1]
            base_item['Include'] = inclue_list
            if mid_obj.configtype_set.filter(name='httpd'):
                mid_obj.configtype_set.filter(name='httpd').update(
                    **{'name': 'httpd', 'display': 'httpd配置', 'xml': data, 'xml_path': httpd_url})
                root_obj = mid_obj.configtype_set.get(name='httpd')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'httpd', 'display': 'httpd配置', 'xml': data, 'xml_path': httpd_url})
            root_obj.configitem_set.exclude(key='version').delete()
            for y in base_item.keys():
                root_obj.configitem_set.create(**{'key': y, 'display': y, 'value': base_item[y]})
            for y in default_tiem.keys():
                root_obj.configitem_set.create(**{'key': y, 'display': y, 'value': default_tiem[y]})
            root_obj.configitem_set.create(**{'key': 'listen', 'display': 'listen', 'value': ','.join(port_list)})
            root_obj.configitem_set.create(**{'key': 'LoadModule', 'display': 'LoadModule', 'value': module_list})


def make_apache_data_version(data):
    if data['result']:
        for a in data['data']:
            data = a['comback']['logContent']
            oid = a['id']
            mid_obj = Middleware.objects.get(id=oid)
            httpd_url = mid_obj.configpath_set.get(key='httpd').value
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_httpd'), 'r').read()
            version_data = ''
            for i in data.split('\n'):
                i = i.rstrip()
                i = i.lstrip()
                if 'Server version:' in i:
                    version_data = i.replace('Server version:', '')
                    version_data.rstrip()
                    version_data.lstrip()

            if mid_obj.configtype_set.filter(name='httpd'):
                mid_obj.configtype_set.filter(name='httpd').update(
                    **{'name': 'httpd', 'display': '基本配置配置'})
                root_obj = mid_obj.configtype_set.get(name='httpd')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'httpd', 'display': '基本配置配置'})
            if root_obj.configitem_set.filter(key='version'):
                root_obj.configitem_set.filter(key='version').update(**{'value': version_data})
            else:
                root_obj.configitem_set.create(**{'key': 'version', 'display': 'version', 'value': version_data})


def make_apache_data_httpd_host(data):
    if data['result']:
        for a in data['data']:
            data = a['comback']['logContent']
            oid = a['id']
            mid_obj = Middleware.objects.get(id=oid)
            httpd_url = mid_obj.configpath_set.get(key='vhost').value
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_httpd_host'), 'r').read()
            ret = {}
            mid_ret = {}
            for i in data.split('\n'):
                if not i.startswith('#'):
                    i = i.rstrip()
                    i = i.lstrip()
                    if '<VirtualHost' in i:
                        mid_key = i.split(':')[-1][:-1]
                        ret[mid_key] = {}
                        mid_ret = ret[mid_key]
                    if 'WebLogicHost' in i:
                        mid_ret['WebLogicHost'] = i.split(' ')[1]
                    if 'WebLogicPort' in i:
                        mid_ret['WebLogicPort'] = i.split(' ')[1]
                    if 'MatchExpression' in i:
                        mid_ret['MatchExpression'] = i.split(' ')[1]
            final_ret = []
            for i in ret.keys():
                mid_val = []
                for z in ret[i].keys():
                    mid_val.append({'key': z, 'display': z, 'value': ret[i][z]})
                final_ret.append({'key': i, 'display': i, 'rgtypeof': True, 'value': mid_val})

            if mid_obj.configtype_set.filter(name='vhost'):
                mid_obj.configtype_set.filter(name='vhost').update(
                    **{'name': 'vhost', 'display': '反向代理配置', 'xml': data, 'xml_path': httpd_url})
                root_obj = mid_obj.configtype_set.get(name='vhost')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'vhost', 'display': '反向代理配置', 'xml': data, 'xml_path': httpd_url})
            root_obj.configitem_set.all().delete()
            for p in final_ret:
                root_obj.configitem_set.create(**{'key': p['key'], 'display': p['display'], 'value': p['value']})


def comeback_weblogic_version(data):
    weblogic_version_list = data.split('WebLogic Server')
    for i in reversed(weblogic_version_list):
        if '.' in i:
            i = i.replace(' ', '')
            return '.'.join(i.split('.')[0:3])
    return ''