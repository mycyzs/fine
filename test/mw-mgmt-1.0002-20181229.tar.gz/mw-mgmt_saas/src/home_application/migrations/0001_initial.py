# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Application',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='Business',
            fields=[
                ('id', models.IntegerField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('created_by', models.CharField(max_length=100)),
                ('when_created', models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='ConfigItem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=100)),
                ('value', models.TextField(default=b'')),
                ('display', models.CharField(default=b'', max_length=100, null=True)),
                ('can_modify', models.BooleanField(default=False)),
            ],
        ),
        migrations.CreateModel(
            name='ConfigPath',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=100)),
                ('value', models.TextField(default=b'')),
                ('display', models.CharField(default=b'', max_length=100, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='ConfigType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('display', models.CharField(max_length=100)),
                ('xml', models.TextField(default=b'', null=True)),
                ('xml_path', models.TextField(default=b'', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='HistoryConfigItem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=100)),
                ('value', models.TextField(default=b'')),
                ('display', models.CharField(default=b'', max_length=100, null=True)),
                ('can_modify', models.BooleanField(default=False)),
            ],
        ),
        migrations.CreateModel(
            name='HistoryConfigType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('display', models.CharField(max_length=100)),
                ('xml', models.TextField(default=b'', null=True)),
                ('xml_path', models.TextField(default=b'', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='HistoryMiddleware',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('create_time', models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='Instance',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='Logs',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('operated_type', models.CharField(max_length=50)),
                ('content', models.TextField()),
                ('when_created', models.CharField(max_length=30)),
                ('operator', models.CharField(max_length=50)),
            ],
        ),
        migrations.CreateModel(
            name='Middleware',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ip', models.CharField(max_length=100)),
                ('is_cluster', models.BooleanField(default=False)),
                ('is_time', models.BooleanField(default=False)),
                ('port', models.CharField(default=b'', max_length=10, null=True)),
                ('state', models.CharField(default=b'waitting', max_length=10, choices=[(b'waitting', b'waitting'), (b'running', b'running'), (b'success', b'success'), (b'fail', b'fail')])),
                ('java_version', models.CharField(default=b'', max_length=10, null=True)),
                ('is_delete', models.BooleanField(default=False)),
                ('creator', models.CharField(max_length=20)),
                ('create_time', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='MiddlewareType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=20)),
                ('creator', models.CharField(max_length=20)),
                ('create_time', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='Module',
            fields=[
                ('id', models.IntegerField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('business', models.ForeignKey(to='home_application.Business')),
            ],
        ),
        migrations.CreateModel(
            name='Servers',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ip', models.CharField(max_length=100)),
                ('operation_system', models.CharField(default=b'', max_length=200)),
                ('hostname', models.CharField(default=b'', max_length=100)),
                ('sys_type', models.CharField(default=b'', max_length=10)),
                ('source', models.CharField(default=b'', max_length=100, null=True)),
                ('is_delete', models.BooleanField(default=False)),
                ('module', models.ForeignKey(to='home_application.Module', null=True)),
            ],
        ),
        migrations.CreateModel(
            name='SettingConfigItem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=100)),
                ('display', models.CharField(default=b'', max_length=100, null=True)),
                ('is_default', models.BooleanField(default=False)),
            ],
        ),
        migrations.CreateModel(
            name='SettingConfigType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('display', models.CharField(max_length=100)),
                ('middle_type', models.ForeignKey(to='home_application.MiddlewareType')),
            ],
        ),
        migrations.CreateModel(
            name='SettingPlan',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('display', models.CharField(max_length=100)),
                ('creator', models.CharField(max_length=20)),
                ('create_time', models.CharField(max_length=30)),
                ('config_detail', models.TextField()),
                ('middle_type', models.ForeignKey(to='home_application.MiddlewareType')),
            ],
        ),
        migrations.CreateModel(
            name='Userinfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=50)),
                ('when_created', models.CharField(max_length=50)),
                ('mailbox', models.CharField(default=b'', max_length=100, null=True)),
            ],
        ),
        migrations.AddField(
            model_name='settingconfigitem',
            name='setting_mid_type',
            field=models.ForeignKey(to='home_application.SettingConfigType'),
        ),
        migrations.AddField(
            model_name='middleware',
            name='type',
            field=models.ForeignKey(to='home_application.MiddlewareType', null=True),
        ),
        migrations.AddField(
            model_name='instance',
            name='midware',
            field=models.ForeignKey(to='home_application.Middleware'),
        ),
        migrations.AddField(
            model_name='historymiddleware',
            name='midware',
            field=models.ForeignKey(to='home_application.Middleware'),
        ),
        migrations.AddField(
            model_name='historyconfigtype',
            name='midware',
            field=models.ForeignKey(to='home_application.HistoryMiddleware'),
        ),
        migrations.AddField(
            model_name='historyconfigitem',
            name='config_type',
            field=models.ForeignKey(to='home_application.HistoryConfigType'),
        ),
        migrations.AddField(
            model_name='configtype',
            name='midware',
            field=models.ForeignKey(to='home_application.Middleware'),
        ),
        migrations.AddField(
            model_name='configpath',
            name='midware',
            field=models.ForeignKey(to='home_application.Middleware'),
        ),
        migrations.AddField(
            model_name='configitem',
            name='config_type',
            field=models.ForeignKey(to='home_application.ConfigType'),
        ),
        migrations.AddField(
            model_name='application',
            name='instance',
            field=models.ForeignKey(to='home_application.Instance'),
        ),
    ]
