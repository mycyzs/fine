# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0004_config_setting'),
    ]

    operations = [
        migrations.AddField(
            model_name='middleware',
            name='bk_inst_id',
            field=models.CharField(default=b'', max_length=50, null=True),
        ),
    ]
