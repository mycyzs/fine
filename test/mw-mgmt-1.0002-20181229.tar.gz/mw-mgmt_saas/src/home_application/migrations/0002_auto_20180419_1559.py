# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Config_report_group',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('mw_type', models.CharField(max_length=20)),
                ('key', models.CharField(max_length=20)),
                ('display', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='Config_report_item',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('type', models.CharField(max_length=30)),
                ('key', models.CharField(max_length=30)),
                ('display', models.CharField(max_length=20)),
                ('compare', models.CharField(max_length=5)),
                ('compare_value', models.TextField(default=b'', null=True)),
                ('warn_color', models.CharField(max_length=15)),
            ],
        ),
        migrations.CreateModel(
            name='Report',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('discript', models.CharField(max_length=50)),
                ('when_create', models.CharField(max_length=30)),
                ('when_end', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='Report_group',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=20)),
                ('display', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='Report_item',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('type', models.CharField(max_length=30)),
                ('key', models.CharField(max_length=30)),
                ('value', models.TextField(default=b'', null=True)),
                ('display', models.CharField(max_length=20)),
                ('iswarn', models.BooleanField(default=False)),
                ('warn_color', models.CharField(max_length=15)),
            ],
        ),
        migrations.CreateModel(
            name='Report_mw',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('mw_type', models.CharField(max_length=20)),
                ('mw_name', models.CharField(max_length=40)),
                ('mw_info', models.TextField(default=b'', null=True)),
                ('discript', models.CharField(max_length=50)),
                ('report', models.ForeignKey(to='home_application.Report')),
            ],
        ),
        migrations.CreateModel(
            name='Task',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('task_name', models.CharField(max_length=50)),
                ('creator', models.CharField(max_length=50)),
                ('when_create', models.CharField(max_length=30)),
                ('mw_id_list', models.TextField()),
            ],
        ),
        migrations.AddField(
            model_name='report',
            name='task',
            field=models.ForeignKey(to='home_application.Task'),
        ),
    ]
