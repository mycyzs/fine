# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
from django.db import migrations
from home_application.models import Setting


def initial_setting(apps, schema_editor):
    try:
        Setting.objects.all().delete()

        up = [
            {'key':'cmdb_op','disc':u'是否从cmdb同步中间件凭据信息','value':'0','display':u'同步cmdb开关'},

              ]
        for u in up:
            Setting.objects.create(**u)
    except Exception, e:
        print e.message


class Migration(migrations.Migration):
    dependencies = [
        ('home_application', '0003_setting'),
    ]

    operations = [
        migrations.RunPython(initial_setting),
    ]