# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0006_instance_value'),
    ]

    operations = [
        migrations.AddField(
            model_name='middleware',
            name='last_time',
            field=models.CharField(default=b'', max_length=50, null=True),
        ),
    ]
