# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0007_middleware_last_time'),
    ]

    operations = [
        migrations.AddField(
            model_name='middleware',
            name='bk_data',
            field=models.TextField(default=b'', null=True),
        ),
    ]
