# -*- coding: utf-8 -*-
from conf.default import APP_TOKEN, APP_ID, BK_PAAS_HOST
import base64
import requests
from common.log import logger
import time
import json

# esb底层工具集，用于基本esb操作以及简单的esb结果处理



# 执行windows脚本,根据传入的参数也可以执行linux脚本,返回执行状态字符串
def execute_script(bk_biz_id, script_content, ip_list, system_executor, bk_username='admin', script_type=2):
    # 默认从django settings中获取APP认证信息：应用ID和安全密钥
    # 默认从django request中获取用户登录态bk_token
    URL = BK_PAAS_HOST + "/api/c/compapi/v2/job/fast_execute_script/"
    kwargs = {
        "bk_app_code": APP_ID,  # appID
        "bk_app_secret": APP_TOKEN,  # appToken
        "bk_username": bk_username,  # 认证用户
        "bk_biz_id": bk_biz_id,  # 业务id
        "script_content": base64.b64encode(script_content),  # 实际执行脚本，要求bash64编码
        "script_timeout": 1000,  # 脚本超时时间
        "account": system_executor,  # 机器执行脚本的账号
        "is_param_sensitive": 0,  # 参数是否敏感
        "script_type": script_type,  # 脚本类型：1(shell脚本)、2(bat脚本)、3(perl脚本)、4(python脚本)、5(Powershell脚本)
        "ip_list": ip_list
    }
    res_json = requests.post(url=URL, json=kwargs,verify=False)
    return res_json


# 获取执行结果,返回结果字符串
def get_result(bk_biz_id, job_instance_id, bk_username="admin"):
    URL = BK_PAAS_HOST + "/api/c/compapi/v2/job/get_job_instance_log/"
    kwargs = {
        "bk_app_code": APP_ID,
        "bk_app_secret": APP_TOKEN,
        "bk_username": bk_username,
        "bk_biz_id": bk_biz_id,
        "job_instance_id": job_instance_id

    }
    res_json = requests.post(url=URL, json=kwargs,verify=False)

    return res_json


# 传输文件,来源信息通过file_source传入,目标地址通过ip_list,file_target_path定位
def push_file(bk_biz_id, file_source, target_path, ip_list, target_account='system', bk_username='admin'):
    URL = BK_PAAS_HOST + "/api/c/compapi/v2/job/fast_push_file/"
    kwargs = {
        "bk_app_code": APP_ID,
        "bk_app_secret": APP_TOKEN,
        "bk_username": bk_username,
        "bk_biz_id": bk_biz_id,
        "account": target_account,
        "file_source": file_source,
        "ip_list": ip_list,
        "file_target_path": target_path
    }
    res_json = requests.post(url=URL, json=kwargs,verify=False)

    return res_json


# 快速获取日志的方案，内嵌循环机制，为get_result方法的复杂版,调用了上层接口
def get_log_content_by_response(get_ret, bk_biz_id):
    res_data = format_json(get_ret)
    execute_flag = True
    query_count = 0
    try:
        while execute_flag and query_count < 60:
            log_res_json = get_result(bk_biz_id=bk_biz_id,
                                      job_instance_id=res_data["data"]["data"]["job_instance_id"])
            # logger.info(u"-----\n"+log_res_json.content)
            log_data = format_json(log_res_json)
            if log_data and log_data["data"] and log_data["data"]["data"] and log_data["data"]["data"][0] and log_data["data"]["data"][0]["is_finished"]:
                log_result = log_data["data"]["data"][0]["step_results"][0]["ip_logs"][0]["log_content"]
                return log_result
            else:
                query_count = query_count + 1
                time.sleep(2)
    except Exception, e:
        logger.exception(u"get_log_content_by_response,快速获取job结果时发生异常")
        return False
    return False


# json自动梳理,若梳理失败(格式不对)则result项返回False
def format_json(response):
    res_item = {}
    try:
        res_item["data"] = json.loads(response.content)
        res_item["result"] = True
    except Exception, e:
        res_item["data"] = str(e)
        res_item["result"] = False
    return res_item
