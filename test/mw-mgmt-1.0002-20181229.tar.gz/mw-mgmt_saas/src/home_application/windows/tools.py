# -*- coding: utf-8 -*-
import json
from home_application.windows import esb_tools
from conf.default import JMXCMD_PATH_WINDOWS
from common.log import logger
from home_application.models import Middleware
import time


# 判断指定的服务器中是否已存在jar包
def has_file_windows(biz_id, ip_list, file_path):
    # 脚本功能：bat脚本，判断是否存在对应文件，文件路径为file_path
    try:
        script_content = '''
            @echo off
            if exist %s (echo hasfile) else (echo nofile) 
            ''' % file_path
        # 执行脚本
        res_json = esb_tools.execute_script(bk_biz_id=biz_id, script_content=script_content, ip_list=ip_list,
                                            system_executor="system")
        # 获取结果
        log_result = esb_tools.get_log_content_by_response(res_json, biz_id)

        if log_result == u"hasfile\n":
            return True
        else:
            return False
    except Exception, e:
        logger.exception(u"has_file_windows,has_file_windows函数,执行异常")
        return False


# 传输文件到指定服务器
def fast_push_file_windows(biz_id, file_source, target_path, ip_list):
    # 传送文件，返回成功或者失败
    try:
        res_data = esb_tools.push_file(bk_biz_id=biz_id, file_source=file_source, target_path=target_path,
                                       ip_list=ip_list)
        res = esb_tools.get_log_content_by_response(res_data, biz_id)
        logger.info(u"文件分发结果:" + res)
        # 很蠢的判断文件是否发送成功方案，有判断失败的概率
        if "select file server fail" in res:
            return False
        else:
            return True
    except Exception, e:
        logger.exception(u"fast_push_file_windows,文件分发ESB,执行异常")
        return False


# 组合脚本并执行脚本
def execute_formated_script(cmd, script_cred):
    cmd_ret = []
    cmd_ret.append("@echo off\n")
    # 拼接命令成为一个list列表
    for i in cmd:
        if 'echo @@@@@@@@@@@@@' in i:
            cmd_ret.append(i)
            continue
        cmd_ret.append('java -jar cmdline-jmxclient-0.10.3.jar - %s %s' % (
            script_cred['ip'] + ':' + script_cred['path']['jmx_port'], i + "\n"))
    # 加入自定义分隔符
    cmd_rets = 'echo !____!\n '.join(cmd_ret)
    # 替换目录为完整版
    cmds = cmd_rets.replace('cmdline-jmxclient-0.10.3.jar', JMXCMD_PATH_WINDOWS + 'cmdline-jmxclient-0.10.3.jar')
    # 因为esb版本变化，重新封装ip数据
    ip_list = [{'ip': script_cred['ip'], 'bk_cloud_id': script_cred['source']}]
    # 执行脚本
    get_ret = esb_tools.execute_script(bk_biz_id=script_cred['app_id'], script_content=cmds, ip_list=ip_list,
                                       system_executor="system")
    # 返回执行结果
    return esb_tools.get_log_content_by_response(get_ret, script_cred['app_id'])


def back_last(data):
    if 'not found' in data:
        return ''
    return data.split(':')[-1].lstrip().rstrip()


