# -*- coding: utf-8 -*-
from binascii import b2a_hex, a2b_hex
from Crypto.Cipher import AES
from Crypto import Random

# 加密方法，用于加密用户密码
def decrypt(ciphertext):
    key = "wusnxhdyshdksiwy"
    mode = AES.MODE_ECB
    encryptor = AES.new(key, mode)
    plain1 = encryptor.decrypt(a2b_hex(ciphertext))
    plain = plain1.rstrip("\0")
    return plain