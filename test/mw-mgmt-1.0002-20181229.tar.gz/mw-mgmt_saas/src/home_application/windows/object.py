# -*- coding: utf-8 -*-
from common.log import logger
from home_application.windows import tools, esb_tools, encryption
from conf.default import *
from home_application.models import Servers, Module, Middleware
from conf.default import PROJECT_ROOT
import os
from home_application.helper import fast_push_file
import json


# 存放中间件管理对象,目前只存放windows对象，linux未进行整理 2018.11.19

# 对应windows的中间件处理对象
class RGMiddleWareWindows:
    def __init__(self, ip_list, accout, is_ip=False, script_type=2):
        self.ip_list = ip_list
        self.accout = accout
        self.script_type = script_type
        if is_ip:
            self.script_result_jvm = self.get_file_tomcat('jvm')
            self.script_result_server = self.get_file_tomcat('server')
            self.script_result_user = self.get_file_tomcat('user')
            self.script_result_httpd = self.get_file_tomcat('httpd')
            self.script_result_vhost = self.get_file_tomcat('vhost')

    # 服务器信息获取,中转方法
    def get_server_base(self):
        return self.get_server_info(self.ip_list)

    # 服务器信息获取,执行查询的重点方法
    def get_server_info(self, iplist):
        try:
            server_list_data = {}
            for i in [g['ip'] for g in iplist]:
                mid_obj = Servers.objects.get(ip=i)
                try:
                    server_list_data[mid_obj.module.business_id].append({'ip': i,
                                                                         'source': mid_obj.source})
                except Exception, e:
                    server_list_data[mid_obj.module.business_id] = [{'ip': i,
                                                                     'source': mid_obj.source}]
            ret = []
            errorlist = []
            # 读取windows脚本
            script_mid = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'server_config_win'), 'r').read()
            # y是业务id
            for y in server_list_data.keys():
                # 重新封装ip数据,应对esb升级
                ip_list_temp = [{"ip": server_list_data[y][0]["ip"], "bk_cloud_id": server_list_data[y][0]["source"]}]
                # 执行脚本,跳到下面的方法中
                get_data = self.script_server_info(y, ip_list_temp, 'admin', script_mid, self.accout)
                # 数据整理，因为目前只操作单个服务器，所以没效果
                if get_data['result']:
                    ret = ret + get_data['data']
                else:
                    # 对应错误列表，目前不知道怎么用
                    errorlist = errorlist + [{'ip': i, 'error': get_data['data']} for i in server_list_data[y]]
            return {'success': ret, 'error': errorlist}
        except Exception, e:
            return False

    # 服务器信息获取,组合脚本，运行脚本,针对脚本执行结果分析数据并返回
    def script_server_info(self, app_id, ip_list, creator, script, accout='system'):
        try:
            get_config_result = esb_tools.execute_script(bk_biz_id=app_id, script_content=script, ip_list=ip_list,
                                                         system_executor=accout)
            result = esb_tools.get_log_content_by_response(get_config_result, app_id)
            res_list = result.split("\n")
            data_list = []
            ip = ip_list[0]["ip"]
            val = []
            caption_count = 1  # 因为数据中有两个caption，所以用这个分割
            # 分割字符串，组合起对应接口的数据
            for i in res_list:
                if i and i != "@@@@@@@@@@":
                    item = {}
                    data = i.strip()
                    item_name = data.split("=")[0]
                    item_value = data.split("=")[1]
                    item["key"] = item_name
                    item["value"] = item_value

                    if item_name == u"Caption":
                        item["display"] = SERVER_INFO_DICT[item_name + "_" + str(caption_count)]
                        caption_count = caption_count + 1
                    else:
                        item["display"] = SERVER_INFO_DICT[item_name]
                    val.append(item)
            data_list.append({"ip": ip, "val": val})
            res_data = {"result": True, "data": data_list}
            return res_data
        except Exception, e:
            logger.exception(u"script_server_info,服务器全局信息获取异常")
            return {"result": False, "data": str(e)}

    # 获取目标下的文件目录,即对应tomcat下部署的应用
    def get_file_dir(self, pathindex):
        try:
            ret = []
            for i in self.ip_list:
                if not i['path'].get(pathindex, False):
                    return {'result': False, 'data': {}}
                mid_path = i['path'].get(pathindex, '').split('\\')
                ip_list_new = []
                ip_list_new.append({"ip": i["ip"], "bk_cloud_id": i["source"]})
                mid_path.pop()
                mid_path[-1] = 'webapps'
                mid_path = '\\'.join(mid_path)
                mid_script = '''@echo off
                dir /B %s
                ''' % (mid_path)
                get_config_result = esb_tools.execute_script(bk_biz_id=i['app_id'], script_content=mid_script,
                                                             ip_list=ip_list_new, system_executor="system")
                res_data = esb_tools.get_log_content_by_response(get_config_result, bk_biz_id=i['app_id'])
                comback = {"ip": i['ip'], "logContent": res_data, "result": True}
                id = i['id']
                path = i["path"]
                result = True
                ret.append({"comback": comback, "id": id, "result": result, "path": path})
            return {'result': True, 'data': ret}
        except Exception, e:
            logger.exception(u"get_file_dir,执行异常")
            return {'result': False, 'data': str(e)}

    # 获取大多数的服务器信息，使用jmx
    def get_tomcat_jmx(self):
        ret = {}
        for i in self.ip_list:
            # 判断是否有文件存在，没有则在后面传输
            if tools.has_file_windows(i["app_id"], [{"ip": i["ip"], "bk_cloud_id": i["source"]}],
                                      JMXCMD_PATH_WINDOWS + 'cmdline-jmxclient-0.10.3.jar'):
                logger.info(u'确认 jmx jar 包已存在')
            else:
                logger.info(u'确认 jmx jar 包不存在，开始重新上传')
                # 根据固定ip拿到指定的服务器信息,没拿到就用默认的信息
                # module_item = Module.objects.get(id=SOURCE_BUSINESS)
                # server_item = module_item.servers_set.get(ip=SOURCE_IP)
                # get_ip_data = get_host_ip([SOURCE_IP])
                # if get_ip_data['result']:
                #     file_source = [
                #         {
                #             "files": [
                #                 SOURCE_URL + 'cmdline-jmxclient-0.10.3.jar'
                #             ],
                #             "account": SOURCE_ACCOUNT,
                #             "ip_list": [
                #                 {
                #                     "bk_cloud_id": get_ip_data['data']['source'],
                #                     "ip": server_item.ip
                #                 }
                #             ]
                #         }
                #     ]
                # else:
                #     file_source = [
                #         {
                #             "files": [
                #                 SOURCE_URL + 'cmdline-jmxclient-0.10.3.jar'
                #             ],
                #             "account": SOURCE_ACCOUNT,
                #             "ip_list": [
                #                 {
                #                     "bk_cloud_id": 0,
                #                     "ip": "192.168.2.154"
                #                 }
                #             ]
                #         }
                #     ]
                #     # 传输文件
                # if tools.fast_push_file_windows(biz_id=i["app_id"], file_source=file_source,
                #                                 target_path=JMXCMD_PATH_WINDOWS,
                #                                 ip_list=[{"ip": i["ip"], "bk_cloud_id": i["source"]}]):
                if fast_push_file(i["ip"],'system'):
                    logger.info(u'jmx文件分发成功')
                else:
                    logger.error(u'get_tomcat_jmx,jmx文件分发失败')
                    return False
            try:
                # jmx命令列表
                cmd_list = ['Catalina:type=Server stateName',
                            'Catalina:type=Server shutdown',
                            'Catalina:type=Service name',
                            'Catalina:type=Engine name',
                            'Catalina:type=Engine defaultHost',
                            'Catalina:type=Connector,port=*',
                            'Catalina:type=Host,host=* name',
                            'Users:type=User,username=\"*\",database=UserDatabase username',
                            'java.lang:type=Memory HeapMemoryUsage',
                            r'java.lang:type=MemoryPool,name="PS Perm Gen" Usage',
                            r'java.lang:type=MemoryPool,name="Perm Gen" Usage',
                            r'java.lang:type=MemoryPool,name="Metaspace" Usage',
                            ]
                # 根据命令列表整理并执行脚本
                logger.info(u"整理并执行jmx脚本")
                first_ret = tools.execute_formated_script(cmd_list, i)
                logger.info(u"脚本执行结束,开始数据整理")
                ret_list = [z for z in first_ret.split('!____!')]
                # 去掉头部的空行
                ret_list.pop(0)
                # 针对性导入结果数据
                mid_ret = {
                    'HeapMemoryUsage': {},
                    'Usage': {},
                    'user': {},
                    'stateName': tools.back_last(ret_list[0]),
                    'shutdown': tools.back_last(ret_list[1]),
                    'Service': {
                        'name': tools.back_last(ret_list[2]),
                        'Connector': [],
                        'Engine': {
                            'name': tools.back_last(ret_list[3]),
                            'defaultHost': tools.back_last(ret_list[4]),
                            'host': []
                        }
                    }
                }
                four_key_list = ['committed', 'init', 'max', 'used']
                for heap_cell in ret_list[8].split('\n'):
                    if heap_cell:
                        for ke in four_key_list:
                            if ke in heap_cell:
                                mid_ret['HeapMemoryUsage'][ke] = heap_cell.split(':')[1].rstrip().lstrip()
                mid_ret_str = ret_list[9] + ret_list[10] + ret_list[11]
                for usage in mid_ret_str.split('\n'):
                    for ke in four_key_list:
                        if ke in usage:
                            mid_ret['Usage'][ke] = usage.split(':')[1].rstrip().lstrip()
                connect_list = [m for m in ret_list[5].split('\n') if m]
                connect_cmd = []
                key_list = ['port', 'protocol', 'connectionTimeout', 'redirectPort']
                for x in connect_list:
                    for keys in key_list:
                        connect_cmd.append(x + ' ' + keys)
                # connect_ret = commands_fast(connect_cmd, i)
                if 'Can be set only once' in ret_list[6]:
                    host_list = ['Catalina:host=%s,type=Host' % (mid_ret['Service']['Engine']['defaultHost'])]
                else:
                    host_list = ['Catalina:host=%s,type=Host' % (tools.back_last(c)) for c in ret_list[6].split('\n') if
                                 c]
                host_key_list = ['name', 'appBase', 'unpackWARs', 'autoDeploy']
                host_cmd = []
                for x in host_list:
                    for keys in host_key_list:
                        host_cmd.append(x + ' ' + keys)
                # host_ret = commands_fast(host_cmd, i)

                user_list = []
                user_cmd_list = []
                for u in ret_list[7].split('\n'):
                    if u:
                        try:
                            if 'username=' in u:
                                mid_user = u.split('username="')[1].split('"')[0]
                                user_cmd_list.append(
                                    r'Users:database=UserDatabase,type=User,username=\"%s\" roles' % (mid_user))
                                user_list.append(mid_user)
                            if 'username:' in u:
                                mid_user = u.split('username:')[1].lstrip().rstrip()
                                user_cmd_list.append(
                                    r'Users:database=UserDatabase,type=User,username=\"%s\" roles' % (mid_user))
                                user_list.append(mid_user)
                        except Exception, e:
                            logger.exception(u"User查询异常")
                ret_cmd = connect_cmd + ['echo @@@@@@@@@@@@@'] + host_cmd + ['echo @@@@@@@@@@@@@'] + user_cmd_list
                logger.info(u"脚本2执行")
                all_ret = tools.execute_formated_script(ret_cmd, i)
                logger.info(u"脚本2执行结束,整理数据")
                all_ret_list = [r for r in all_ret.split('@@@@@@@@@@@@@')]
                connect_ret = all_ret_list[0]
                host_ret = all_ret_list[1]
                user_ret = all_ret_list[2]
                for n in connect_ret.split('!____!'):
                    num = mid_ret['Service']['Connector'].__len__()
                    if num == 0:
                        mid_ret['Service']['Connector'] = [{}]
                        num = 1
                    for zx in key_list:
                        if zx in n:
                            if mid_ret['Service']['Connector'][num - 1].get(zx, False):
                                mid_ret['Service']['Connector'].append({zx: tools.back_last(n)})
                            else:
                                mid_ret['Service']['Connector'][num - 1][zx] = tools.back_last(n)

                for n in host_ret.split('!____!'):
                    num = mid_ret['Service']['Engine']['host'].__len__()
                    if num == 0:
                        mid_ret['Service']['Engine']['host'] = [{}]
                        num = 1
                    for zx in host_key_list:
                        if zx in n:
                            if mid_ret['Service']['Engine']['host'][num - 1].get(zx, False):
                                mid_ret['Service']['Engine']['host'].append({zx: tools.back_last(n)})
                            else:
                                mid_ret['Service']['Engine']['host'][num - 1][zx] = tools.back_last(n)

                user_num = 0
                for q in user_ret.split('!____!'):
                    if 'rolename=' in q:
                        mid_ret['user'][user_list[user_num]] = []
                        for qc in q.split('\n'):
                            if 'rolename=' in qc:
                                mid_role_name = qc.split('rolename=')[1].split(',')[0]
                                mid_ret['user'][user_list[user_num]].append(mid_role_name)
                        user_num = user_num + 1
            except Exception, e:
                logger.exception(u'get_tomcat_jmx,,jmx脚本执行异常')
                return False
            ret[i['id']] = mid_ret
        return ret

    def get_weblogic_wlst(self):
        try:
            # self.run_weblogic_wlst()
            ret = []
            for i in self.ip_list:
                wlst_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wlst_windows'), 'r').read()
                mw_obj = Middleware.objects.get(id=i['id'])
                wlst_path = mw_obj.configpath_set.get(key='wlst').value
                if 'wlst.cmd' in wlst_path:
                    pass
                else:
                    if wlst_path.endswith('\\'):
                        wlst_path = wlst_path + 'wlst.cmd'
                    else:
                        wlst_path = wlst_path + '\\wlst.cmd'
                wlst_accout = mw_obj.configpath_set.get(key='accout').value
                wlst_pass = mw_obj.configpath_set.get(key='pass').value
                wlst_pass = encryption.decrypt(wlst_pass)
                wlst_url = mw_obj.ip
                wlst_prot = mw_obj.port
                run_path = wlst_path.replace('wlst.cmd', '')
                mid_i = {'id': i['id'], 'path': i['path']}
                if wlst_path == '' or wlst_accout == '' or wlst_url == '' or wlst_prot == '':
                    mid_i['result'] = False
                    mid_i['error'] = u'凭据不全'
                    ret.append(mid_i)
                    continue

                file_extend = i["app_id"]
                mid_script = wlst_py.replace("%@path", run_path)
                mid_script = mid_script.replace("%@extend", str(file_extend))
                mid_script = mid_script.replace("%@name", wlst_accout)
                mid_script = mid_script.replace("%@passwd", wlst_pass)
                mid_script = mid_script.replace("%@ip", wlst_url)
                mid_script = mid_script.replace("%@port", wlst_prot)
                ip_list = [{'ip': i['ip'], 'bk_cloud_id': i['source']}]
                get_config_result = esb_tools.execute_script(bk_biz_id=i['app_id'], script_content=mid_script,
                                                             ip_list=ip_list, system_executor=self.accout)
                result_data = esb_tools.get_log_content_by_response(get_config_result, i["app_id"])
                # text = str(result_data).split("\n")[1]
                # if text=="":
                #     text = str(result_data).split("\n")[0]
                text = str(result_data).replace('&lt;', '<').replace('&gt;', '>')
                text = text.lstrip()
                if '_____' in text:
                    text = text.split('_____')[1].split('_____')[0]
                comback = {"ip": i["ip"], "logContent": text, "result": True}
                ret.append({"comback": comback, "id": i["id"], "path": i["path"], "result": True})
            return {'result': True, 'data': ret}
        except Exception, e:
            logger.exception(u"get_weblogic_wlst,获取weblogic信息异常")
            return False

    def get_apache_base_config(self):
        return {'httpd': self.script_result_httpd, 'vhost': self.script_result_vhost}

    def run_apache(self):
        try:
            ret = []
            for i in self.ip_list:
                # wlst_py = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'wlst'), 'r').read()
                mw_obj = Middleware.objects.get(id=i['id'])
                version_path = mw_obj.configpath_set.get(key='version').value
                apachectl_url = ''
                if version_path.endswith('\\'):
                    apachectl_url = version_path + 'httpd'
                else:
                    apachectl_url = version_path + '\\httpd'
                mid_script = '''@echo off
                %s -v''' % (apachectl_url)
                mid_i = {'id': i['id'], 'path': i['path']}
                ip_list_item = [{"ip": i["ip"], "bk_cloud_id": i["source"]}]
                get_config_result = esb_tools.execute_script(bk_biz_id=i["app_id"], script_content=mid_script,
                                                             ip_list=ip_list_item, system_executor=self.accout)
                res_data = esb_tools.get_log_content_by_response(get_config_result, i["app_id"])
                text = res_data
                text = text.replace('&lt;', '<').replace('&gt;', '>')
                text = text.lstrip()
                comback = {"ip": i["ip"], "logContent": text, "result": True}
                ret.append({"comback": comback, "id": i["id"], "path": i["path"], "result": True})
            return {'result': True, 'data': ret}
        except Exception, e:
            logger.exception(u"run_apache,获取apache版本信息异常")
            return False

    def get_file_tomcat(self, index):
        try:
            ret = []
            for i in self.ip_list:
                if not i['script'].get(index, False):
                    return {'result': False, 'data': {}}
                mid_i = {'id': i['id'], 'path': i['path']}
                mid_script = i['script'][index]
                ip_list_item = [{"ip": i["ip"], "bk_cloud_id": i["source"]}]
                get_config_result = esb_tools.execute_script(bk_biz_id=i["app_id"], script_content=mid_script,
                                                             ip_list=ip_list_item, system_executor=self.accout)
                res_data = esb_tools.get_log_content_by_response(get_config_result, i["app_id"])
                text = res_data
                text = text.replace('&lt;', '<').replace('&gt;', '>')
                text = text.lstrip()
                comback = {"ip": i["ip"], "logContent": text, "result": True}
                ret.append({"comback": comback, "id": i["id"], "path": i["path"], "result": True})
            return {'result': True, 'data': ret}
        except Exception, e:
            logger.exception(u"获取tomcat基础" + index + u"信息时异常")
            return False
