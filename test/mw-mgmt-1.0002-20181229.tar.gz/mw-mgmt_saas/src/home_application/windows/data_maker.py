# -*- coding: utf-8 -*-
from home_application.models import Middleware
from common.log import logger
from home_application.windows import tools

# 所有正式写入数据库的方法


# ----------------------------------------------------------------------
# tomcat处理




# 写入tomcat信息
def make_tomcat_data(data):
    for keys in data.keys():
        a = data[keys]
        mw_obj = Middleware.objects.get(id=keys)
        try:
            tomcat_jvm_cell(mw_obj, a)
        except Exception, e:
            logger.exception(u"tomcat,jvm信息写入异常")
        try:
            tomcat_config_cell(mw_obj, a)
        except Exception, e:
            logger.exception(u"tomcat,配置信息写入异常")
        try:
            tomcat_user_cell(mw_obj, a)
        except Exception, e:
            logger.exception(u"tomcat,用户信息写入异常")


# jvm信息写入
def tomcat_jvm_cell(mw_obj, a):
    if mw_obj.configtype_set.filter(name='jvm'):
        mw_obj.configtype_set.filter(name='jvm').update(
            **{'name': 'jvm', 'display': 'JVM配置', 'xml': '', 'xml_path': ''})
        next_obj = mw_obj.configtype_set.get(name='jvm')
    else:
        next_obj = mw_obj.configtype_set.create(
            **{'name': 'jvm', 'display': 'JVM配置', 'xml': '', 'xml_path': ''})
    next_obj.configitem_set.all().delete()
    if a.get('error', False):
        next_obj.configitem_set.filter(key='error').delete()
        next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})
    else:
        item_val = a['HeapMemoryUsage']
        heap_key = {'max': u'堆最大分配空间', 'used': u'当前堆使用空间'}
        for z in heap_key.keys():
            if item_val[z] == '-1':
                mid_val = '-1'
            else:
                try:
                    mid_val = '%.2f' % (float(item_val[z]) / float(1048576)) + 'MB'
                except:
                    mid_val = ''
            next_obj.configitem_set.create(**{'value': mid_val, 'display': heap_key[z], 'key': z})
        item_val = a['Usage']
        heap_key = {'max': u'持久堆内存最大分配空间', 'used': u'持久堆内存使用大小'}
        for z in heap_key.keys():
            if item_val[z] == '-1':
                mid_val = '-1'
            else:
                try:
                    mid_val = '%.2f' % (float(item_val[z]) / float(1048576)) + 'MB'
                except:
                    mid_val = ''
            next_obj.configitem_set.create(**{'value': mid_val, 'display': heap_key[z], 'key': z})

# 配置信息写入
def tomcat_config_cell(mw_obj, a):
    if mw_obj.configtype_set.filter(name='server'):
        mw_obj.configtype_set.filter(name='server').update(
            **{'name': 'server', 'display': 'tomcat配置', 'xml': '', 'xml_path': ''})
        next_obj = mw_obj.configtype_set.get(name='server')
    else:
        next_obj = mw_obj.configtype_set.create(
            **{'name': 'server', 'display': 'tomcat配置', 'xml': '', 'xml_path': ''})
    next_obj.configitem_set.all().delete()
    if a.get('error', False):
        next_obj.configitem_set.filter(key='error').delete()
        next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})
    else:
        next_obj.configitem_set.create(**{'value': a['stateName'], 'display': 'stateName', 'key': 'stateName'})
        next_obj.configitem_set.create(**{'value': a['shutdown'], 'display': 'shutdown', 'key': 'shutdown'})
        service_data = a['Service']
        try:
            service_val = [{'key': 'name', 'display': 'name', 'value': service_data['name']}]
            for connects in service_data['Connector']:
                mid_val = []
                for z in ['port', 'protocol', 'connectionTimeout', 'redirectPort']:
                    mid_val.append({'key': z, 'display': z, 'value': connects[z]})
                service_val.append({'key': 'Connector', 'display': 'Connector', 'value': mid_val, 'rgtypeof': True})
            mid_en_val = []
            engine_data = service_data['Engine']
            mid_en_val.append({'key': 'name', 'display': 'name', 'value': engine_data['name']})
            mid_en_val.append({'key': 'defaultHost', 'display': 'defaultHost', 'value': engine_data['defaultHost']})
            for host_cell in service_data['Engine']['host']:
                mid_val = []
                for z in ['name', 'appBase', 'unpackWARs', 'autoDeploy']:
                    mid_val.append({'key': z, 'display': z, 'value': host_cell[z]})
                mid_en_val.append({'key': 'Host', 'display': 'Host', 'value': mid_val, 'rgtypeof': True})
            service_val.append({'key': 'Engine', 'display': 'Engine', 'value': mid_en_val, 'rgtypeof': True})
            next_obj.configitem_set.create(**{'value': service_val, 'display': 'Service', 'key': 'Service'})
        except Exception, e:
            print e

# 用户信息写入
def tomcat_user_cell(mw_obj, a):
    if mw_obj.configtype_set.filter(name='user'):
        mw_obj.configtype_set.filter(name='user').update(
            **{'name': 'user', 'display': '权限配置', 'xml': '', 'xml_path': ''})
        next_obj = mw_obj.configtype_set.get(name='user')
    else:
        next_obj = mw_obj.configtype_set.create(
            **{'name': 'user', 'display': '权限配置', 'xml': '', 'xml_path': ''})
    next_obj.configitem_set.all().delete()
    if a.get('error', False):
        logger.error(str(a['error']))
        next_obj.configitem_set.filter(key='error').delete()
        next_obj.configitem_set.create(**{'value': str(a['error']), 'display': u'错误', 'key': u'error'})
    else:
        for user_cell in a['user'].keys():
            try:
                mid_role = ','.join(a['user'][user_cell])
            except:
                mid_role = ''
            mid_val = [{'key': 'username', 'display': 'username', 'value': user_cell},
                       {'key': 'roles', 'display': 'roles', 'value': mid_role}]
            next_obj.configitem_set.create(**{'value': mid_val, 'display': 'User', 'key': 'user'})

# -----------------------------------------------------------------------------------------------------------------
# weblogic处理

def comeback_weblogic_version(data):
    weblogic_version_list = data.split('WebLogic Server')
    for i in reversed(weblogic_version_list):
        if '.' in i:
            i = i.replace(' ', '')
            return '.'.join(i.split('.')[0:3])
    return ''


def make_weblogic_data(data,ip_list,bk_biz_id):
    key_cmdb = {'AdminServerName': 'admin_server_name', 'RootDirectory': 'root_dir', 'WeblogicVersion': 'version',
                'ConsoleEnabled': 'console_enabled', 'WeblogicHome': 'weblogic_home',
                'ProductionModeEnabled': 'production_mode_enabled', 'MiddlewareHome': 'md_home',
                'AdminConsole': 'admin_console', 'ConsoleContextPath': 'console_context_path',
                'DomainVersion': 'domain_version'}
    inst_key_cmdb = {'Name': 'name', 'ListenAddress': 'ip_addr', 'ListenPort': 'listen_port',
                     'HealthState': 'health_state', 'State': 'state', 'JavaVersion': 'java_version',
                     'AdminServerName': 'admin_server_name', 'RootDirectory': 'root_dir',
                     'ConsoleEnabled': 'console_enabled', 'WeblogicHome': 'weblogic_home',
                     'ProductionModeEnabled': 'production_mode_enabled', 'MiddlewareHome': 'md_home',
                     'ConsoleContextPath': 'console_context_path', 'WeblogicVersion': 'version',
                     'DomainVersion': 'domain_version', 'patch_path': 'patch_path'}
    if data['result']:
        for d in data['data']:
            oid = d['id']
            mid_obj = Middleware.objects.get(id=oid)
            try:
                bk_data = eval(mid_obj.bk_data)
            except:
                bk_data = {}
            if mid_obj.configtype_set.filter(name='root'):
                mid_obj.configtype_set.filter(name='root').update(
                    **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
                root_obj = mid_obj.configtype_set.get(name='root')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'root', 'display': '基本配置', 'xml': '', 'xml_path': ''})
            if mid_obj.configtype_set.filter(name='server'):
                mid_obj.configtype_set.filter(name='server').update(
                    **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
                server_obj = mid_obj.configtype_set.get(name='server')
            else:
                server_obj = mid_obj.configtype_set.create(
                    **{'name': 'server', 'display': '实例配置', 'xml': '', 'xml_path': ''})
            # root_obj.configitem_set.all().delete()
            # server_obj.configitem_set.all().delete()

            if d['result']:
                admin_data = bk_data.get('admin', {})
                data = d['comback']['logContent']
                try:
                    data = eval(data)
                except:
                    root_obj.configitem_set.filter(key='error').delete()
                    server_obj.configitem_set.filter(key='error').delete()
                    if bk_data.get('admin', False):
                        make_cmdb_to_weblogic_config(root_obj, server_obj, bk_data, key_cmdb, inst_key_cmdb)
                    else:
                        if root_obj.configitem_set.filter(key='error'):
                            root_obj.configitem_set.filter(key='error').update(
                                **{'value': str(data), 'display': u'错误', 'key': u'error'})
                        else:
                            root_obj.configitem_set.create(**{'value': str(data), 'display': u'错误', 'key': u'error'})
                        if server_obj.configitem_set.filter(key='error'):
                            server_obj.configitem_set.filter(key='error').update(
                                **{'value': str(data), 'display': u'错误', 'key': u'error'})
                        else:
                            server_obj.configitem_set.create(**{'value': str(data), 'display': u'错误', 'key': u'error'})
                server_ret = []
                server_list = [data['root']['AdminServerName']]
                for xi in data['root']['Servers'].keys():
                    if xi not in server_list:
                        server_list.append(xi)
                for i in server_list:
                    mid_dict = dict(data['root']['Servers'][i],
                                    **data['domain_run_time']['ServerRuntimes'].get(i,
                                                                                    {'HealthState': '', 'State': ''}))
                    try:
                        mid_jvm = data['domain_run_time']['ServerRuntimes'][i]['JVMRuntime'][i]
                    except:
                        mid_jvm = {}
                    mid_dict = dict(mid_dict, **mid_jvm)
                    if data['domain_run_time'].get('ServerServices', False):
                        services_data = data['domain_run_time']['ServerServices'].get(i, False)
                        if services_data:
                            mid_domain_data = services_data['RuntimeService']['DomainConfiguration']
                            domain_data = mid_domain_data[mid_domain_data.keys()[0]]
                            domain_data['DomainName'] = domain_data['Name']
                            server_runtime_data = services_data['RuntimeService']['ServerRuntime'][i]
                            mid_domain_dict = dict(domain_data, **server_runtime_data)
                            mid_dict = dict(mid_domain_dict, **mid_dict)
                    mid_key = []
                    m_home = ''
                    weblogic_version = ''
                    listen_ip = ''
                    for g in ['Name', 'ListenAddress', 'ListenPort', 'HealthState', 'State', 'JavaVersion',
                              'AdminServerName', 'RootDirectory', 'ConsoleEnabled', 'WeblogicHome',
                              'ProductionModeEnabled',
                              'MiddlewareHome', 'ConsoleContextPath', 'WeblogicVersion', 'DomainVersion']:
                        mid_vl = mid_dict.get(g, '')
                        if g == 'MiddlewareHome':
                            m_home = mid_vl
                        if g == 'ListenAddress':
                            listen_ip = mid_vl
                        if g == 'WeblogicVersion':
                            weblogic_version = mid_vl
                        if g == 'HealthState':
                            try:
                                mid_vl = mid_vl.split('State:')[1].split(',')[0]
                            except:
                                pass
                        if g == 'ListenAddress':
                            if mid_vl == '':
                                mid_vl = mid_obj.ip
                        mid_key.append({'key': g, 'display': g, 'value': mid_vl})
                    if weblogic_version:
                        if comeback_weblogic_version(weblogic_version).split('.')[0] >= '12':
                            patch_path = m_home + '\\OPatch\\opatch'
                        else:
                            patch_path = m_home + '\\utils\\bsu\\bsu.cmd'
                        if listen_ip == '':
                            listen_ip = d['comback']['ip']
                        if tools.has_file_windows(bk_biz_id,ip_list,patch_path):
                            mid_key.append({'key': 'patch_path', 'display': 'patch_path', 'value': patch_path})
                        else:
                            mid_key.append({'key': 'patch_path', 'display': 'patch_path', 'value': ''})
                    else:
                        mid_key.append({'key': 'patch_path', 'display': 'patch_path', 'value': ''})
                    displayi = ''
                    if data['root']['AdminServerName'] == i:
                        displayi = u'管理实例：' + i
                    else:
                        displayi = u'应用实例：' + i
                    server_ret.append({'key': i, 'display': displayi, 'value': mid_key})
                mid_ret = dict(data['root'], **data['server_run_time'])
                try:
                    mid_ret['AdminConsole'] = mid_ret['AdminConsole'][mid_ret['AdminConsole'].keys()[0]][
                        'SessionTimeout']
                except:
                    pass
                mid_ret.pop('Servers')
                root_obj.configitem_set.filter(key='error').delete()
                server_obj.configitem_set.filter(key='error').delete()

                for z in mid_ret.keys():
                    # has key
                    mid_val = mid_ret[z]
                    if root_obj.configitem_set.filter(key=z):
                        if mid_val:
                            # has new key  update
                            root_obj.configitem_set.filter(key=z).update(
                                **{'key': z, 'display': z, 'value': mid_val, 'can_modify': False})
                        else:
                            # no new key
                            mid_root = root_obj.configitem_set.get(key=z)
                            cmdb_mid_data = admin_data.get(key_cmdb[z], False)
                            if cmdb_mid_data:
                                root_obj.configitem_set.filter(key=z).update(
                                    **{'key': z, 'display': z, 'value': cmdb_mid_data, 'can_modify': True})
                            else:
                                # old_val = mid_root.value
                                mid_root.can_modify = True
                                mid_root.save()
                    else:
                        if mid_val == '':
                            mid_val = admin_data.get(key_cmdb[z], '')
                        root_obj.configitem_set.create(**{'key': z, 'display': z, 'value': mid_val})
                for x in server_ret:
                    listen_port = ''
                    mid_val = x['value']
                    for xz in mid_val:
                        if xz['key'] == 'ListenPort':
                            listen_port = xz['value']
                            break
                    try:
                        inst_data_cmdb = bk_data['inst'].get(listen_port, {})
                    except:
                        inst_data_cmdb = {}
                    if server_obj.configitem_set.filter(key=x['key']):
                        old_server_mid_val = eval(server_obj.configitem_set.get(key=x['key']).value)
                        old_server_val = {}
                        for old_mi in old_server_mid_val:
                            old_server_val[old_mi['key']] = old_mi
                        for xz in mid_val:
                            if xz['value'] == '':
                                xz['value'] = inst_data_cmdb.get(inst_key_cmdb.get(xz['key'], ''), '')
                                xz['can_modify'] = True
                            if xz['value'] == '':
                                xz['value'] = old_server_val[xz['key']]['value']
                                xz['can_modify'] = True
                        server_obj.configitem_set.filter(key=x['key']).update(**{'value': mid_val})
                    else:
                        for xz in mid_val:
                            if xz['value'] == '':
                                xz['value'] = inst_data_cmdb.get(inst_key_cmdb.get(xz['key'], ''), '')
                                xz['can_modify'] = True
                        x['value'] = mid_val
                        server_obj.configitem_set.create(**x)
            else:
                root_obj.configitem_set.filter(key='error').delete()
                server_obj.configitem_set.filter(key='error').delete()
                if bk_data.get('admin', False):
                    make_cmdb_to_weblogic_config(root_obj, server_obj, bk_data, key_cmdb, inst_key_cmdb)
                else:
                    root_obj.configitem_set.create(**{'value': str(d['error']), 'display': u'错误', 'key': u'error'})
                    server_obj.configitem_set.create(**{'value': str(d['error']), 'display': u'错误', 'key': u'error'})


def make_cmdb_to_weblogic_config(root_obj, server_obj, bk_data, key_cmdb, inst_key_cmdb):
    for z in key_cmdb.keys():
        if root_obj.configitem_set.filter(key=z):
            root_obj.configitem_set.filter(key=z).update(
                **{'key': z, 'display': z, 'value': bk_data['admin'].get(key_cmdb[z], ''),
                   'can_modify': True})
        else:
            root_obj.configitem_set.create(
                **{'key': z, 'display': z, 'value': bk_data['admin'].get(key_cmdb[z], ''),
                   'can_modify': True})
    if bk_data['inst']:
        for z in bk_data['inst'].values():
            mid_val = []
            for x in inst_key_cmdb.keys():
                mid_val.append({'key': x, 'display': x, 'value': z.get(inst_key_cmdb[x], ''), 'can_modify': True})
            if server_obj.configitem_set.filter(key=z['name']):
                server_obj.configitem_set.filter(key=z['name']).update(
                    **{'key': z['name'], 'display': z['name'], 'value': mid_val,
                       'can_modify': True})
            else:
                server_obj.configitem_set.create(
                    **{'key': z['name'], 'display': z['name'], 'value': mid_val,
                       'can_modify': True})

def make_weblogic_monitor(data):
    if data['result']:
        for d in data['data']:
            mw_obj = Middleware.objects.get(id=d['id'])
            try:
                xml_data = eval(d['comback']['logContent'])
            except:
                xml_data = {}
            name_list = [m.name for m in mw_obj.instance_set.all()]
            for i in mw_obj.configtype_set.get(name='server').configitem_set.all():
                service_dict = eval(i.value)
                mid_key = ''
                mid_val = ''
                mid_all = {'admin_server': str(d['id']) + '%%' + mw_obj.ip + ':' + mw_obj.port}
                for z in service_dict:
                    if z['key'] == 'Name':
                        mid_key = z['value']
                    if z['key'] == 'ListenPort':
                        mid_val = z['value']
                    if z['key'] == 'WeblogicHome':
                        if z['value']:
                            if z['value'].endswith('\\'):
                                mid_all['wlst'] = z['value'] + 'common\\bin\\wlst.cmd'
                            else:
                                mid_all['wlst'] = z['value'] + '\\common\\bin\\wlst.cmd'
                        else:
                            mid_all['wlst'] = ''
                    if z['key'] == 'ListenAddress':
                        if z['value']:
                            mid_all['ip'] = z['value']
                        else:
                            mid_all['ip'] = mw_obj.ip
                    if z['key'] == 'ListenPort':
                        mid_all['port'] = z['value']
                    if z['key'] == 'WeblogicVersion':
                        mid_all['WeblogicVersion'] = z['value']
                    if z['key'] == 'patch_path':
                        mid_all['patch_path'] = z['value']
                val_name = mid_key + '(' + mid_val + ')'
                if mw_obj.instance_set.filter(name=val_name):
                    next_obj = mw_obj.instance_set.get(name=val_name)
                    next_obj.value = str(mid_all)
                    next_obj.save()
                    name_list.remove(val_name)
                else:
                    next_obj = mw_obj.instance_set.create(name=val_name, value=str(mid_all))
                next_obj.application_set.all().delete()
                try:
                    for c in xml_data['app'].get(mid_key, []):
                        next_obj.application_set.create(name=c)
                except Exception, e:
                    pass
            for z in name_list:
                mw_obj.instance_set.filter(name=z).delete()


# ------------------------------------------------------------------------------------
# apache处理
APACHE_ITEM = ['User', 'Group', 'ServerAdmin', 'DocumentRoot', 'ServerName']
APACHE_DEFULT = {'Timeout': '60', 'KeepAlive': 'on', 'KeepAliveTimeout': '5', 'MaxKeepAliveRequests': '100'}

# apache的httpd信息写入
def make_apache_data_httpd(data):
    if data['result']:
        for a in data['data']:
            data = a['comback']['logContent']
            oid = a['id']
            mid_obj = Middleware.objects.get(id=oid)
            httpd_url = mid_obj.configpath_set.get(key='httpd').value
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_httpd'), 'r').read()
            port_list = []
            module_list = []
            inclue_list = []
            base_item = {}
            default_tiem = APACHE_DEFULT
            for i in data.split('\n'):
                i = i.rstrip()
                i = i.lstrip()
                if not i.startswith('#'):
                    if 'Listen' in i:
                        port_list.append(i.split(' ')[1])
                    if 'LoadModule' in i:
                        split_mid = i.split(' ')
                        module_list.append({'key': split_mid[1], 'value': split_mid[2], 'display': split_mid[1]})
                    for z in APACHE_ITEM:
                        if i.startswith(z):
                            mid_li_vl = i.split(' ')
                            mid_li_vl[0] = ''
                            base_item[z] = ' '.join(mid_li_vl)
                    if 'Include' in i:
                        inclue_list.append(i.split(' ')[1])
                    for g in APACHE_DEFULT.keys():
                        if i.startswith(g):
                            default_tiem[g] = i.split(' ')[1]
            base_item['Include'] = inclue_list
            if mid_obj.configtype_set.filter(name='httpd'):
                mid_obj.configtype_set.filter(name='httpd').update(
                    **{'name': 'httpd', 'display': 'httpd配置', 'xml': data, 'xml_path': httpd_url})
                root_obj = mid_obj.configtype_set.get(name='httpd')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'httpd', 'display': 'httpd配置', 'xml': data, 'xml_path': httpd_url})
            root_obj.configitem_set.exclude(key='version').delete()
            for y in base_item.keys():
                root_obj.configitem_set.create(**{'key': y, 'display': y, 'value': base_item[y]})
            for y in default_tiem.keys():
                root_obj.configitem_set.create(**{'key': y, 'display': y, 'value': default_tiem[y]})
            root_obj.configitem_set.create(**{'key': 'listen', 'display': 'listen', 'value': ','.join(port_list)})
            root_obj.configitem_set.create(**{'key': 'LoadModule', 'display': 'LoadModule', 'value': module_list})

# apache的版本信息写入
def make_apache_data_version(data):
    if data['result']:
        for a in data['data']:
            data = a['comback']['logContent']
            oid = a['id']
            mid_obj = Middleware.objects.get(id=oid)
            httpd_url = mid_obj.configpath_set.get(key='httpd').value
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_httpd'), 'r').read()
            version_data = ''
            for i in data.split('\n'):
                i = i.rstrip()
                i = i.lstrip()
                if 'Server version:' in i:
                    version_data = i.replace('Server version:', '')
                    version_data.rstrip()
                    version_data.lstrip()

            if mid_obj.configtype_set.filter(name='httpd'):
                mid_obj.configtype_set.filter(name='httpd').update(
                    **{'name': 'httpd', 'display': '基本配置配置'})
                root_obj = mid_obj.configtype_set.get(name='httpd')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'httpd', 'display': '基本配置配置'})
            if root_obj.configitem_set.filter(key='version'):
                root_obj.configitem_set.filter(key='version').update(**{'value': version_data})
            else:
                root_obj.configitem_set.create(**{'key': 'version', 'display': 'version', 'value': version_data})

# apache的host信息写入
def make_apache_data_httpd_host(data):
    if data['result']:
        for a in data['data']:
            data = a['comback']['logContent']
            oid = a['id']
            mid_obj = Middleware.objects.get(id=oid)
            httpd_url = mid_obj.configpath_set.get(key='vhost').value
            # data = open(os.path.join(os.path.join(PROJECT_ROOT, 'script'), 'test_httpd_host'), 'r').read()
            ret = {}
            mid_ret = {}
            for i in data.split('\n'):
                if not i.startswith('#'):
                    i = i.rstrip()
                    i = i.lstrip()
                    if '<VirtualHost' in i:
                        mid_key = i.split(':')[-1][:-1]
                        ret[mid_key] = {}
                        mid_ret = ret[mid_key]
                    if 'WebLogicHost' in i:
                        mid_ret['WebLogicHost'] = i.split(' ')[1]
                    if 'WebLogicPort' in i:
                        mid_ret['WebLogicPort'] = i.split(' ')[1]
                    if 'MatchExpression' in i:
                        mid_ret['MatchExpression'] = i.split(' ')[1]
            final_ret = []
            for i in ret.keys():
                mid_val = []
                for z in ret[i].keys():
                    mid_val.append({'key': z, 'display': z, 'value': ret[i][z]})
                final_ret.append({'key': i, 'display': i, 'rgtypeof': True, 'value': mid_val})

            if mid_obj.configtype_set.filter(name='vhost'):
                mid_obj.configtype_set.filter(name='vhost').update(
                    **{'name': 'vhost', 'display': '反向代理配置', 'xml': data, 'xml_path': httpd_url})
                root_obj = mid_obj.configtype_set.get(name='vhost')
            else:
                root_obj = mid_obj.configtype_set.create(
                    **{'name': 'vhost', 'display': '反向代理配置', 'xml': data, 'xml_path': httpd_url})
            root_obj.configitem_set.all().delete()
            for p in final_ret:
                root_obj.configitem_set.create(**{'key': p['key'], 'display': p['display'], 'value': p['value']})


# ------------------------------------------------------------------------------------
# 全局信息处理

# 写入服务器基本信息
def make_server_info_data(base_data):
    try:
        for a in base_data['success']:
            for b in Middleware.objects.filter(ip=a['ip']):
                if b.configtype_set.filter(name='os'):
                    next_obj = b.configtype_set.get(name='os')
                else:
                    next_obj = b.configtype_set.create(**{'name': 'os', 'display': '服务器配置'})
                next_obj.configitem_set.all().delete()
                if type(a['val']) == type([]):
                    for c in a['val']:
                        next_obj.configitem_set.create(**c)
                else:
                    next_obj.configitem_set.filter(key='error').delete()
                    next_obj.configitem_set.create(**{'value': str(a['val']), 'display': u'错误', 'key': u'error'})
        for c in base_data['error']:
            for d in Middleware.objects.filter(ip=c['ip']):
                if d.configtype_set.filter(name='os'):
                    next_obj = d.configtype_set.get(name='os')
                else:
                    next_obj = d.configtype_set.create(**{'name': 'os', 'display': '服务器配置'})
                next_obj.configitem_set.all().delete()
                next_obj.configitem_set.create(**{'value': str(c['error']), 'display': u'错误', 'key': u'error'})
    except Exception,e:
        logger.exception(u"make_server_info_data,服务器基本信息写入异常")


# -------------------------------------------------------------------------------------------
# monitor信息处理


# 写入tomcat应用
def make_monitor_data(data):
    try:
        if data['result']:
            for a in data['data']:
                xml_data = a['comback']['logContent']
                applist = xml_data.split('\n')

                mw_obj = Middleware.objects.get(id=a['id'])
                service_data = mw_obj.configtype_set.get(name='server').configitem_set.get(key='Service').value
                service_dict = eval(service_data)
                mid_connect = []
                servername = ''
                for i in service_dict:
                    if i['key'] == 'name':
                        servername = i['value']
                    if i['key'] == 'Connector':
                        for u in i['value']:
                            if u['key'] == 'protocol' and ('HTTP' in u['value']):
                                mid_connect = i['value']
                mid_port = ''
                for z in mid_connect:
                    if z['key'] == 'port':
                        mid_port = servername + '(' + z['value'] + ')'
                if mw_obj.instance_set.filter(name=mid_port):
                    nextobj = mw_obj.instance_set.get(name=mid_port)
                else:
                    nextobj = mw_obj.instance_set.create(name=mid_port)
                nextobj.application_set.all().delete()
                for y in applist:
                    if y:
                        nextobj.application_set.create(name=y)
    except Exception,e:
        logger.exception(u"make_monitor_data,tomcat应用信息写入异常")

