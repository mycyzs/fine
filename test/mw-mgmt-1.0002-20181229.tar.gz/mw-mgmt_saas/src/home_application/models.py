# -*- coding: utf-8 -*-

from django.db import models

# 中间件类型
class MiddlewareType(models.Model):
    name = models.CharField(max_length=20)
    creator = models.CharField(max_length=20)
    create_time = models.CharField(max_length=30)




# 中间件主表
class Middleware(models.Model):
    state_state_choices = (
        ("waitting", "waitting"),
        ("running", "running"),
        ("success", "success"),
        ("fail", "fail")
    )
    ip = models.CharField(max_length=100)
    is_cluster = models.BooleanField(default=False)
    is_time = models.BooleanField(default=False)
    port = models.CharField(max_length=10,null=True,default="")
    state = models.CharField(max_length=10,choices=state_state_choices,default='waitting')
    java_version = models.CharField(max_length=10,null=True,default="")
    is_delete=models.BooleanField(default=False)
    creator= models.CharField(max_length=20)
    create_time= models.CharField(max_length=30)
    bk_inst_id= models.CharField(max_length=50,null=True,default='')
    last_time= models.CharField(max_length=50,null=True,default='')
    bk_data= models.TextField(null=True,default='')
    type = models.ForeignKey(MiddlewareType,null=True)

# 配置路径
class ConfigPath(models.Model):
    key = models.CharField(max_length=100)
    value = models.TextField(default="")
    display = models.CharField(max_length=100,null=True,default="")
    midware = models.ForeignKey(Middleware)

# 配置类型
class ConfigType(models.Model):
    name = models.CharField(max_length=100)
    display = models.CharField(max_length=100)
    xml = models.TextField(null=True,default="")
    xml_path = models.TextField(null=True,default="")
    midware = models.ForeignKey(Middleware)


# 配置项
class ConfigItem(models.Model):
    key = models.CharField(max_length=100)
    value = models.TextField(default="")
    display = models.CharField(max_length=100, null=True, default="")
    can_modify = models.BooleanField(default=False)
    config_type = models.ForeignKey(ConfigType)

class HistoryMiddleware(models.Model):
    midware = models.ForeignKey(Middleware)
    create_time = models.CharField(max_length=100)

# 配置类型历史
class HistoryConfigType(models.Model):
    name = models.CharField(max_length=100)
    display = models.CharField(max_length=100)
    xml = models.TextField(null=True,default="")
    xml_path = models.TextField(null=True,default="")
    midware = models.ForeignKey(HistoryMiddleware)


# 配置项历史
class HistoryConfigItem(models.Model):
    key = models.CharField(max_length=100)
    value = models.TextField(default="")
    display = models.CharField(max_length=100, null=True, default="")
    can_modify = models.BooleanField(default=False)
    config_type = models.ForeignKey(HistoryConfigType)

# 实例
class Instance(models.Model):
    name = models.CharField(max_length=100)
    value = models.TextField(null=True,default='')
    midware = models.ForeignKey(Middleware)

# 应用
class Application(models.Model):
    name = models.CharField(max_length=100)
    instance = models.ForeignKey(Instance)


# 配置类型配置
class SettingConfigType(models.Model):
    name = models.CharField(max_length=100)
    display = models.CharField(max_length=100)
    middle_type=models.ForeignKey(MiddlewareType)


# 配置项配置
class SettingConfigItem(models.Model):
    key = models.CharField(max_length=100)
    display = models.CharField(max_length=100, null=True, default="")
    is_default = models.BooleanField(default=False)
    setting_mid_type = models.ForeignKey(SettingConfigType)

# 配置方案
class SettingPlan(models.Model):
    name = models.CharField(max_length=100)
    display = models.CharField(max_length=100)
    creator = models.CharField(max_length=20)
    create_time = models.CharField(max_length=30)
    config_detail = models.TextField()
    middle_type = models.ForeignKey(MiddlewareType)

# 配置路径配置
# class SettingConfigPath(models.Model):
#     key = models.CharField(max_length=100)
#     value = models.CharField(max_length=100)
#     display = models.CharField(max_length=100,null=True,default="")
#     plan = models.ForeignKey(SettingPlan)


# 业务
class Business(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    created_by = models.CharField(max_length=100)
    when_created = models.CharField(max_length=100)



# 模块
class Module(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    business = models.ForeignKey(Business)




# 服务器
class Servers(models.Model):
    module = models.ForeignKey(Module, null=True)
    ip = models.CharField(max_length=100)
    operation_system = models.CharField(max_length=200, default="")
    hostname = models.CharField(max_length=100, default="")
    sys_type = models.CharField(max_length=10, default="")
    source = models.CharField(max_length=100, null=True, default="")
    is_delete = models.BooleanField(default=False)

# 运维人员
class Userinfo(models.Model):
    name = models.CharField(max_length=50)
    when_created = models.CharField(max_length=50)
    mailbox = models.CharField(max_length=100,null=True,default='')

# 日志
class Logs(models.Model):
    operated_type = models.CharField(max_length=50)
    content = models.TextField()
    when_created = models.CharField(max_length=30)
    operator = models.CharField(max_length=50)

#巡检任务
class Task(models.Model):
    task_name = models.CharField(max_length=50)
    creator = models.CharField(max_length=50)
    when_create = models.CharField(max_length=30)
    mw_id_list = models.TextField()


#巡检报告
class Report(models.Model):
    task = models.ForeignKey(Task)
    discript = models.CharField(max_length=50)
    when_create = models.CharField(max_length=30)
    when_end = models.CharField(max_length=30)
#巡检报告中间件
class Report_mw(models.Model):
    mw_type = models.CharField(max_length=20)
    mw_name = models.CharField(max_length=40)
    mw_info = models.TextField(null=True,default='')
    report = models.ForeignKey(Report)
    discript = models.CharField(max_length=50)
#巡检报告分类
class Report_group(models.Model):
    key = models.CharField(max_length=20)
    display = models.CharField(max_length=20)

#巡检报告小项
class Report_item(models.Model):
    type = models.CharField(max_length=30)
    key = models.CharField(max_length=30)
    value = models.TextField(null=True,default='')
    display = models.CharField(max_length=20)
    iswarn = models.BooleanField(default=False)
    warn_color = models.CharField(max_length=15)

#巡检报告分类配置
class Config_report_group(models.Model):
    mw_type = models.CharField(max_length=20)
    key = models.CharField(max_length=20)
    display = models.CharField(max_length=20)

#巡检报告小项配置
class Config_report_item(models.Model):
    type = models.CharField(max_length=30)
    key = models.CharField(max_length=30)
    display = models.CharField(max_length=20)
    compare = models.CharField(max_length=5)
    compare_value = models.TextField(null=True, default='')
    warn_color = models.CharField(max_length=15)

class Setting(models.Model):
    key = models.CharField(max_length=50)
    value = models.CharField(max_length=50)
    display = models.CharField(max_length=50)
    disc = models.TextField()