# -*- coding: utf-8 -*-
from account.decorators import login_exempt
from django.views.decorators.csrf import csrf_exempt
from home_application.models import *
from common.mymako import render_json
from common.log import logger
from django.db.models import Q

@login_exempt
@csrf_exempt
def get_mw_by_id(request):
    try:
        get_id = request.GET.get('id')
        if get_id:
            ret = Middleware.objects.filter(id=get_id).values()[0]
            mw_obj = Middleware.objects.get(id=get_id)
            ret['cred'] = {}
            server_obj = Servers.objects.get(ip = mw_obj.ip)
            ret['source'] = server_obj.source
            ret['business_id'] = server_obj.module.business_id
            ret['sys_type'] = server_obj.sys_type
            if mw_obj.type.name=='weblogic':
                try:
                    ret['weblogic_version'] = mw_obj.configtype_set.get(name='root').configitem_set.get(key='WeblogicVersion').value
                except:
                    ret['weblogic_version'] = ''
                ret['instance'] = []
                try:
                    for instance_data in mw_obj.configtype_set.get(name='server').configitem_set.all():
                        try:
                            mid_data = eval(instance_data.value)
                            mid_dict = {}
                            for item in mid_data:
                                mid_dict[item['key']] = item['value']
                            ret['instance'].append(mid_dict)
                        except:
                            pass
                except:
                    pass
            for i in mw_obj.configpath_set.all():
                ret['cred'][i.key] = i.value
        else:
            get_data = request.GET.dict()
            get_name = get_data.get('name','')
            if get_data.get('port',False):
                port_search = "'%s'"%(get_data['port'])
            else:
                port_search = ''
            ip_search =get_data.get('ip', '')
            ret = []
            has_id = []
            for instance in Instance.objects.filter(name__contains=get_name).filter(Q(value__contains=ip_search)&Q(value__contains=port_search)):
                mw_id = instance.midware_id
                if str(mw_id) in has_id:
                    continue
                has_id.append(str(mw_id))
                mid_ret = Middleware.objects.filter(id=mw_id).values()[0]
                mw_obj = Middleware.objects.get(id=mw_id)
                mid_ret['cred'] = {}
                server_obj = Servers.objects.get(ip=mw_obj.ip)
                mid_ret['source'] = server_obj.source
                mid_ret['business_id'] = server_obj.module.business_id
                mid_ret['sys_type'] = server_obj.sys_type
                if mw_obj.type.name == 'weblogic':
                    try:
                        mid_ret['weblogic_version'] = mw_obj.configtype_set.get(name='root').configitem_set.get(
                            key='WeblogicVersion').value
                    except:
                        mid_ret['weblogic_version'] = ''
                    mid_ret['instance'] = []
                    try:
                        for instance_data in mw_obj.configtype_set.get(name='server').configitem_set.all():
                            try:
                                mid_data = eval(instance_data.value)
                                mid_dict = {}
                                for item in mid_data:
                                    mid_dict[item['key']] = item['value']
                                mid_ret['instance'].append(mid_dict)
                            except:
                                pass
                    except:
                        pass
                for i in mw_obj.configpath_set.all():
                    mid_ret['cred'][i.key] = i.value
                ret.append(mid_ret)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})
