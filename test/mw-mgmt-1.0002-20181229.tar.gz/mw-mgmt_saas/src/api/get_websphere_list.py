# -*- coding: utf-8 -*-
from account.decorators import login_exempt
from django.views.decorators.csrf import csrf_exempt
from home_application.models import *
from common.mymako import render_json
from common.log import logger
from home_application.celery_tasks import start_config
import json


@login_exempt
@csrf_exempt
def get_websphere(request):
    try:
        type_obj = MiddlewareType.objects.get(name='websphere')
        ret = []
        for i in type_obj.middleware_set.all():
            base_data = {'text': i.ip+':'+i.port,'id':i.id}
            ret.append(base_data)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})



