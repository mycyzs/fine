# -*- coding: utf-8 -*-
from account.decorators import login_exempt
from django.views.decorators.csrf import csrf_exempt
from home_application.models import *
from common.mymako import render_json
from common.log import logger
from home_application.celery_tasks import start_config
import json
@login_exempt
@csrf_exempt
def get_weblogic_list(request):
    try:
        type_obj = MiddlewareType.objects.get(name='weblogic')
        ret = []
        for i in type_obj.middleware_set.all():
            server_dict = eval(i.configtype_set.get(name='server').configitem_set.get(key='server').value)
            base_data ={'ip':i.ip,'java_version':i.java_version}
            for r in i.configtype_set.get(name='root').configitem_set.all():
                base_data[r.key]=r.value
            for z in server_dict:
                mid_server = {'instance_name':z['display']}
                for y in z['value']:
                    mid_server[y['key']] = y['value']
                    if y['key'] == 'HealthState':
                        try:
                            mid_server[y['key']] = mid_server[y['key']].split('State:')[1].split(',')[0]
                        except:
                            pass
                    if y['key'] == 'ListenPort':
                        search_name = '%s(%s)' % (z['display'], y['value'])
                        mid_id = i.instance_set.filter(name=search_name)[0].id
                        mid_server['instance_id'] = mid_id
                mid_ret = dict(base_data,**mid_server)
                if not mid_ret.get('ListenAddress',False):
                    mid_ret['ListenAddress'] = mid_ret['ip']
                ret.append(mid_ret)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})


@login_exempt
@csrf_exempt
def get_weblogic(request):
    try:
        type_obj = MiddlewareType.objects.get(name='weblogic')
        ret = []
        for i in type_obj.middleware_set.all():
            base_data = {'text': i.ip+':'+i.port,'id':i.id}
            ret.append(base_data)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})


@login_exempt
@csrf_exempt
def get_weblogic_instance(request):
    try:
        type_obj = MiddlewareType.objects.get(name='weblogic')
        ret = []
        for i in type_obj.middleware_set.all():
            for z in i.instance_set.all():
                try:
                    mid_data = eval(z.value)
                    if mid_data['WeblogicVersion']:
                        base_data = {'text': mid_data['ip']+':'+mid_data['port'],'id':z.id}
                        ret.append(base_data)
                except Exception,e:
                    logger.error('instance_list:'+str(e))
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})


@login_exempt
@csrf_exempt
def get_weblogic_instance_by_id(request):
    try:
        get_id = request.GET.get('id')
        inst_obj = Instance.objects.get(id=get_id)
        ret = eval(inst_obj.value)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})


@login_exempt
@csrf_exempt
def run_instance_idlist(request):
    try:
        get_id_list = json.loads(request.body)['idlist']
        for i in Instance.objects.filter(id__in=get_id_list).values('midware_id').distinct():
            start_config.delay([i['midware_id']])
        logger.error(u'weblogic update comeback:'+str(get_id_list))
        return render_json({"result": True})
    except Exception,e:
        logger.error(u'weblogic update comeback error:' + str(e))
        return render_json({"result": False, "data": str(e)})