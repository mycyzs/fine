# -*- coding: utf-8 -*-
from account.decorators import login_exempt
from django.views.decorators.csrf import csrf_exempt
from home_application.models import *
from common.mymako import render_json
from common.log import logger

@login_exempt
@csrf_exempt
def get_apache_list(request):
    try:
        type_obj = MiddlewareType.objects.get(name='apache')
        ret = []
        for i in type_obj.middleware_set.all():
            base_data = {'ip': i.ip,'Include':[],'ServerName':'','id':i.id,'java_version':i.java_version}
            for r in i.configtype_set.get(name='httpd').configitem_set.all():
                base_data[r.key] = r.value
                if r.key == 'LoadModule':
                    try:
                        mid_load = {}
                        for p in eval(base_data[r.key]):
                            mid_load[p['key']] = p['value']
                        base_data[r.key] = mid_load
                    except:
                        pass
            vhost_data = []
            for r in i.configtype_set.get(name='vhost').configitem_set.all():
                mid_vhost = {'VirtualHost':r.key}
                try:
                    for z in eval(r.value):
                        mid_vhost[z['key']] = z['value']
                except:
                    pass
                vhost_data.append(mid_vhost)
            base_data['vhost'] = vhost_data
            ret.append(base_data)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})


@login_exempt
@csrf_exempt
def get_apache(request):
    try:
        type_obj = MiddlewareType.objects.get(name='apache')
        ret = []
        for i in type_obj.middleware_set.all():
            base_data = {'text': i.ip+':'+i.port,'id':i.id}
            ret.append(base_data)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})