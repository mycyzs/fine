# -*- coding: utf-8 -*-
from account.decorators import login_exempt
from django.views.decorators.csrf import csrf_exempt
from home_application.models import *
from common.mymako import render_json
from common.log import logger

@login_exempt
@csrf_exempt
def get_tomcat_list(request):
    try:
        type_obj = MiddlewareType.objects.get(name='tomcat')
        ret = []
        for i in type_obj.middleware_set.all():
            pass
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})


@login_exempt
@csrf_exempt
def get_tomcat(request):
    try:
        type_obj = MiddlewareType.objects.get(name='tomcat')
        ret = []
        for i in type_obj.middleware_set.all():
            base_data = {'text': i.ip+':'+i.port,'id':i.id}
            ret.append(base_data)
        return render_json({"result": True, "data":ret})
    except Exception,e:
        return render_json({"result": False, "data": str(e)})