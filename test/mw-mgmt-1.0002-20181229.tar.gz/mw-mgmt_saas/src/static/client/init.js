﻿var app = angular.module("myApp", ['myController', 'utilServices', 'myDirective', 'ui.bootstrap', 'ui.router', 'webApiService', 'rgLeftMenu', 'ngGrid']);
var controllers = angular.module("myController", []);
var directives = angular.module("myDirective", []);


app.config(["$stateProvider", "$urlRouterProvider", "$httpProvider", function ($stateProvider, $urlRouterProvider, $httpProvider) {
    $httpProvider.defaults.headers.post['X-CSRFToken'] = $("#csrf").val();
    $urlRouterProvider.otherwise("/mw_type_manage");//默认展示页面
    $stateProvider.state('home', {
        url: "/home",
        controller: "home",
        templateUrl: static_url + "client/views/home.html"
    }).state('tomcat_manage', {//tomcat
            url: "/tomcat_manage",
            controller: "tomcat_manage",
            templateUrl: static_url + "client/views/middleware_manage/tomcat/tomcat_manage.html"
        }).state('tomcat_monitor', {//tomcat监控
            url: "/tomcat_monitor",
            controller: "tomcat_monitor",
            templateUrl: static_url + "client/views/middleware_manage/tomcat/tomcat_monitor.html"
        }).state('weblogic_manage', {//tomcat
            url: "/weblogic_manage",
            controller: "weblogic_manage",
            templateUrl: static_url + "client/views/middleware_manage/weblogic/tomcat_manage.html"
        }).state('weblogic_monitor', {//tomcat监控
            url: "/weblogic_monitor",
            controller: "weblogic_monitor",
            templateUrl: static_url + "client/views/middleware_manage/weblogic/tomcat_monitor.html"
        }).state('apache_manage', {//tomcat
            url: "/apache_manage",
            controller: "apache_manage",
            templateUrl: static_url + "client/views/middleware_manage/apache/tomcat_manage.html"
        }).state('apache_monitor', {//apache监控
            url: "/apache_monitor",
            controller: "apache_monitor",
            templateUrl: static_url + "client/views/middleware_manage/apache/tomcat_monitor.html"
        }).state('websphere_manage', {//tomcat
            url: "/websphere_manage",
            controller: "websphere_manage",
            templateUrl: static_url + "client/views/middleware_manage/websphere/tomcat_manage.html"
        }).state('websphere_monitor', {//apache监控
            url: "/websphere_monitor",
            controller: "websphere_monitor",
            templateUrl: static_url + "client/views/middleware_manage/websphere/tomcat_monitor.html"
        }).state('jboss_manage', {//tomcat
            url: "/jboss_manage",
            controller: "jboss_manage",
            templateUrl: static_url + "client/views/middleware_manage/jboss/tomcat_manage.html"
        }).state('jboss_monitor', {//tomcat监控
            url: "/jboss_monitor",
            controller: "jboss_monitor",
            templateUrl: static_url + "client/views/middleware_manage/jboss/tomcat_monitor.html"
        })
        .state('businessManage', {//系统管理
            url: "/businessManage",
            controller: "businessManage",
            templateUrl: static_url + "client/views/sys_manage/businessManage.html"
        })
        .state('operationLog', {//系统管理
            url: "/operationLog",
            controller: "operationLog",
            templateUrl: static_url + "client/views/sys_manage/operationLog.html"
        })
    .state('userManage', {
            url: "/userManage",
            controller: "userManage",
            templateUrl: static_url + "client/views/sys_manage/userManage.html"
        }).state('mw_type_manage', {
            url: "/mw_type_manage",
            controller: "mw_type_manage",
            templateUrl: static_url + "client/views/sys_manage/mw_type_manage.html"
        }).state('plan_manage', {
            url: "/plan_manage",
            controller: "plan_manage",
            templateUrl: static_url + "client/views/sys_manage/plan_manage.html"
        }).state('setting', {
            url: "/setting",
            controller: "setting",
            templateUrl: static_url + "client/views/sys_manage/setting.html"
        })
}]);
