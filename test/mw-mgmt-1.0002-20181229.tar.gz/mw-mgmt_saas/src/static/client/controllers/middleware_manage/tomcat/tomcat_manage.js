controllers.controller('tomcat_manage', ["$scope", "midService", "loading", "confirmModal", "msgModal", "$modal", function ($scope, midService, loading, confirmModal, msgModal, $modal) {
    $scope.filterObj = {
        name: ''
    };
    $scope.table_data = [];
    $scope.table_option = {
        bottom: 30,
        data: 'table_data',
        title: [
            {title: 'IP', rgwidth: '10%', rghtml: '<a ng-click="show(i.id)">{{i.ip}}</a>',thtml: '<div  ng-init="a={op:true}">' +
            '<span style="cursor: pointer" ng-show="a.op" ng-click="search(\'ip\',\'\');a.op=false;">IP<i class="fa fa-angle-up"></i></span>' +
            '<span style="cursor: pointer" ng-show="!a.op" ng-click="search(\'ip\',\'-\');a.op=true;">IP<i class="fa fa-angle-down"></i></span>' +
            '</div>'},
            {
                title: '是否群集',
                rgwidth: '6%',
                rghtml: '<span ng-if="i.is_cluster">是</span><span ng-if="!i.is_cluster">否</span>'
            },
            {title: '访问端口', rgwidth: '6%', enname: 'port'},
            {
                title: '状态',
                rgwidth: '6%',
                rghtml: '<span ng-if="i.state==\'waitting\'">获取数据中</span><span ng-if="i.state==\'fail\'" style="color: red;">错误</span><span ng-if="i.state==\'success\'" style="color: green;">成功</span>'
            },
            {title: 'java版本', rgwidth: '6%', enname: 'java_version'},
            {
                title: '是否定时备份',
                rgwidth: '8%',
                rghtml: '<span ng-if="i.is_time">是</span><span ng-if="!i.is_time">否</span>'
            },
            {title: '最近一次备份', rgwidth: '10%', enname: 'new_time'},
            {title: '创建者', rgwidth: '6%', enname: 'creator'},
            {title: '创建时间', rgwidth: '10%', enname: 'create_time'},
            {
                title: '操作', rgwidth: '30%', rghtml: '<div>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-info" ng-click="detail(i.id)">详情</button>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-success" ng-click="config(i.id)">备份</button>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-default" ng-click="sync(i.id)">同步</button>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-primary" ng-click="modify(i.id)">修改</button>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-danger" ng-click="del(i.id)">删除</button>' +
            '</div>'
            }
        ]
    };
    $scope.sync = function (id) {
        confirmModal.open({
            text: "是否要开始同步配置？",
            confirmClick: function () {
                loading.open();
                midService.sync_mw({}, {id: id}, function (res) {
                    loading.close();
                    if (res.result) {
                        msgModal.open("success", "同步开启成功！");
                    } else {
                        msgModal.open("error", "同步开启失败，请联系管理员！");
                    }
                })
            }
        })
    };
    var minby = function (name) {
        return function (o, p) {
            var a, b;
            if (typeof o === "object" && typeof p === "object" && o && p) {
                a = o[name];
                b = p[name];
                if (a === b) {
                    return 0;
                }
                if (typeof a === typeof b) {
                    return a < b ? -1 : 1;
                }
                return typeof a < typeof b ? -1 : 1;
            }
            else {
                throw ("error");
            }
        }
    }
    var maxby = function (name) {
        return function (o, p) {
            var a, b;
            if (typeof o === "object" && typeof p === "object" && o && p) {
                a = o[name];
                b = p[name];
                if (a === b) {
                    return 0;
                }
                if (typeof a === typeof b) {
                    return a > b ? -1 : 1;
                }
                return typeof a > typeof b ? -1 : 1;
            }
            else {
                throw ("error");
            }
        }
    }
    $scope.search = function (field, op) {
        $scope.field = field
        $scope.field_op = op
        loading.open();
        midService.get_middle_ware({}, {type: 'tomcat', 'ip': $scope.filterObj.name}, function (res) {
            loading.close();
            if (res.result) {
                if (field || op) {
                    if (op == '') {
                        res.data.sort(maxby(field))
                    } else {
                        res.data.sort(minby(field))
                    }
                }
                $scope.table_data = res.data;
            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        })
    };
    $scope.search();
    $scope.config = function (id) {
        confirmModal.open({
            text: "是否要备份？",
            confirmClick: function () {
                loading.open();
                midService.sync_middle_ware({}, {id: id}, function (res) {
                    loading.close();
                    if (res.result) {
                        msgModal.open("success", "同步成功！");
                        $scope.search()
                    } else {
                        msgModal.open("error", "同步失败，请联系管理员！");
                        $scope.search()
                    }
                })
            }
        })
    };
    $scope.add = function () {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/middleware_manage/tomcat/add_tomcat.html',
            windowClass: 'add_tomcat',
            controller: 'add_tomcat',
            backdrop: 'static',
            resolve: {}
        });
        modalInstance.result.then(function (res) {
            $scope.search()
        })
    };
    $scope.del = function (id) {
        confirmModal.open({
            text: "是否要删除？",
            confirmClick: function () {
                loading.open();
                midService.del_middleware({}, {id: id}, function (res) {
                    loading.close();
                    if (res.result) {
                        msgModal.open('success', '删除成功');
                        $scope.search()
                    } else {
                        msgModal.open("error", "删除失败");
                        console.log(res.error)
                    }
                })
            }
        })
    };
    $scope.modify = function (id) {
        var modalInstances = $modal.open({
            templateUrl: static_url + 'client/views/middleware_manage/tomcat/modify_tomcat.html',
            windowClass: 'modify_tomcat',
            controller: 'modify_tomcat',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return id
                }
            }
        });
        modalInstances.result.then(function (res) {
            $scope.search()
        })
    };
    $scope.detail = function (id) {
        var modalInstances = $modal.open({
            templateUrl: static_url + 'client/views/middleware_manage/tomcat/detail_tomcat.html',
            windowClass: 'detail_tomcat',
            controller: 'detail_tomcat',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return id
                }
            }
        });
        modalInstances.result.then(function (res) {
        })
    };
    $scope.show_detail = {detail: false};
    $scope.base_data = {};
    $scope.item_data = [];
    $scope.time_list = [];
    $scope.time_data = [];
    $scope.show_index = 0;
    $scope.his_index = 'now';
    $scope.change_tab = function (index) {
        $scope.show_index = index;
    };
    $scope.chose_his = function (data) {
        if (data == 'now') {
            $scope.item_data = $scope.all_data.item_data;
        } else {
            $scope.item_data = $scope.time_data[data];
        }
    };
    $scope.all_data = {};
    $scope.show = function (id) {
        loading.open();
        midService.get_middle_ware_config_item({}, {id: id}, function (res) {
            loading.close();
            if (res.result) {
                $scope.all_data = angular.copy(res.data);
                $scope.base_data = res.data.base_data;
                $scope.item_data = res.data.item_data;
                $scope.time_list = res.data.his_data.time;
                $scope.time_data = res.data.his_data.data;
                $scope.show_detail.detail = true;
                setTimeout(function () {
                    $('.bg_box').addClass('action');
                    $('.rg_name').parent('.fir_tab').css('border-bottom', 'none');
                    $('.rg_name').click(function () {
                        var sil_obj = $(this).siblings('.rg_tab');
                        $(sil_obj).toggleClass("rgaction")
                        $(this).toggleClass("rgaction")
                    })
                }, 200)
            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        })


    };
    $scope.hidde = function (e) {
        if ($(e.target).hasClass('bg')) {
            $('.bg_box').removeClass('action')
            setTimeout(function () {
                $scope.show_detail.detail = false
                $scope.$apply()
            }, 700)
        }
    };
    $scope.up_file = function () {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/up_file.html',
            windowClass: 'dialog_custom',
            controller: 'up_file',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return 'tomcat'
                }
            }
        });
        modalInstance.result.then(function (res) {
            $scope.search()
        })
    };
    $scope.down_file = function (id) {
        confirmModal.open({
            text: "是否要下载？",
            confirmClick: function () {
                var url = site_url+'down_mw?type=tomcat';
                window.open(url)
            }
        })
    };
}]);