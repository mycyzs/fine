controllers.controller('detail_apache', ["$scope", "midService", "msgModal", "$modalInstance", "loading", "errorModal", "confirmModal", "$modal", "objectItem", function ($scope, midService, msgModal, $modalInstance, loading, errorModal, confirmModal, $modal, objectItem) {
    $scope.title = "查看apache";
    $scope.server_list = [];
    $scope.mid_path = 'wu';
    $scope.args = {
        id: objectItem,
        ip: '',
        is_cluster: '',
        port: "",
        java_version: ""
    };
    $scope.pathconfig = [];
    $scope.path_list = [];
    $scope.plan_data = [];
    $scope.search_detail = function () {
        loading.open();
        midService.get_middle_ware_detail({}, {id: objectItem}, function (res) {
            loading.close();
            if (res.result) {
                $scope.args = res.base_data;
                $scope.pathconfig = res.plan_data;
            }
            else {
                msgModal.open('error', '获取数据错误，请联系管理员！')
            }
        })
    };
    $scope.search_detail();
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);