controllers.controller('add_weblogic', ["$scope", "midService", "msgModal", "$modalInstance", "loading", "errorModal", "confirmModal", "$modal", function ($scope, midService, msgModal, $modalInstance, loading, errorModal, confirmModal, $modal) {
    $scope.title = "添加weblogic";
    $scope.server_list = [];
    $scope.mid_path = 'wu';
    $scope.args = {
        ip: '',
        is_cluster: '0',
        is_time: '0',
        port: "",
        java_version: ""
    };
    $scope.pathconfig = [];
    $scope.path_list = [];
    $scope.plan_data = [];
    $scope.search_server = function () {
        loading.open();
        midService.get_ip_server({}, {}, function (res) {
            loading.close();
            $scope.has_model();
            if (res.result) {
                $scope.server_list = res.data;
                setTimeout(function () {
                    $(".select_two_list").select2({
                        placeholder: "请选择ip",
                        allowClear: true,
                        maximumSelectionSize: 3
                    });
                }, 200)
            } else {
                msgModal.open('error', '获取服务器数据失败，请联系管理员！');
            }
        });
    };
    $scope.has_model = function () {
        loading.open();
        midService.has_model({}, {type: 'weblogic'}, function (res) {
            loading.close();
            if (res.result) {
                if (res.data.has) {
                    $scope.path_list = res.data.plan_list;
                    $scope.plan_data = res.data.plan_data;
                    $scope.mid_path = $scope.path_list[0].id + '';
                    $scope.pathconfig = res.data.plan_data[$scope.path_list[0].id];

                } else {
                    $scope.pathconfig = res.data.data;
                }
            }
            else {
                msgModal.open('error', '获取模板错误，请联系管理员！')
            }
        })
    };
    $scope.search_server();
    $scope.choose_path = function () {
        id_mid = $('#path_list').val();
        $scope.pathconfig = angular.copy($scope.plan_data[id_mid])
    };
    $scope.confirm = function () {
        $scope.args.ip = $(".select_two_list").select2("val");
        if (!CWApp.isIP($scope.args.ip)) {
            msgModal.open("error", "请选择IP");
            return;
        }
        if ($scope.args.port == '') {
            msgModal.open("error", "请填写端口！");
            return;
        }
        // if ($scope.args.java_version == '') {
        //     msgModal.open("error", "请填写JAVA版本！");
        //     return;
        // }
        var mid_path = ''
        if ($scope.path_list.length != 0) {
            mid_path = $('#path_list').val()
        }
        loading.open();
        midService.add_middleware({}, {
            'base': $scope.args,
            'config': $scope.pathconfig,
            tpye: 'weblogic',
            'path': mid_path
        }, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "添加成功！");
                if (res.save) {
                    confirmModal.open({
                        text: "是否保存为模板？",
                        confirmClick: function () {
                            $scope.savepath_model({
                                'config': $scope.pathconfig,
                                tpye: 'weblogic'
                            })
                        },
                        cancelClick: function () {
                            $modalInstance.close();
                        }
                    })
                } else {
                    var mid_os = $('.os_type_mid').text();
                    if (mid_os == 'Linux') {
                        localStorage.web_mw_plan_id = mid_path;
                    } else if (mid_os == 'Windows') {
                        localStorage.web_mw_plan_win_id = mid_path;
                    }
                    $modalInstance.close();
                }
            }
            else {
                if (res.message) {
                    msgModal.open("error", res.message);
                } else {
                    msgModal.open("error", '添加失败，请联系管理员！');
                }
            }
        })
    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
    $scope.savepath_model = function (get_data) {
        var modalInstances = $modal.open({
            templateUrl: static_url + 'client/views/sys_manage/save_plan.html',
            windowClass: 'save_plan',
            controller: 'save_plan',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return get_data
                }
            }
        });
        modalInstances.result.then(function (res) {
            $modalInstance.close();
        })
    }
    $scope.chose_ip = function (ip) {
        var os = '';
        for (var i = 0; i < $scope.server_list.length; i++) {
            for (var u = 0; u < $scope.server_list[i].children.length; u++) {
                if ($scope.server_list[i].children[u].name == ip) {
                    os = $scope.server_list[i].children[u].os
                }
            }
        }
        var mid_text = '无法获取信息';
        if (os) {
            mid_text = os
        }
        $('.os_type_mid').text(mid_text);
        if (os == 'Linux') {
            if (localStorage.mw_plan_id) {
                if($scope.plan_data[localStorage.mw_plan_id]){
                    $scope.mid_path = localStorage.mw_plan_id + '';
                $scope.pathconfig = angular.copy($scope.plan_data[localStorage.mw_plan_id]);
                }

            }
        } else if (os == 'Windows') {
            if (localStorage.mw_plan_win_id) {
                if($scope.plan_data[localStorage.mw_plan_win_id]){
                    $scope.mid_path = localStorage.mw_plan_win_id + '';
                $scope.pathconfig = angular.copy($scope.plan_data[localStorage.mw_plan_win_id]);
                }

            }
        }

    }
}]);