controllers.controller('weblogic_monitor', ["$scope", "midService", "loading", "confirmModal", "msgModal", "$modal", function ($scope, midService, loading, confirmModal, msgModal, $modal) {
    $scope.filterObj={
        name:''
    };
    $scope.table_data = [];
    $scope.search = function () {
        loading.open();
        midService.get_instance_list({}, {type: 'weblogic','ip':$scope.filterObj.name}, function (res) {
            loading.close();
            if (res.result) {
                $scope.table_data = res.data;
            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        })
    };
    $scope.search();
    $scope.operate = function (id,type,name) {
        var text = '';
        if(type=='open'){
            text='开启'
        }else {
            text='关闭'
        }
        confirmModal.open({
            text: "是否要"+text+"？",
            confirmClick: function () {
                loading.open();
                midService.operate_mw({}, {id: id,type:type,name:name}, function (res) {
                    loading.close();
                    if (res.result) {
                        $scope.open_model(res.data)
                    } else {
                        msgModal.open("error", "操作失败，请联系管理员！");
                    }
                })
            }
        })
    };
    $scope.open_model = function (text) {
        confirmModal.open({
            text: text,
            confirmClick: function () {
                $scope.search();
            }
        })
    }
}]);