controllers.controller('setting', ["$scope", "sysService", "loading", "confirmModal", "msgModal", "$modal", function ($scope, sysService, loading, confirmModal, msgModal, $modal) {
    $scope.data = [];
    $scope.search = function () {
        loading.open();
        sysService.get_setting({}, {}, function (res) {
            loading.close();
            if (res.result) {
                $scope.data = res.data
            } else {
                msgModal.open('error', '获取数据失败，请联系管理员！')
            }
        })
    };
    $scope.search();
    $scope.change_has = function (op) {
        if (op.value == '1') {
            op.value = '0'
        } else {
            op.value = '1'
        }
        loading.open();
        sysService.up_setting({}, op, function (res) {
            loading.close();
            if (res.result) {

            } else {
                msgModal.open('error', '修改数据失败，请联系管理员！')
            }
        });

    };
    $scope.sync_c = function () {
        loading.open();
        sysService.sync_c({}, {}, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open('success', '开启同步！')
            } else {
                msgModal.open('error', '开启失败，请联系管理员！')
            }
        });
    };
    $scope.sync_mw = function () {
        loading.open();
        sysService.config_sync({}, {}, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open('success', '开启同步！')
            } else {
                msgModal.open('error', '开启失败，请联系管理员！')
            }
        });
    }
}]);