controllers.controller('userManage', ["$scope", "sysService", "loading", "confirmModal", "msgModal", "$modal", function ($scope, sysService, loading, confirmModal, msgModal, $modal) {
    $scope.filterObj={
        name:''
    }
    $scope.search = function () {
        loading.open()
        sysService.get_user({}, $scope.filterObj, function (res) {
            loading.close()
            if (res.result) {
                $scope.table_data = res.data
            }else{
                console.log(res.error)
                alert('服务器错误')
            }
        })
    }
    $scope.search()
    $scope.table_data = []
    $scope.table_option = {
        bottom: 30,
        data: 'table_data',
        title: [
            {title: '用户名', enname: 'name'},
            {title: '邮箱', enname: 'mailbox'},
            {title: '创建时间', enname: 'when_created'},
            {
                title: '操作', rgwidth: '200px', rghtml: '<div>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-info" ng-click="modify(i)">修改</button>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-danger" ng-click="del(i.id)">删除</button>' +
            '</div>'
            },
        ]
    }
    $scope.add_mail = function () {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/sys_manage/userAdd.html',
            windowClass: 'userAdd',
            controller: 'userAdd',
            backdrop: 'static',
            resolve: {}
        });
        modalInstance.result.then(function (res) {
            $scope.search()
        })
    }
    $scope.del = function (id) {
        confirmModal.open({
            text: "是否要删除？",
            confirmClick: function () {
                loading.open();
                sysService.del_user({}, {id: id}, function (res) {
                    loading.close()
                    if (res.result) {
                        msgModal.open('success', '删除成功')
                        $scope.search()
                    } else {
                        msgModal.open("error", "删除失败");
                        console.log(res.error)
                    }
                })
            }
        })
    }
    $scope.modify = function (data) {
        var modalInstances = $modal.open({
            templateUrl: static_url + 'client/views/sys_manage/userModify.html',
            windowClass: 'userModify',
            controller: 'userModify',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return data
                }
            }
        });
        modalInstances.result.then(function (res) {
            $scope.search()
        })
    }
}])