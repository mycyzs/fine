controllers.controller('userModify', ["$scope", "sysService", "msgModal", "$modalInstance", "loading","errorModal","objectItem", function ($scope, sysService, msgModal, $modalInstance, loading,errorModal,objectItem) {
    $scope.title = "修改运维人员";
    $scope.args = {
        id:"",
        name: "",
    };
    if(objectItem){
        $scope.args = angular.copy(objectItem)
    }
    $scope.confirm = function () {
        if($scope.args.name==''){
            msgModal.open("success","请填写用户名");
            return;
        }
        if(!CWApp.isMail($scope.args.mailbox)){
            msgModal.open("error","邮箱格式有误");
            return;
        }
        loading.open();
        sysService.modify_user({}, $scope.args, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "修改成功！");
                $modalInstance.close();
            }
            else {
                msgModal.open("error",res.error);
                console.log(res.error)
            }
        })
    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);