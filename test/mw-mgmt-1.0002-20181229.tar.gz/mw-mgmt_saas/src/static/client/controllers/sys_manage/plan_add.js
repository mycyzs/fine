controllers.controller('plan_add', ["$scope", "sysService", "msgModal", "$modalInstance", "loading", "errorModal","objectItem", function ($scope, sysService, msgModal, $modalInstance, loading, errorModal,objectItem) {

    $scope.data={};
    $scope.data_head=[];
    $scope.data_index = '';
    $scope.args = {name: ''};
    $scope.now_data = [];
    if(objectItem){
        $scope.title = "修改模板";
        $scope.data_index = angular.copy(objectItem.type_name)
        $scope.now_data = angular.copy(objectItem.config_detail)
        $scope.args.name = angular.copy(objectItem.name)
    }else {
        $scope.title = "添加模板";

    }
    $scope.search = function () {
        loading.open();
        sysService.get_plan_config({}, {}, function (res) {
            loading.close();
            if (res.result) {
                $scope.data = res.data;
                $scope.data_head = res.data_head;
            }
            else {
                msgModal.open("error",res.error);
            }
        })
    };
    $scope.search();
    $scope.choose = function (index) {
        $scope.data_index = index;
        $scope.now_data = angular.copy($scope.data[index])
    };
    $scope.confirm = function () {
        if ($scope.data_index == '') {
            msgModal.open("error", "请选择中间件类型！");
            return;
        }
        if ($scope.args.name == '') {
            msgModal.open("error", "请填写模板名称！");
            return;
        }
        var up = {
            type:$scope.data_index,
            data:{
                name:$scope.args.name,
                config_detail:$scope.now_data
            }
        };
        if(objectItem){
            up.id = objectItem.id
        }

        loading.open();
        sysService.add_plan({}, up, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "添加成功！");
                $modalInstance.close();
            }
            else {
                if(res.message){
                    msgModal.open("error",res.message);
                }else {
                    msgModal.open("error",'添加失败，请联系管理员！');
                }

            }
        })
    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);