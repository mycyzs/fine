controllers.controller('mw_type_manage', ["$scope", "sysService", "loading", "confirmModal", "msgModal", "$modal","$window", function ($scope, sysService, loading, confirmModal, msgModal, $modal,$window) {
    $scope.filterObj={
        name:''
    };
    $scope.search = function (is_reload) {
        loading.open();
        sysService.get_mw_type_list({}, $scope.filterObj, function (res) {
            loading.close();
            if (res.result) {
                $scope.table_data = res.data
            }else{
                msgModal.open('error','服务器错误')
            }
        })
    };
    $scope.rgreload = function () {
        $window.location.reload()
    };
    $scope.table_data = [];
    $scope.search();
    $scope.table_option = {
        bottom: 30,
        data: 'table_data',
        title: [
            {title: '中间件类型', enname: 'name',rgwidth:'25%'},
            {title: '创建者', enname: 'creator',rgwidth:'25%'},
            {title: '创建时间', enname: 'create_time',rgwidth:'25%'},
            {
                title: '操作', rgwidth: '25%', rghtml: '<div>' +
            // '<button style="margin: 0 3px" class="btn btn-sm btn-info" ng-click="modify(i.id)">修改配置项</button>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-danger" ng-click="del(i.id,i.name)">删除</button>' +
            '</div>'
            },
        ]
    };
    $scope.add = function () {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/sys_manage/mw_type_add.html',
            windowClass: 'mw_type_add',
            controller: 'mw_type_add',
            backdrop: 'static',
            resolve: {}
        });
        modalInstance.result.then(function (res) {
            $scope.rgreload()
        })
    };
    $scope.del = function (id,name) {
        confirmModal.open({
            text: "是否要删除？",
            confirmClick: function () {
                loading.open();
                sysService.del_mw_type({}, {id: id,name:name}, function (res) {
                    loading.close();
                    if (res.result) {
                        msgModal.open('success', '删除成功');
                        $scope.rgreload()
                    } else {
                        msgModal.open("error", "删除失败");
                    }
                })
            }
        })
    };
    $scope.modify_model = function (data,id) {
        var modalInstances = $modal.open({
            templateUrl: static_url + 'client/views/sys_manage/mw_type_modify.html',
            windowClass: 'mw_type_modify',
            controller: 'mw_type_modify',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return {data:data,id:id}
                }
            }
        });
        modalInstances.result.then(function (res) {
            $scope.search()
        })
    };
    $scope.modify = function (id) {
        loading.open();
        sysService.get_mw_type_config({}, {id: id}, function (res) {
            loading.close();
            if (res.result) {
                $scope.modify_model(res.data,id)
            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        });

    }
}]);