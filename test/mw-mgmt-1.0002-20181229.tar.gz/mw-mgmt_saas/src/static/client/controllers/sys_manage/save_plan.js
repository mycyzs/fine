controllers.controller('save_plan', ["$scope", "sysService", "msgModal", "$modalInstance", "loading", "errorModal", "objectItem", function ($scope, sysService, msgModal, $modalInstance, loading, errorModal, objectItem) {
    $scope.title = "添加模板";
    $scope.args = {
        name: "",
        display: "",
        config_detail: objectItem['config']
    };
    $scope.confirm = function () {
        if ($scope.args.name == '') {
            msgModal.open("error", "请填写模板名称!");
            return;
        }
        loading.open();
        sysService.add_plan({}, {'data': $scope.args, 'type': objectItem['tpye']}, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "添加成功！");
                var mid_os = $('.os_type_mid').text();
                if (objectItem['tpye'] == 'tomcat') {
                    if (mid_os == 'Linux') {
                        localStorage.mw_plan_id = res.new_id;
                    } else if (mid_os == 'Windows') {
                        localStorage.mw_plan_win_id = res.new_id;
                    }
                } else {
                    if (mid_os == 'Linux') {
                        localStorage.web_mw_plan_id = res.new_id;
                    } else if (mid_os == 'Windows') {
                        localStorage.web_mw_plan_win_id = res.new_id;
                    }
                }


                $modalInstance.close();
            }
            else {
                if (res.message) {
                    msgModal.open("error", res.message);
                    $modalInstance.close();
                } else {
                    msgModal.open("error", '添加失败，请联系管理员！');
                    $modalInstance.close();
                }

            }
        })
    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);