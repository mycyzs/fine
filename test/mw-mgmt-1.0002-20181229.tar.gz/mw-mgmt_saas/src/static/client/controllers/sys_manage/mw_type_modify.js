controllers.controller('mw_type_modify', ["$scope", "sysService", "msgModal", "$modalInstance", "loading", "errorModal", "objectItem", "$compile", function ($scope, sysService, msgModal, $modalInstance, loading, errorModal, objectItem, $compile) {
    $scope.title = "修改配置项";
    $scope.data = objectItem.data;
    $scope.is_loading = {op: false};
    $scope.show_index = 0;
    $scope.change_tab = function (index) {
        $scope.show_index = index;
    };
    $scope.search = function () {
        loading.open();
        sysService.get_default_mw_config({}, {id: objectItem.id}, function (res) {
            loading.close();
            if (res.result) {
                $scope.del_list = res.data;
            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        })
    };
    $scope.search();
    $scope.save = function () {
        var up = [];
        $('.choose_container').each(function () {
            var mid_up = {};
            mid_up[$(this).attr('type_name')] = [];
            var mid_obj = mid_up[$(this).attr('type_name')];
            $(this).find('.item_box').each(function () {
                var mid_json = JSON.parse($(this).attr('mid_data'));
                mid_obj.push({display:mid_json.display,key:mid_json.key,is_default:mid_json.is_default})
            });
            up.push(mid_up)
        });
        loading.open();
        sysService.up_default_mw_config({}, {id: objectItem.id,up:up}, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "保存成功！");
                $modalInstance.close();
            } else {
                msgModal.open("error", "保存失败，请联系管理员！");
            }
        })
    };
    $scope.close = function () {
        $modalInstance.close();
    };
    setTimeout(function () {
        $scope.start_drago()
    }, 200);
    $scope.del_item = function (e) {
        var move_obj = $($(e.target).parent('.move_box'));
        var mid_data = move_obj.attr('mid_data');
        var mid_index = move_obj.attr('mid_index');
        $scope.del_list[$scope.show_index].item.push(JSON.parse(mid_data));
        // $scope.data[$scope.show_index].item.splice(mid_index,1);
        move_obj.remove();
    };
    $scope.left_item = function (e) {
        var move_obj = $($(e.target).parent('.item_box'));
        var mid_data = move_obj.attr('mid_data');
        var mid_index = move_obj.attr('mid_index');
        var json_data = JSON.parse(mid_data);
        var html_text = '<li class="item_box move_box" mid_data=\'' + mid_data + '\'>' + json_data.display + '<i ng-click="del_item($event)" class="fa fa-close"></i></li>';
        var ele = $compile(html_text)($scope);
        $('.choose_container.action').append(ele);
        $scope.del_list[$scope.show_index].item.splice(mid_index, 1);
        // $scope.remove_drago();
        setTimeout(function () {
            $scope.start_drago()
        }, 200)

    };
    $scope.del_list = [];
    $scope.start_drago = function () {
        $('.choose_container').sortable();
        $('.choose_container').disableSelection();
    }
}]);