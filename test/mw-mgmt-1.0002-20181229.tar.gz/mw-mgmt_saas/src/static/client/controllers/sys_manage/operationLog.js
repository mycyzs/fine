controllers.controller('operationLog', ["$scope", "sysService", "loading", "confirmModal", "msgModal", "$modal","$filter", function ($scope, sysService, loading, confirmModal, msgModal, $modal,$filter) {
    var dateStart = new Date();
    var dateEnd = new Date();
    $scope.DateStart = dateStart.setDate(dateStart.getDate() - 29);
    $scope.DateEnd = dateEnd.setDate(dateEnd.getDate() + 1);
    $scope.filter = {
        operator: "",
        operateType: "",
        whenStart: $filter('date')($scope.DateStart, 'yyyy-MM-dd'),
        whenEnd: $filter('date')($scope.DateEnd, 'yyyy-MM-dd')
    };
    $scope.recordList = [];
    $scope.Pagingdata = [];
    $scope.totalSerItems = 0;
    $scope.search = function () {
        loading.open()
        sysService.get_log({}, $scope.filter, function (res) {
            loading.close()
            if (res.result) {
                $scope.table_data = res.data
            }
        })
    }
    $scope.search()
    $scope.table_data = []
    $scope.table_option = {
        bottom: 30,
        data: 'table_data',
        title: [
            {title: '操作类型', rgwidth: '150px', enname: 'operated_type'},
            {title: '操作内容', enname: 'content'},
            {title: '操作者', rgwidth: '150px', enname: 'operator'},
            {title: '操作时间', rgwidth: '250px', enname: 'when_created'},
        ]
    }
}])