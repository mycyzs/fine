controllers.controller('userAdd', ["$scope", "sysService", "msgModal", "$modalInstance", "loading", "errorModal", function ($scope, sysService, msgModal, $modalInstance, loading, errorModal) {
    $scope.title = "添加运维人员";
    $scope.args = {
        name: "",
        mailbox: ""
    };
    $scope.confirm = function () {
        if ($scope.args.name == '') {
            msgModal.open("error", "请填写用户名");
            return;
        }
        if (!CWApp.isMail($scope.args.mailbox)) {
            msgModal.open("error", "邮箱格式有误");
            return;
        }
        loading.open();
        sysService.add_user({}, $scope.args, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "添加成功！");
                $modalInstance.close();
            }
            else {
                msgModal.open("error",res.error);
                console.log(res.error)
            }
        })
    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);