controllers.controller('businessManage', ["$scope", "sysService", "loading", "confirmModal", "msgModal", "$modal", function ($scope, sysService, loading, confirmModal, msgModal, $modal) {
    $scope.filterObj={
        'name':''
    }
    $scope.search = function () {
        loading.open();
        sysService.get_business_list({}, $scope.filterObj, function (res) {
            loading.close();
            if (res.result) {
                $scope.table_data = res.data
            }
        })
    };
    $scope.search();

    $scope.table_data = [];
    $scope.table_option = {
        bottom: 30,
        data: 'table_data',
        title: [
            {title: '业务名称', enname: 'name'},
            {title: '创建者', enname: 'created_by'},
            {title: '创建时间', enname: 'when_created'},
            {
                title: '操作', rghtml: '<div>' +
            '<button style="margin: 0 3px" class="btn btn-sm btn-danger" ng-click="del(i.id)">删除</button>' +
            '</div>'
            },
        ]
    }

    $scope.add_business = function () {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/sys_manage/addbusiness.html',
            windowClass: 'addbusiness',
            controller: 'addbusiness',
            backdrop: 'static',
            resolve: {}
        });
        modalInstance.result.then(function (res) {
            $scope.search()
        })
    };
    $scope.del = function (id) {
        confirmModal.open({
            text: "是否要删除？",
            confirmClick: function () {
                loading.open();
                sysService.delet_business({}, {id: id}, function (res) {
                    loading.close()
                    if (res.result) {
                        msgModal.open('success', '删除成功')
                        $scope.search()
                    } else {
                        msgModal.open("error", "删除失败");
                        console.log(res.error)
                    }
                })
            }
        })
    }
    $scope.sync = function () {
        confirmModal.open({
            text: "是否要同步业务信息？",
            confirmClick: function () {
                loading.open();
                sysService.sync_bussiness({}, {}, function (res) {
                    loading.close()
                    if (res.result) {
                        msgModal.open('success', '同步任务开启成功')
                        $scope.search()
                    } else {
                        msgModal.open("error", "同步任务开启失败");
                        console.log(res.error)
                    }
                })
            }
        })
    }
}])