controllers.controller('mw_type_add', ["$scope", "sysService", "msgModal", "$modalInstance", "loading", "errorModal", function ($scope, sysService, msgModal, $modalInstance, loading, errorModal) {
    $scope.title = "添加中间件类型";
    $scope.args = {
        name: "tomcat"
    };
    $scope.is_loading = {op:false}
    $scope.confirm = function () {
        $scope.is_loading.op = true;
        sysService.add_mw_type({}, $scope.args, function (res) {
            $scope.is_loading.op = false;
            if (res.result) {
                msgModal.open("success", "添加成功！");
                $modalInstance.close();
            }
            else {
                if(res.message){
                    msgModal.open("error",res.message);
                }else {
                    msgModal.open("error",'添加失败，请联系管理员！');
                }
            }
        })
    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);