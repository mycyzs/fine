controllers.controller('addbusiness', ["$scope", "sysService", "$modalInstance", "loading","msgModal",
    function ($scope, sysService, $modalInstance, loading,msgModal) {
    $scope.data = []
    loading.open()
    sysService.get_business_all({}, {}, function (res) {
        loading.close()
        if (res.result) {
            $scope.data = res.data
        }else {
            console.log(res.error)
        }
    })
    $scope.indexlist={}
    $scope.choose = function ($event, index) {
        if ($event.target.checked) {
            $scope.indexlist['' + index] = {id: $scope.data[index].id, name: $scope.data[index].name}
        } else {
            delete $scope.indexlist[index]
        }
    }
    $scope.confirm = function () {
        var up = []
        for (i in $scope.indexlist) {
            up.push($scope.indexlist[i])
        }
        if(up.length==0){
            msgModal.open("error", "请选择业务！");
            return;
        }
        loading.open()
        sysService.add_business({},up,function (res) {
            loading.close()
            if(res.result){
                msgModal.open('success', '添加成功')
                $modalInstance.close();
            }else {
                msgModal.open("error", "添加失败");
                console.log(res.error)
            }
        })

    };
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
}]);