controllers.controller("site", ["$scope", "sysService", "loading", "$timeout", function ($scope, sysService, loading, $timeout) {
    $scope.menuList = [
        {
            displayName: "配置管理", iconClass: "fa fa-cog fa-lg",
            children: []
        },
        {
            displayName: "监控管理", iconClass: "fa fa-cog fa-lg",
            children: []
        },

        {
            displayName: "系统管理", iconClass: "fa fa-cog fa-lg",
            children: [
                {displayName: "中间件类型管理", url: "#/mw_type_manage"},
                {displayName: "模板管理", url: "#/plan_manage"},
                {displayName: "业务管理", url: "#/businessManage"},
                {displayName: "运维人员管理", url: "#/userManage"},
                {displayName: "系统配置管理", url: "#/setting"},
                {displayName: "操作日志", url: "#/operationLog"}
            ]
        }
    ];

    $scope.search = function () {
        loading.open();
        sysService.get_mw_type_list({}, {}, function (res) {
            loading.close();
            if (res.result) {
                for (var i = 0; i < res.data.length; i++) {
                    var mid_name = res.data[i].name;
                    $scope.menuList[0].children.push({displayName: mid_name, url: "#/" + mid_name + "_manage"});
                    $scope.menuList[1].children.push({displayName: mid_name, url: "#/" + mid_name + "_monitor"});
                }

            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        });
    };
    $scope.search();
    $scope.menuOption = {
        data: 'menuList',
        locationPlaceHolder: '#locationPlaceHolder',
        adaptBodyHeight: CWApp.HeaderHeight + CWApp.FooterHeight
    };


}]);