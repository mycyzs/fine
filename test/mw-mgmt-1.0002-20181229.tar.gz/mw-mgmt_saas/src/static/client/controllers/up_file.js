controllers.controller('up_file', ["$scope", "sysService", "$modalInstance", "loading", "errorModal", "msgModal","objectItem", function ($scope, sysService, $modalInstance, loading, errorModal, msgModal,objectItem) {
    $scope.title = "导入excel";
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
    $scope.down_demo = function () {
        var url = site_url+'down_demo?type='+objectItem;
                window.open(url)
    };
    $scope.clickop = false;
    $scope.confirm = function () {
        if ($('.file_input').val() == '') {
            msgModal.open("error", "请选择文件！");
            return
        } else {
            $scope.clickop = true;
            loading.open();
            $('#upload_file_form').ajaxSubmit({
                url: site_url+'up_excel?type='+objectItem,
                type: 'post',
                dataType: 'json',
                success: function (data) {
                    loading.close();
                    if (data.result) {
                        msgModal.open("success", "导入成功");
                        $modalInstance.close();
                    } else {
                        if (data.error_data) {
                            msgModal.open("error", "导入失败");
                            $modalInstance.close();
                        } else {
                            errorModal.open(data.error_list);
                            $modalInstance.close();
                        }
                    }
                },
                error: function (data) {
                    loading.close()
                }
            });
        }
    }
}]);