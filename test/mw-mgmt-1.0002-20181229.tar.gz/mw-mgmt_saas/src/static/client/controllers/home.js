controllers.controller("home", ["msgModal", "$scope", "loading", "sysService", function (msgModal, $scope, loading, sysService) {

}]);
