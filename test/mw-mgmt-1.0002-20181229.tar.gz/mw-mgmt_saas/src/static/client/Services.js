﻿services = angular.module('webApiService', ['ngResource', 'utilServices']);

//生产代码
var POST = "POST";
var GET = "GET";

//测试代码
//var sourceRoute = "./Client/MockData";
//var fileType = ".html";
//var POST = "GET";
//var GET = "GET";
services.factory('sysService', ['$resource', function ($resource) {
    return $resource(site_url + ':actionName/', {},
        {
            get_business_list: {method: POST, params: {actionName: 'get_business_list'}, isArray: false},
            get_business_all: {method: POST, params: {actionName: 'get_business_all'}, isArray: false},
            add_business: {method: POST, params: {actionName: 'add_business'}, isArray: false},
            delet_business: {method: POST, params: {actionName: 'delet_business'}, isArray: false},
            get_log: {method: POST, params: {actionName: 'get_log'}, isArray: false},
            sync_bussiness: {method: POST, params: {actionName: 'sync_bussiness'}, isArray: false},
            get_user: {method: POST, params: {actionName: 'get_user'}, isArray: false},
            add_user: {method: POST, params: {actionName: 'add_user'}, isArray: false},
            modify_user: {method: POST, params: {actionName: 'modify_user'}, isArray: false},
            del_user: {method: POST, params: {actionName: 'del_user'}, isArray: false},


            get_mw_type_list: {method: POST, params: {actionName: 'get_mw_type_list'}, isArray: false},
            add_mw_type: {method: POST, params: {actionName: 'add_mw_type'}, isArray: false},
            del_mw_type: {method: POST, params: {actionName: 'del_mw_type'}, isArray: false},
            get_mw_type_config: {method: POST, params: {actionName: 'get_mw_type_config'}, isArray: false},

            add_plan: {method: POST, params: {actionName: 'add_plan'}, isArray: false},
            get_plan_list: {method: POST, params: {actionName: 'get_plan_list'}, isArray: false},
            get_plan_config: {method: POST, params: {actionName: 'get_plan_config'}, isArray: false},

                get_default_mw_config: {method: POST, params: {actionName: 'get_default_mw_config'}, isArray: false},
                up_default_mw_config: {method: POST, params: {actionName: 'up_default_mw_config'}, isArray: false},

                del_plan: {method: POST, params: {actionName: 'del_plan'}, isArray: false},

                get_setting: {method: POST, params: {actionName: 'get_setting'}, isArray: false},
                up_setting: {method: POST, params: {actionName: 'up_setting'}, isArray: false},
                sync_c: {method: POST, params: {actionName: 'sync_c'}, isArray: false},
                config_sync: {method: POST, params: {actionName: 'config_sync'}, isArray: false},
        });
}]).factory('midService', ['$resource', function ($resource) {
    return $resource(site_url + ':actionName/', {},
        {
            get_middle_ware: {method: POST, params: {actionName: 'get_middle_ware'}, isArray: false},
            has_model: {method: POST, params: {actionName: 'has_model'}, isArray: false},
            get_ip_server: {method: POST, params: {actionName: 'get_ip_server'}, isArray: false},
            add_middleware: {method: POST, params: {actionName: 'add_middleware'}, isArray: false},
            del_middleware: {method: POST, params: {actionName: 'del_middleware'}, isArray: false},
            get_middle_ware_detail: {method: POST, params: {actionName: 'get_middle_ware_detail'}, isArray: false},
            get_middle_ware_config_item: {method: POST, params: {actionName: 'get_middle_ware_config_item'}, isArray: false},
            sync_middle_ware: {method: POST, params: {actionName: 'sync_middle_ware'}, isArray: false},


            get_instance_list: {method: POST, params: {actionName: 'get_instance_list'}, isArray: false},
            operate_mw: {method: POST, params: {actionName: 'operate_mw'}, isArray: false},
            sync_mw: {method: POST, params: {actionName: 'sync_mw'}, isArray: false},
        });
}])
;//这是结束符，请勿删除